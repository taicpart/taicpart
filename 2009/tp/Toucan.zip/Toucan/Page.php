<?php

Toucan::load("Toucan_Lib_Util");
Toucan::load("Toucan_Lib_SimpleEncrypt");
Toucan::load("Toucan_Presentation");

class Toucan_Page extends Toucan_Presentation
{
	var $_title;
	var $_metaDescription;
	var $_metaKeywords;
	var $_favIconURL;
	var $_rssURL;	
	var $_doXMLPrologue;
	var $_styleSheets;
	var $_scripts;
	var $_doCache;
	var $_onLoadScript;

	var $_forms;
	var $_state;
	
	function Toucan_Page($props) 
	{
		parent::Toucan_Presentation($props);
		
		$this->_title            = $this->_getPropDefault($props, 'title');
		$this->_metaDescription  = $this->_getPropDefault($props, 'metaDescription');		
		$this->_metaKeywords     = $this->_getPropDefault($props, 'metaKeywords');		
		
		$this->_favIconURL       = $this->_getPropDefault($props, 'favIconURL');
		$this->_rssURL		     = $this->_getPropDefault($props, 'rssURL');
		$this->_doXMLPrologue    = $this->_getPropDefault($props, 'doXMLPrologue', true);
		$this->_doCache          = $this->_getPropDefault($props, 'doCache', true);		
		$this->_onLoadScript     = $this->_getPropDefault($props, 'onLoadScript', '');
		
		$this->_forms = array();
		$this->_loadState();
		
		// stylesheets were read in from props in parent Toucan_Presentation constructor
		$this->addStyleSheets($this->_styleSheets);
		
		$this->_scripts = array();
	}

	/*------------  Getter and Setter methods  ------------*/

    function setTitle($title) 
    {
        $this->_title = $title;
    }
	
	/*------------  Cache methods  ------------*/
	
	function _getDoCache() 
	{
		return $this->_doCache;
	}
	
	function _setDoCache($doCache)
	{
		$this->_doCache = $doCache;
	}
	
	/*------------  Header methods  ------------*/
	
	function _sendHeaders()
	{
		if (headers_sent()) {
			$this->warning("Headers already sent");	
		} else {
			$this->_sendEncodingHeaders();
			if (!$this->_getDoCache()) {
				$this->_sendNoCacheHeaders();
			}
		}
	}
	
	function _sendEncodingHeaders()
	{
		header('Content-Type: text/html; charset=utf-8');
	}
	
	function _sendNoCacheHeaders()
	{
		// Date in the past
		header("Expires: Mon, 26 Jul 1997 05:00:00 GMT");
		
		// always modified
		header("Last-Modified: " . gmdate("D, d M Y H:i:s") . " GMT");
		 
		// HTTP/1.1
		header("Cache-Control: no-store, no-cache, must-revalidate");
		header("Cache-Control: post-check=0, pre-check=0", false);
		
		// HTTP/1.0
		header("Pragma: no-cache");		
	}
	
	/*------------  Form methods  ------------*/
	
	function &addForm($props)
	{
		if (!is_array($props)) {
			$props = Toucan_Lib_Util::coerceArray($props, 'name');
		}
		
		if (!isset($props['page'])) {
			$props['page'] = &$this;	
		}
		
		$form =& $this->create("Toucan_Form", $props);		
		$this->_forms[$form->getName()] =& $form;
		
		$location = isset($props['location']) ? $props['location'] : 'body';
		if ($location != "none") {
			$this->_subPresentations[$location][] = &$form;	
		}
	
		$this->addStyleSheets($form->getStyleSheets());	
				
		return $form;
	}
	
	function processForms()
	{
		$formNames = array_keys($this->_forms);
		foreach ($formNames as $formName) {
			$form =& $this->_forms[$formName];
			$form->process();
		}	
	}
	
	/*------------  Script methods  ------------*/
		
	function &addScript($props)
	{	
		if (!isset($props['type'])) {
			$this->error("No type set for script to be added to Toucan_Page", $props);
		}		
		
		$type = $props['type'];

		if (strpos($type, 'Toucan') !== 0 && strpos($type, 'Proj') !== 0) {
			$type = "Toucan_Script_{$type}";
		}		
		
		$props['page'] =& $this;
		
		$script =& $this->create($type, $props);
		$this->_scripts[] =& $script;
		return $script;
	}
	
	function addOnLoadScript($functionCall)
	{
		if ($this->_onLoadScript != "") {
			$this->_onLoadScript .= "; ";
		}
		
		$this->_onLoadScript .= $functionCall;	
	}
		
	/*------------  StyleSheet methods  ------------*/
	
	function addStyleSheet($sheet)
	{	
		$this->_styleSheets[] = $sheet;
	}
	
	function addStyleSheets($sheets)
	{
		foreach($sheets as $sheet) {
			$this->addStyleSheet($sheet);	
		}
	}
		
	/*------------  'State' methods  ------------*/	
	
	function setState($state)
	{
		$this->_state = $state;	
	}
	
	function setStateValue($field, $key)
	{
		$this->_state[$field] = $key;	
	}
		
	function getState()
	{
		return $this->_state;	
	}

	function _loadState()
	{
		$stateStr = isset($_REQUEST['state']) ? $_REQUEST['state'] : '';
		if ($stateStr == '') {
			$this->_state = array();
		} else {
			$serializedState = Toucan_Lib_SimpleEncrypt::decrypt($stateStr, TOUCAN_STATE_KEY);	
		
			$this->_state = unserialize($serializedState); 
		
			if ($this->_state === false && $serializedState != serialize($this->_state))  {
				var_dump($stateStr);
				Toucan::error("Could not unserialize the state");
			}
		}
	}
	
	function getStateString() 
	{	
		$serializedState = serialize($this->_state);		
		return Toucan_Lib_SimpleEncrypt::encrypt($serializedState, TOUCAN_STATE_KEY);
	}
	
	function getStateStringRequestName() 
	{
		return 'state';
	}
	
	function getStateQueryStringParam()
	{
		if (sizeof($this->_state) > 0) {
			return $this->getStateStringRequestName()
			       .'='.htmlentities(urlencode($this->getStateString()));
		} else {
			return '';
		}
	}
	
	function getStateFormField()
	{
		if (sizeof($this->_state) > 0) {
			return   '<input type="hidden" name="state" value="'
				   . htmlentities($this->getStateString()).'" />';
		} else {
			return '';
		}
	}
	
	/*------------  Pager/Sorter methods  ------------*/
	
	function &createPager($props)
	{
		if (!isset($props['page'])) {
			$props['page'] =& $this;
		}
		
		$pager =& $this->create("Toucan_Util_Pager", $props);
		return $pager;
	}

	function &createSorter($props)
	{
		if (!isset($props['page'])) {
			$props['page'] =& $this;
		}
		
		$sorter =& $this->create("Toucan_Util_Sorter", $props);
		return $sorter;
	}
	

	/*------------  Request methods ------------*/
	
	function getRequestValue($field)
	{				
		if (isset($_REQUEST[$field])) {
			return $_REQUEST[$field];
		} else if (isset($this->_state[$field])) {
			return $this->_state[$field];
		} else {
			return NULL;
		}
	}
			
	/*------------  HTML methods  ------------*/
	
	function _generateHeaderHTML() 
	{
		$this->_sendHeaders();
		
		$html = <<< HTML
<!DOCTYPE html 
     PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN"
     "http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">
<head>
<title>{$this->_title}</title>

HTML;
		if ($this->_doXMLPrologue) {
			$html = "<?xml version=\"1.0\" encoding=\"utf-8\" ?>\n".$html;
		} 
				
		if ($this->_metaDescription) {
			$html .= $this->_getMetaTagHTML('description', $this->_metaDescription)."\n";
		}	
		
		if ($this->_metaKeywords) {
			$html .= $this->_getMetaTagHTML('keywords', $this->_metaKeywords)."\n";	
		}
				
		$html .= $this->_getStyleSheetsHTML();
		
		if ($this->_rssURL) {
			$html .= "<link href=\"{$this->_rssURL}\" rel=\"alternate\" type=\"application/rss+xml\" title=\"rss\" />\n";
		}
		
		if ($this->_favIconURL) {
			$html .= "<link rel=\"shortcut icon\" href=\"{$this->_favIconURL}\" />\n";
		} 
	
		foreach($this->_scripts as $script) {
			$html .= $script->getScript();
		}
	
		$html .= "</head>\n";
		
		$onLoad = "";
		if ($this->_onLoadScript) {
			$onLoad = " onload=\"{$this->_onLoadScript}\"";
		}
		
		$html .= "<body{$onLoad}>\n";

		$html .= parent::_generateHeaderHTML();
		
		return $html;
	}
		
	function _generateFooterHTML()
	{
		$html = parent::_generateFooterHTML();
		
		$html .= "</body>\n</html>\n";
		
		return $html;
	}

	function _getMetaTagHTML($name, $content) 
	{
		return "<meta name=\"$name\" content=\"$content\" />";
	}
	
	function _getStyleSheetsHTML()
	{
		$html = '';
		
		foreach ($this->_styleSheets as $sheet)
		{
			$media = 'screen, projection';
			$href = '';
		
			if (is_array($sheet)) {
				if (isset($sheet['media'])) {
					$media = $sheet['media'];
				}
				$href = $sheet['href'];
			} else {
				$href = $sheet;	
			}
			
			$html .= "<link rel=\"stylesheet\" type=\"text/css\"  media=\"$media\" href=\"$href\" />\n";
		}
	
		return $html;
	}		
}

?>