<?php

Toucan::load("Toucan_Presentation");

class Toucan_Presentation_HTML extends Toucan_Presentation
{
	var $_html;
	
	function Toucan_Presentation_HTML($props) 
	{		
		parent::Toucan_Presentation($props);	
		$this->_html = $this->_getPropDefault($props, 'html');
	}
	
	function _generateBodyHTML()
	{
		return $this->_html;	
	}
}