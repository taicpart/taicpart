<?php

Toucan::load("Toucan_Presentation_PagerLinks");

class Toucan_Presentation_PagerControls extends Toucan_Presentation_PagerLinks
{
	var $_form;
	var $_pageCaptionHTML; 
	var $_firstHTML;
	var $_prevHTML;
	var $_nextHTML;
	var $_lastHTML;
	var $_jumpTo;
	
	function Toucan_Presentation_PagerControls($props)
	{
		parent::Toucan_Presentation_PagerLinks($props);
		
		$this->_pageCaptionHTML = $this->_getPropDefault($props, "pageCaptionHTML", "Page"); 
		$this->_firstHTML = $this->_getPropDefault($props, "firstHTML", "|&lt;"); 
		$this->_prevHTML  = $this->_getPropDefault($props, "prevHTML",  "&lt;"); 
		$this->_nextHTML  = $this->_getPropDefault($props, "nextHTML",  "&gt;"); 
		$this->_lastHTML  = $this->_getPropDefault($props, "lastHTML",  "&gt;|"); 
		
		$formName = $this->_pager->getName()."Controls";
	
		$jumpToForm = $this->_getPropDefault($props, "jumpToForm");
		if ($jumpToForm) {
			$this->_jumpTo = $formName;
		} else {
			$this->_jumpTo = $this->_getPropDefault($props, "jumpTo", "");	
		}
			
		$this->_form =& $this->_page->addForm(
				array("name"       => $formName,
				      "jumpTo" 	   => $this->_jumpTo,
				      "method"     => "get",
				      "location"   => "none"));		
	}
	
	function _generateHeaderHTML()
	{
		return $this->_form->getHeaderHTML() . "<div class=\"pagerControlsPanel\">\n";
	}
			
	function _generateBodyHTML()
	{
		$options = array();
		
		for ($option=1; $option <= $this->_pager->getMaxPage(); $option ++) {
			$options[] = array("value"=>"$option", "caption"=>"$option");
		}
		
		$select =& $this->_form->addField(
				array('type'         => 'Select',
					  'options'      => $options,
				      'name'         => $this->_pager->getRequestName(),
				      'initialValue' => $this->_pager->getPage()));
				      
		$goButton =& $this->_form->addButton(
				array('name'      => $this->_pager->getName()."Go",
				      'caption'   => 'Go',
				      'htmlClass' => 'pagerButton'));		
		
		$state = $this->_page->getStateQueryStringParam();
		
		$html = "<span class=\"pagerControlsText\">"
		      . $this->_pageCaptionHTML
		      . ": </span>\n"
			  . $select->getHTML()
			  . "&nbsp;" 
		      . $goButton->getHTML()
		      . "&nbsp;";
		      
		$currentPage = $this->_pager->getPage();
		$maxPage     = $this->_pager->getMaxPage();
				
		$prev = $currentPage-1;
		if ($prev < 1) {
			$prev = 1;
		}
		$next = $currentPage+1;
		if ($next > $maxPage) {
			$next = $maxPage;
		}
			
		$html .= $this->_makeLink(1,        $this->_firstHTML, $this->_jumpTo) . "&nbsp;"
		      .  $this->_makeLink($prev,    $this->_prevHTML,  $this->_jumpTo) . "&nbsp;"
		      .  $this->_makeLink($next,    $this->_nextHTML,  $this->_jumpTo) . "&nbsp;"
		      .  $this->_makeLink($maxPage, $this->_lastHTML,  $this->_jumpTo) . "&nbsp;";
				
		return $html;
	}
	
	function _generateFooterHTML()
	{
		return "</div>\n".$this->_form->getFooterHTML();
	}
}

?>