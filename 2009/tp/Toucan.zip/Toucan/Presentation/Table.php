<?php

/*
	todo: row classes based on row class repetition factor (do modulus of row no)

*/

Toucan::load("Toucan_Lib_Util");
Toucan::load("Toucan_Presentation");

class Toucan_Presentation_Table extends Toucan_Presentation
{
	var $_recordset;
	var $_matrix;
	
	var $_sorter;
	var $_sorterURL;
		
	var $_tableRowData;
	var $_tableRowKeys;
	var $_rowFieldNames;
	var $_rowButtonNames;
	var $_endButtonNames;
	var $_endCaption;
	
	function Toucan_Presentation_Table($props)
	{
		parent::Toucan_Presentation($props);
		
		$this->_recordset      =& $this->_getProp($props, 'recordset');
		$this->_tableRowData   =  $this->_getProp($props, 'tableRowData');
		
		$this->_matrix         =& $this->_getProp($props, 'matrix');
		$this->_tableRowKeys   =  $this->_getProp($props, 'tableRowKeys');
		
		$this->_rowFieldNames  =  
				$this->_getPropDefault($props, 'rowFieldNames', array()); 
		$this->_rowButtonNames =  
				$this->_getPropDefault($props, 'rowButtonNames', array()); 

		$this->_endButtonNames = $this->_getPropDefault($props, 'endButtonNames'); 
		$this->_endCaption     = $this->_getPropDefault($props, 'endCaption'); 
				
		$this->_sorter         =& $this->_getPropDefault($props, 'sorter');
	}

	function _generateBodyHTML()
	{
		$html = "<table>\n<tr>\n";
		
		foreach ($this->_tableRowData as $field => $data) {
		
			$caption   = is_array($data) && isset($data['caption'])   
								? $data['caption']   : $data;
								
			$sortField = is_array($data) && isset($data['sortField']) 
								? $data['sortField'] : $field;
						
			$html .= "<td class=\"tableHeader\"><span class=\"tableCaption\">$caption</span> ";
			
			if ($this->_sorter) {
				$html .= $this->_sorter->makeSorterLink($sortField, 'asc', '/\\', $this->_sorterURL) 
				      .  "&nbsp;"
				      .  $this->_sorter->makeSorterLink($sortField, 'desc', '\/', $this->_sorterURL);					
			}
			
			$html .= "</td>";
		}
				
		$html .= "</tr>\n";
		$rowNo = 1;
		while ($this->_recordset->hasNext()) {
			$row = $this->_recordset->nextRecord();			
			$html .= "<tr>\n";
			
			foreach($this->_tableRowData as $field => $data) {
				
				if (is_array($data) && isset($data['callback'])) {
					$callback = $data['callback'];
					$value = $callback($row);
				} else if (is_array($data) && isset($data['display'])) {
					if ($data['display'] == 'url') {
						$target = "";
						if (isset($data['target'])) {
							$target = " target=\"{$data['target']}\"";
						}
						$value = "<a href=\"{$row[$field]}\"$target>{$row[$field]}</a>";
					}
					
				} else {
					$value = $row[$field];	
				}
				$html .= "<td class=\"tableData\">$value</td>\n";					
			}			

			if ($this->_matrix) {
				foreach ($this->_rowFieldNames as $fieldName) {
					$field =& $this->_matrix->getRowField($fieldName, $rowNo);
					$html .= "<td class=\"tableControl\">".$field->getHTML()."</td>\n";
				}	
				
				foreach ($this->_rowButtonNames as $buttonName) {
					$button =& $this->_matrix->getRowButton($buttonName, $rowNo);
					$html .= "<td class=\"tableControl\">".$button->getHTML()."</td>\n";
				}	
				
				foreach($this->_tableRowKeys as $key) {
					$this->_matrix->addRowKeyValue($key, $rowNo, $row[$key]);
				}
			}		
			
			$html .= "</tr>\n";
			$rowNo ++;
		}
		
		if ($this->_endButtonNames) {
			$colSpan = sizeof($this->_tableRowData) + 
					   sizeof($this->_rowFieldNames);
			
			$html .= "<tr><td colspan=\"{$colSpan}\">\n";
			$html .= "{$this->_endCaption}</td>";
							
			foreach ($this->_endButtonNames as $endButtonName) {
				$button =& $this->_matrix->getEndButton($endButtonName);
				$html .= "<td>".$button->getHTML()."</td>\n";
			}
			
			$html .= "</td></tr>\n";
		}		
		
		$html .= "</table>\n";
		return $html;
	}
}
?>