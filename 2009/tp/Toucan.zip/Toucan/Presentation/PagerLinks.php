<?php

Toucan::load("Toucan_Lib_Util");
Toucan::load("Toucan_Lib_Sys");
Toucan::load("Toucan_Presentation");

class Toucan_Presentation_PagerLinks extends Toucan_Presentation
{
	var $_pager;
	var $_targetURL;
	var $_numDisplayLinks;
	var $_jumpTo;
	
	function Toucan_Presentation_PagerLinks($props)
	{
		parent::Toucan_Presentation($props);
		$this->_pager     =& $this->_getProp($props, 'pager');
		$this->_targetURL =  $this->_getPropDefault($props, 
												    'targetURL', 
												    Toucan_Lib_Sys::getRequestURL());
												   
		$this->_numDisplayLinks = $this->_getPropDefault($props, 'numDisplayLinks', 10);
		$this->_jumpTo = $this->_getPropDefault($props, "jumpTo", "");	
	}
		
	// to do: add classes to links so one can override them in css with images
	function _makeLink($page, $anchorText) 
	{
		$pageStr  = $this->_pager->getRequestName()."=$page";
		$stateStr = $this->_page->getStateQueryStringParam();	
		if ($stateStr != '') {
			$stateStr = "&amp;{$stateStr}";	
		}
		
		$anchor = "";
		if ($this->_jumpTo != '') {
			$anchor = "#".$this->_jumpTo;	
		}	
		return  "<a href=\"{$this->_targetURL}?{$pageStr}{$stateStr}{$anchor}\""
		       ." class=\"pagercontrols_page\">{$anchorText}</a>";
	}	
	
	function _generateBodyHTML()
	{
		$state = $this->_page->getState();
		
		$html = "<div class=\"pageLinks\">Results Page: ";
		
		$thisPage = $this->_pager->getPage();
		$maxPage  = $this->_pager->getMaxPage();
		
		$beforeLinks = floor($this->_numDisplayLinks/2);
		$firstPage = max(1, $thisPage - $beforeLinks);
		$lastPage =  $firstPage + $this->_numDisplayLinks - 1;
		if ($lastPage > $maxPage) {
			$lastPage = $maxPage;	
			$firstPage = max(1, $maxPage - ($this->_numDisplayLinks - 1));
		}
		
		if ($firstPage != 1) {
			$html .= "[".$this->_makeLink(1, "First")."] ";
			$html .= "[".$this->_makeLink($thisPage-1, "Prev")."] ";
		}
		
		for ($page=$firstPage; $page <= $lastPage; $page++) {
			if ($page == $this->_pager->getPage()) {
				$html .= "{$page} ";
			} else {
				$html .= $this->_makeLink($page, $page) . " ";
			}
		}	
		
		if ($lastPage != $maxPage) {
			$html .= "[".$this->_makeLink($thisPage+1, "Next")."] ";
			$html .= "[".$this->_makeLink($maxPage, "Last")."] ";
		}
		
		$html .= "</div>";
		
		return $html;
	}
}

?>