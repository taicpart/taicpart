<?php

Toucan::load("Toucan_Presentation");

class Toucan_Presentation_Form extends Toucan_Presentation
{
	var $_form;

	var $_formFieldContainerClass;
	var $_formFieldCaptionClass;
	var $_formFieldClass;
	var $_formFieldValidateClass;
	var $_buttonRowClass;
	var $_matrixRowClass;

	var $_rowFields;
	var $_rowButtons;

	function Toucan_Presentation_Form($props)
	{
		parent::Toucan_Presentation($props);
		$this->_form =& $this->_getProp($props, 'form');

		$this->_formClass =
				$this->_getPropDefault($props, 'formClass', 'form');

		$this->_formFieldRowClass =
				$this->_getPropDefault($props, 'formFieldContainerClass', 'formFieldContainer');

		$this->_formFieldCaptionClass =
				$this->_getPropDefault($props, 'formFieldCaptionClass', 'formFieldCaption');

		$this->_formFieldClass =
				$this->_getPropDefault($props, 'formFieldClass', 'formField');

		$this->_formFieldValidateClass =
				$this->_getPropDefault($props, 'formFieldValidateClass', 'formFieldValidation');

		$this->_matrixRowClass =
				$this->_getPropDefault($props, 'matrixRowClass', 'matrixRow');

		$this->_buttonRowClass =
				$this->_getPropDefault($props, 'buttonRowClass', 'buttonRow');
	}

	function _generateHTML()
	{		
		$this->_rowFields = array();
		$this->_rowButtons = array();

		$html = "<div class=\"{$this->_formClass}\">\n";

		$matrices = $this->_form->getMatrices();
		$matrixNames = array_keys($matrices);

		foreach($matrixNames as $matrixName) {
			$matrix =& $matrices[$matrixName];

			for ($rowNo=1; $rowNo <= $matrix->getNumRows(); $rowNo++) {
				$html .= "<div class=\"{$this->_matrixRowClass}\">\n";
				$html .= $this->_getRowFieldsHTML($matrix, $rowNo);
				$html .= $this->_getRowButtonsHTML($matrix, $rowNo);
				$html .= "</div>\n";
			}
		}

		$html .= $this->_getEndFieldsHTML();
		$html .= $this->_getEndButtonsHTML();

		$html .= "</div>\n";

		return $html;
	}

	function _getRowFieldsHTML(&$matrix, $rowNo)
	{
		$html = '';
		if ($matrix) {
			$fieldNames = $matrix->getFieldNames();
			foreach ($fieldNames as $fieldName) {
				$field =& $matrix->getRowField($fieldName, $rowNo);
				$html .= $this->_getFieldHTML($field);
				$this->_rowFields[] = $field->getName();
			}
		}
		return $html;
	}

	function _getEndFieldsHTML()
	{
		$html = '';

		$fieldNames = array_keys($this->_form->getFields());
		foreach ($fieldNames as $fieldName) {
			if (!in_array($fieldName, $this->_rowFields)) {
				$field =& $this->_form->getField($fieldName);
				$html .= $this->_getFieldHTML($field);
			}
		}
		
		return $html;
	}

	function _getRowButtonsHTML(&$matrix, $rowNo)
	{
		$html = '';
		$buttonNames = $matrix->getButtonNames();

		if (sizeof($buttonNames) > 0) {
			$html .= "<div class=\"{$this->_buttonRowClass}\">\n";
			foreach ($buttonNames as $buttonName) {
				$button =& $matrix->getRowButton($buttonName, $rowNo);
				$html .= $button->getHTML()."\n";
				$this->_rowButtons[] = $button->getName();
			}
			$html .= "</div>\n";
		}

		return $html;
	}

	function _getEndButtonsHTML()
	{
		$html = '';
		$buttons = $this->_form->getButtons();
		$buttonNames = array_keys($buttons);

		if (sizeof($buttonNames) > 0) {
			$html .= "<div class=\"{$this->_buttonRowClass}\">\n";

			foreach ($buttonNames as $buttonName) {
				if (!in_array($buttonName, $this->_rowButtons)) {
					$button =& $buttons[$buttonName];
					$html .= $button->getHTML()."\n";
				}
			}

		    $html .= "</div>\n";
		}
		return $html;
	}

	function _getFieldHTML(&$field)
	{
		$html = '';
		if (!is_a($field, 'Toucan_Form_Field_Hidden')) {
			$caption = $field->getCaption();
			$fieldHTML = $field->getHTML();

			$html .= "<div class=\"{$this->_formFieldRowClass}\">\n"
				  .  "<div class=\"{$this->_formFieldCaptionClass}\">{$caption}</div>\n"
				  .  "<div class=\"{$this->_formFieldClass}\">{$fieldHTML}</div>\n"
			      .  "</div>\n";

			if ($this->_form->submitted()) {
				$validationMessages = $field->performValidate();
				if (sizeof($validationMessages) > 0) {
					$html .= "<div class=\"{$this->_formFieldRowClass}\">\n";

					foreach($validationMessages as $message) {
						$html .= "<div class=\"{$this->_formFieldValidateClass}\">{$message}</div>\n";
					}

					$html .= "</div>";
				}
			}
		}
		return $html;
	}
}
