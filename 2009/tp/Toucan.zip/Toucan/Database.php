<?php

class Toucan_Database extends Toucan
{
	var $_server;
	var $_username;
	var $_password;
	var $_databaseName;
	
	var $_resource;

	function Toucan_Database($props)
	{
		$this->_server = $this->_getProp($props, 'server');
		$this->_username = $this->_getProp($props, 'username');
		$this->_password = $this->_getProp($props, 'password');
		$this->_databaseName = $this->_getProp($props, 'databaseName');
	}		
	
	function connect()
	{
		$this->error("connect() should be overridden in ".$this->toString());
	}
	
	function query($sql)
	{
		$this->error("query() should be overridden in ".$this->toString());
	}
	
	function select($query=array())	
	{
		$this->error("select() should be overridden in ".$this->toString());
	}
		
	function selectOne($query)
	{
		$result = $this->select($query);
		if ($result->numRows() > 0) {
			$row = $result->fetchRow();
			foreach($row as $key => $value) {
				return $value;	
			}
		} else {
			return null;	
		}
	}	
	
	function insert($query=array())
	{
		$this->error("insert() should be overridden in ".$this->toString());		
	}
	
	function delete($query=array())
	{
		$this->error("delete() should be overridden in ".$this->toString());		
	}
	
	function update($query=array())
	{
		$this->error("update() should be overridden in ".$this->toString());		
	}
	
	function ensureConnection()
	{
		if (!$this->_resource) {
			$this->connect();
		}
	}
	
	function setServer($server)
	{
		$this->_server = $server;
	}
	
	function getServer()
	{
		return $this->_server;
	}

	function setUsername($username)
	{
		$this->_username = $username;
	}
	
	function getUsername()
	{
		return $this->_username;
	}

	function setPassword($password)
	{
		$this->_password = $password;
	}
	
	function getPassword()
	{
		return $this->_password;
	}

	function setDatabaseName($databaseName)
	{
		$this->_databaseName = $databaseName;
	}
	
	function getDatabaseName()
	{
		return $this->_databaseName;
	}

	function _printQuery($query)
	{
		if (defined('TOUCAN_SHOW_QUERY') && TOUCAN_SHOW_QUERY) {
			print "<p class=\"toucan_query\">QUERY: {$query}</p>";
		}			
	}

	function toString()
	{
		return get_class($this)." {$this->_username}@{$this->_server}:{$this->_databaseName}";
	}
}

class Toucan_DatabaseResult extends Toucan
{
	var $_resource;
	
	function Toucan_DatabaseResult($resource)
	{
		$this->_resource = $resource;
	}	
	
	function moveTo($rowNo)
	{
		$this->error("fetchRow() should be overridden in ".$this->toString());
	}
	
	function fetchRow()
	{
		$this->error("fetchRow() should be overridden in ".$this->toString());
	}
	
	function numRows()
	{
		$this->error("numRows() should be overridden in ".$this->toString());
	}
}

?>