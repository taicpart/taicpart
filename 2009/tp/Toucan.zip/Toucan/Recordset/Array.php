<?php

Toucan::load("Toucan_Recordset");

class Toucan_Recordset_Array extends Toucan_Recordset
{
	var $_data;
	
	function Toucan_Recordset_Array($props)
	{
		parent::Toucan_Recordset($props);
		$this->_data = $props['data'];
		
		$this->_numRecords = sizeof($this->_data);
		$this->_nextRecordNo = 0;
		$this->_page();
		$this->_sort();
	}
	
	function _page()
	{
	}

	function _sort()
	{	
	}
	
	function &nextRecord() 
	{
		$row = $this->_data[$this->_nextRecordNo];
		$this->_nextRecordNo ++;
		return $row;
	}
}

?>