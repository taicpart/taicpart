<?php

Toucan::load("Toucan_Recordset");

class Toucan_Recordset_Database extends Toucan_Recordset
{
	var $_db;
	var $_dbResult;
	
	function Toucan_Recordset_Database($props)
	{
		parent::Toucan_Recordset($props);	
		$this->_db = $this->_getPropDefault($props, 'db');
		
		if (isset($props['query'])) {
			$this->performQuery($props['query']);
		}
	}	
	
	function performQuery($query)
	{
		$query = $this->_page($query);
		$query = $this->_sort($query);			
				
		$this->_dbResult = $this->_db->select($query);
		$this->_numRecords = $this->_dbResult->numRows();				
	}
	
	function loadRecordsFromKeys($table, $fields, $keys)
	{
		$query = array();
		$query['tables'] = $table;
		$query['fields'] = $fields;
		
		$where = array();
		if (sizeof($keys) > 0) {
			$where['logicalOp'] = 'OR';
			$where['conditions'] = array();
			foreach($keys as $keySet) {	
				$keySetWhere = array();
				$keySetWhere['logicalOp'] = 'AND';
				$keySetWhere['conditions'] = array();
				
				foreach($keySet as $key) {
					$keySetWhere['conditions'][] =
						array("field"=>$key['key'], "value"=>$key['value']);
				}
				
				$where['conditions'][] = $keySetWhere;
			}
		}
		
		$query['where'] = $where;
		$this->performQuery($query);
	}
	
	function _page($query)
	{
		if ($this->_pager) {	
			$countQuery = $query;
			$countQuery['fields'] = 'count(*)';
			$numRows = intval($this->_db->selectOne($countQuery));
			$maxPage = ceil($numRows / $this->_pageSize);
		
			$this->_pager->setMaxPage($maxPage);
			
			$page = $this->_pager->getPage();
			$query['limit'] = array();
			$query['limit']['limit']  = $this->_pageSize;
			$query['limit']['offset'] = ($page-1) * $this->_pageSize;
		} 		
		
		return $query;
	}
	
	function _sort($query)
	{
		$hasDefaultOrderBy = isset($query['orderBy']);
					
		if ($this->_sorter) {
			$rawFields   = $this->_sorter->getFields();
			$sorterOrder = $this->_sorter->getOrder();	
			
			foreach($rawFields as $rawField) {
				$sorterField = '';
				
				if ($rawField != null) {
					foreach($query['fields'] as $field) {
						$compare = $field;
						if (is_array($field)) {
							$compare = $field['as'];
						}
						
						if ($compare == $rawField) {
							$sorterField = $compare;
							break;	
						}	
					}	
				}
						
				if ($sorterField != null) {
					if ($hasDefaultOrderBy) {
						// clear default order by clause
						$query['orderBy'] = array();
						$hasDefaultOrderBy = false;
					}
					
					$query['orderBy'][] = array('field'=>$sorterField, 'order'=>$sorterOrder);
				}
			}
		}			
		
		return $query;		
	}
	
	function moveTo($recordNo) 
	{
		parent::moveTo($recordNo);
		$this->_dbResult->moveTo($recordNo);
	}
	
	function &nextRecord() 
	{	
		$row = $this->_dbResult->fetchRow();
		$this->_nextRecordNo ++;
		return $row;
	}
}

?>