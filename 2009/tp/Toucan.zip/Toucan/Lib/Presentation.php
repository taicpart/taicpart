<?php

class Toucan_Lib_Presentation
{
	function popUp($url, $anchor, $windowID="popUp", 
	               $x=50, $y=50, $width=200, $height=200) {
	
		$return   "<a href=\"$url\" target=\"$windowID\" "
		        . "onclick=\"window.open('$url', '$windowID', "
		        . "'toolbar=no, location=no, scrollbars=yes, "
		        . "resizable=yes, menubar=no, status=no, "
		        . "left=$x, top=$y, width=$width, height=$height'); "
		        . "return false\">$anchor</a>";
	}
}

?>