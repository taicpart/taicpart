<?php

class Toucan_Lib_String
{
	function startsWith($haystack, $needle)
	{
		return strpos($haystack, $needle) === 0;	
	}
	
	function endsWith($haystack, $needle)
	{
		return strrpos($haystack, $needle) === strlen($haystack) - strlen($needle);
	}
}
?>