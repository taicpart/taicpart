<?php

class Toucan_Lib_URL
{
	function canonicalURL($url)
	{
		$components = Toucan_Lib_URL::_getComponents(rtrim($url));
		return Toucan_Lib_URL::_canonicalURL($components);
	}

	function getAbsoluteURL($relURL, $absURL)
	{
		$absComponents = Toucan_Lib_URL::_getComponents($absURL);

		if (!Toucan_Lib_URL::_isAbsolute($absComponents)) {
			return false;
		}

		if (rtrim(substr($relURL, 0, 1)) == '/') {
			$absURL = Toucan_Lib_URL::_canonicalURL(array_slice($absComponents, 0, 2));
		} else {
			$lastEntry = $absComponents[sizeof($absComponents)-1];
			if (Toucan_Lib_URL::_isFile($lastEntry)) {
				array_pop($absComponents);
			}
			
			$absURL = Toucan_Lib_URL::_canonicalURL($absComponents);
		}
		
		return Toucan_Lib_URL::canonicalURL($absURL.$relURL);
	}
	
	function getExtension($url)
	{
		$components = Toucan_Lib_URL::_getComponents($url);
		$file = Toucan_Lib_URL::_getFileComponents($components);
		return $file['ext'];
	}

	function getFileComponents($url)
	{
		$components = Toucan_Lib_URL::_getComponents($url);
		return Toucan_Lib_URL::_getFileComponents($components);
	}

	function isAbsolute($url)
	{
		$components = Toucan_Lib_URL::_getComponents($url);
		return Toucan_Lib_URL::_isAbsolute($components);
	}

	function isExternal($absoluteURL, $compareAbsoluteURL)
	{
		$absoluteURLComponents =
				Toucan_Lib_URL::_getComponents($absoluteURL);
		$compareAbsoluteURLComponents =
				Toucan_Lib_URL::_getComponents($compareAbsoluteURL);

		if (isset($absoluteURLComponents[1]) &&
				isset($compareAbsoluteURLComponents[1])) {			
			return strtolower($absoluteURLComponents[1])
					!= strtolower($compareAbsoluteURLComponents[1]);
		} else {
			return false;
		}
	}

	function _canonicalURL($components)
	{
		$newComponents = $components;
		if (Toucan_Lib_URL::_isAbsolute($components)) {
			$newComponents[0] = strtolower($components[0]).'/';
			if (isset($components[1])) {
				$newComponents[1] = strtolower($components[1]);
			} else {
				return false;
			}
		}
		$canonicalURL = implode("/", $newComponents);
		if (!Toucan_Lib_URL::_isFile(array_pop($components))) {
			if (sizeof($components) > 0) {
				$canonicalURL .= "/";
			} else {
				return false;
			}
		}
		return $canonicalURL;
	}

	function _getComponents($url)
	{
		$rawComponents = explode("/", $url);
		$components = array();
		foreach ($rawComponents as $component) {
			if ($component == '..') {
				array_pop($components);
			} else if ($component != '' & $component != '.') {
				$components[] = $component;
			}
		}
		return $components;
	}

	function _isAbsolute($components)
	{
		$protocols = array("http:", "ftp:");
		return isset($components[0]) && (in_array(strtolower($components[0]), $protocols));		
	}

	function _isFile($file)
	{
		return strpos($file, ".") !== false ||
			   strpos($file, "#") !== false ||
			   strpos($file, "?") !== false;
	}

	function _getFileComponents($components)
	{
		$name     = '';
		$filename = '';
		$ext      = '';
		$anchor   = '';
		$queryStr = '';

		if (!Toucan_Lib_URL::_isAbsolute($components) || sizeof($components) > 2) {
			$file     = array_pop($components);

			$dotPos = strpos($file, ".");

			if ($dotPos !== false) {
				$name = substr($file, 0, $dotPos);
				$ext  = substr($file, $dotPos+1);
				$file = substr($file, $dotPos+1);
			}

			$anchorPos = strpos($file, "#");
			if ($anchorPos !== false) {
				if ($name == '') {
					$name = substr($file, 0, $anchorPos);
				} else if ($ext != '') {
					$ext = 	substr($ext, 0, $anchorPos);
				}
				$anchor = substr($file, $anchorPos+1);
				$file   = substr($file, $anchorPos+1);
			}

			$queryStrPos = strpos($file, "?");
			if ($queryStrPos !== false) {
				if ($name == '') {
					$name = substr($file, 0, $queryStrPos);
				} else if ($ext != '' && $anchor == '') {
					$ext = 	substr($ext, 0, $queryStrPos);
				} else if ($anchor != '') {
					$anchor = substr($anchor, 0, $queryStrPos);
				}
				$queryStr = substr($file, $queryStrPos+1);
			}

			$filename = $name;
			if ($ext != '') {
				$filename .= ".$ext";
			}
		}

		return array("name"     => $filename,
		             "ext"      => $ext,
		             "anchor"   => $anchor,
		             "queryStr" => $queryStr);
	}
}

?>