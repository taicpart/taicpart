<?php

/* To do: 
	- secure against injection 	
*/

class Toucan_Lib_Email 
{	
	function send($toEmailAddress, $subject, $message, 
				  $fromEmailAddress=false, $fromName=false, $cc=false, $bcc=false) 
	{
		$extraHeaders = "To: {$toEmailAddress} <{$toEmailAddress}>";
								
		if ($fromName && $fromEmailAddress) {
			$extraHeaders .= "\r\nFrom: {$fromName} <{$fromEmailAddress}>";
		} else if ($fromEmailAddress) {
			$extraHeaders .= "\r\nFrom: {$fromEmailAddress}";
		}
			
		if ($cc) {
			$extraHeaders .= "\r\nCC: {$cc}";
		}
		
		if ($bcc) {
			$extraHeaders .= "\r\nBCC: {$bcc}";
		}

		if (TOUCAN_EMAIL_LOG_FILE) 
		{
			$file = fopen(TOUCAN_EMAIL_LOG_FILE, "a");
			if ($file) {
				fwrite($file, "*****************************************************************************\n");
				fwrite($file, "EMAIL SENT: ".gmdate("M d Y H:i:s")."\n");
				fwrite($file, "IP ADDRESS: ".$_SERVER['REMOTE_ADDR']."\n");
				fwrite($file, "HEADERS:\n");
				fwrite($file, $extraHeaders."\n");
				fwrite($file, "SUBJECT:\n");
				fwrite($file, $subject."\n");
				fwrite($file, "MESSAGE:\n");
				fwrite($file, $message."\n");	
				fwrite($file, "*****************************************************************************\n\n");
			}
			fclose($file);
		}

		if (TOUCAN_SHOW_ERRORS) {
			mail('', $subject, $message, $extraHeaders);
		} else {
			@mail('', $subject, $message, $extraHeaders);
		}
	}	
}

?>