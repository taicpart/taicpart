<?php

define("ONE_HOUR", 60*60);

class Toucan_Lib_Date
{
	function adjustBST($timestamp)
	{
		if (Toucan_Lib_Date::inBST($timestamp)) {
			$timestamp -= ONE_HOUR;
		}	
		return $timestamp;	
	}
	
	function inBST($timestamp=false)
	{
		if ($timestamp === false) {
			$timestamp = gmmktime();	
		}
		
		$thisYear = (date("Y", $timestamp));
		$marStartDate = ($thisYear."-03-25");
		$octStartDate = ($thisYear."-10-25");
		$marEndDate = ($thisYear."-03-31");
		$octEndDate = ($thisYear."-10-31");
		
		// work out the Unix timestamp for 1:00am GMT on the last 
		// Sunday of March, when BST starts
		while ($marStartDate <= $marEndDate) {
			$day = date("l", strtotime($marStartDate));
			if ($day == "Sunday") {
				$bstStartDate = ($marStartDate);
			}
			$marStartDate++;
		}
		
		$bstStartDate = (date("U", strtotime($bstStartDate)) + ONE_HOUR);
		
		// work out the Unix timestamp for 1:00am GMT on the last 
		// Sunday of October, when BST ends
		while ($octStartDate <= $octEndDate) {
			$day = date("l", strtotime($octStartDate));
			if ($day == "Sunday"){
				$bstEndDate = ($octStartDate);
			}
			$octStartDate++;
		}
		
		$bstEndDate = (date("U", strtotime($bstEndDate)) + ONE_HOUR);
		return (($timestamp >= $bstStartDate) && ($timestamp <= $bstEndDate));
	}
}

?>