<?php

Toucan::load("Toucan_Lib_Date");
Toucan::load("Toucan_Lib_String");

class Toucan_Lib_FileSystem
{
	function getExtension($filename)
	{
		$ext = '';
		$extPos = strpos($filename, '.');
		if ($extPos !== false) {
			$ext = strtolower(substr($filename, $extPos+1)); 
		} 
		return $ext;			
	}	
	
	function canonicalDirName($dirName)
	{
		$dirName = str_replace("\\", "/", $dirName);
		if (!Toucan_Lib_String::endsWith($dirName, "/")) {
			$dirName = "{$dirName}/";
		}
		return $dirName;
	}
	
	function ls($dir, $adjustBST=true)
	{	
		$dir = Toucan_Lib_FileSystem::canonicalDirName($dir);
		
		$dirsList = array();
		$filesList = array();
		if ($resource = opendir($dir)) {
			while (($name = readdir($resource)) !== false) { 
	    		$entry = array();
	    		$entry['name'] = $name;   
	       		$entry['timestamp'] = 
	       				Toucan_Lib_Date::adjustBST(filemtime($dir.$name));   
	       		       		
	       		if (is_dir($dir.$name)) {
	       			$dirsList[$name] = $entry;
	       		} else {
	       			$filesList[$name] = $entry;
	       		}
		   	}
		   	closedir($resource); 
		} else {
			Toucan::warning("Could not get directory listing for $dir");	
		}
		
		$res = array();
        $res["dirs"] = $dirsList;
        $res["files"] = $filesList;
        
        return $res;
	}
}


?>