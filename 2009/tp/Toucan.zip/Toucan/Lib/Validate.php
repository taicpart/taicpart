<?php

class Toucan_Lib_Validate
{
	function notNull($value, $trim=true)
	{
		if ($value == null) {
			return false;
		} else {
			$value = trim($value);
			return $value != '';	
		}
	}
	
	function stringLength($value, $max=null, $min=null)
	{
		//if ($trim) {
		//	$value = trim($value);
		//}
		
		$minOk = $min ? strlen($value) >= $min : true;
		$maxOk = $max ? strlen($value) <= $max : true;
		
		return $minOk && $maxOk;		
	}

	function isNumber($number, $min=null, $max=null, $minPrecision=null, $maxPrecision=null)
	{
		$decPrec = '';
		if ($minPrecision && $maxPrecision) {
			$decPrec = "{{$minPrecision},{$maxPrecision}}";
		} else if ($maxPrecision) {
			$decPrec = "{1,{$maxPrecision}}";
		} //else if ($floatingPoint) {
		  //	$decPrec = '+';	
		//}
		
		$decRegex  = $decPrec ? "\.[0-9]$decPrec" : '';

        if (!preg_match("|^[-+]?\s*[0-9]+($decRegex)\$|", $number)) {
            return false;
        }
              
        $number = (float) str_replace(' ', '', $number);
        if ($min !== null && $number < $min) {
            return false;
        }
        
        if ($max !== null && $number > $max) {
            return false;
        }
       
        return true;		
	}

	function isEmailAddress($email, $checkDomain=false)
	{
        if (ereg('^[-!#$%&\'*+\\./0-9=?A-Z^_`a-z{|}~]+'.'@'.
                 '[-!#$%&\'*+\\/0-9=?A-Z^_`a-z{|}~]+\.'.
                 '[-!#$%&\'*+\\./0-9=?A-Z^_`a-z{|}~]+$', $email))
        {
            if ($checkDomain && function_exists('checkdnsrr')) {
                list (, $domain)  = explode('@', $email);
                if (checkdnsrr($domain, 'MX') || checkdnsrr($domain, 'A')) {
                    return true;
                }
                return false;
            }
            return true;
        }
        return false;		
	}
	
	function isDate($date, $separator='/')
	{
		$dateParts = explode($separator, $date);
		$day   = isset($dateParts[0]) ? $dateParts[0] : false;
		$month = isset($dateParts[1]) ? $dateParts[1] : false;
		$year  = isset($dateParts[2]) ? $dateParts[2] : false;

		if (is_numeric($day) && is_numeric($month) && is_numeric($year)) {
			return checkdate($month, $day, $year);
		} else {
			return false;
		}
	}	
	
	function oldIsDate($date, $separator='/')
	{
		if (trim($date) == "") {
			return false;
		}

		$dateParts = explode($separator, $date);
		$day   = isset($dateParts[0]) ? $dateParts[0] : 0;
		$month = isset($dateParts[1]) ? $dateParts[1] : 0;
		$year  = isset($dateParts[2]) ? $dateParts[2] : 0;
		
		$isMonth = Toucan_Lib_Validate::isNumber($month, 1, 12);
		$isYear  = strlen($year) == 4 && Toucan_Lib_Validate::isNumber($year, 0, 9999);
		
		if ($isMonth && $isYear) {
			$month = intval($month);
			$year  = intval($year);
			
			if ($month == 2) {
				$maxDays = 28;
				if (($year % 4) == 0) {	
					if 	(($year % 100) == 0) {
						if (($year % 400) == 0) {
							$maxDays = 29;
						}
					} else {
						$maxDays = 29;
					}
				}
				return Toucan_Lib_Validate::isNumber($day, 1, $maxDays);
				
			} else {
				$maxDays = array(31, -1, 31, 30, 31, 30, 31, 31, 30, 31, 30, 31);				
				return Toucan_Lib_Validate::isNumber($day, 1, $maxDays[$month-1]);
			}
		} else {
			return false;
		}
	}
}

?>