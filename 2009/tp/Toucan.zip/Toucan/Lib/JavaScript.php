<?php

class Toucan_Lib_JavaScript
{
	function fromSrc($src)
	{
		return "<script language=\"JavaScript\" type=\"text/JavaScript\" src=\"{$src}\"></script>";
	}
	
	function header()
	{
		return "<script language=\"JavaScript\" type=\"text/JavaScript\"><!--\n";	
	}
	
	function footer()
	{
		return "\n//--></script>";	
	}
	
	function scramble($str)
	{
		$code = "";
		$encodedStr = "";
		$chars = array();
		$inTag = false;
		$inParam = false;
		
		for ($i=0; $i < strlen($str); $i++) {
			$char = substr($str, $i, 1);
			
			if ($char == '<') {
				$inTag = true;	
			}
						
			if ($inTag && !$inParam) {
				$encodedStr =  $char . $encodedStr;
			} else {
				$encodedStr =  ';' . strrev(ord($char)) . '#&' . $encodedStr;
			}
			
			if ($inTag) {
				if ($char == '>') {
					$inTag = false;
				} else if ($char == "'" || $char == '"') {
					$inParam = !$inParam;
				}
			}
		}
		
		for ($i=0; $i < strlen($encodedStr); $i++) {	
			$char = substr($encodedStr, $i, 1);
			if ($char == '"') {
				$char = '\\"';
			}
		
			$code .= 'var a' . $i . '="' . $char . '";';
		}
	
		$code .= 'document.write(';
		
		for ($i=strlen($encodedStr)-1; $i >= 0; $i--) {	
			if ($i != strlen($encodedStr)-1) {
				$code .= '+' ;
			}
			$code .= 'a' . $i;
		}
		
		$code .= ');';
		return $code;
	}
	
	function scrambleEmailAddress($emailAddress) 
	{	
		return Toucan_Lib_JavaScript::header()
		       . "document.write('<a href=\"');"
		       . Toucan_Lib_JavaScript::scramble("mailto:$emailAddress")
		       . "document.write('\">');"
		       . Toucan_Lib_JavaScript::scramble($emailAddress)
		       . "document.write('</a>');"
		       . Toucan_Lib_JavaScript::footer();		
	}
	
	function printPage()
	{
		return Toucan_Lib_JavaScript::header()."window.print();".Toucan_Lib_JavaScript::footer();			
	}
}

?>
