<?php

class Toucan_Lib_Sys
{	
	function clearIncludePath()
	{
		ini_set('include_path', './');
	}
	
	function addToIncludePath($path) 
	{
		$separator = (strpos(PHP_OS, 'WIN') === 0) ? ';' : ':'; 
		ini_set('include_path', ini_get('include_path').$separator.$path);
	}
	
	function getRequestURL()
	{
		if (strpos($_SERVER['REQUEST_URI'], '?') === false) {
			return $_SERVER['REQUEST_URI'];
		} else {
			return substr($_SERVER['REQUEST_URI'], 0, strpos($_SERVER['REQUEST_URI'], '?'));		
		}
	}	
}

?>