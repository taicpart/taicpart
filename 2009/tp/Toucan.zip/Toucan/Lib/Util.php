<?php

class Toucan_Lib_Util 
{
	function coerceArray($value, $key=false)
	{
		$arr = array();	
		if ($key) {
			$arr[$key] = $value;	
		} else {
			$arr[] = $value;	
		}
		
		return $arr;
	}
		

}
?>