<?php

Toucan::load("Toucan_Lib_JavaScript");

class Toucan_Script extends Toucan
{
	var $_page;
	
	function Toucan_Script($props)
	{
		$this->_page =& $this->_getProp($props, 'page'); 
	}
	
	function _generateCode()
	{
		return '';
	}

	function _generateNoScript()
	{
		return '';
	}

	function getScript()
	{
		$script = Toucan_Lib_JavaScript::header()
		        . $this->_generateCode()
		        . Toucan_Lib_JavaScript::footer();

		$noScript = $this->_generateNoScript();
		if ($noScript) {
			$noScript = "<noscript>{$noScript}</noscript>";
		}
		
		return $script.$noScript;
	}
}

?>