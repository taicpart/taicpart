<?php

class Toucan_Recordset extends Toucan
{
	var $_numRecords;
	var $_nextRecordNo;

	var $_pager;
	var $_pageSize;
	var $_sorter;

	function Toucan_Recordset($props)
	{
		$this->_pager    =& $this->_getPropDefault($props, 'pager');
		$this->_pageSize =  $this->_getPropDefault($props, 'pageSize', 20);
		
		$this->_sorter   =& $this->_getPropDefault($props, 'sorter'); 
		
		$this->_toMoveTo = null;
		$this->_nextRecordNo = 0;
	}
	
	function getNumRecords()
	{
		return $this->_numRecords;
	}
	
	function moveToFirst()
	{
		$this->moveTo(0); 
	}

	function moveToLast() 
	{
		$this->moveTo($this->numRecords()-1);	
	}

	function moveTo($recordNo) 
	{
		$this->_nextRecordNo = $recordNo;
	}

	function numRecords() 
	{
		return $this->_numRecords;
	}	
	
	function hasNext() 
	{
		return $this->_nextRecordNo < $this->numRecords();
	}
	
	function nextRecordNo()
	{
		return $this->_nextRecordNo;	
	}
	
	function &nextRecord() 
	{
		$this->error("nextRecord() should be overridden in ".$this->toString());
	}
	
	function getPageSize() 
	{
		return $this->_pageSize;	
	}
}

?>