<?php

Toucan::load("Toucan_Database");

class Toucan_Database_MySQL extends Toucan_Database
{	
	function connect()
	{
		$this->_resource = mysql_connect($this->_server, $this->_username, $this->_password);
		
		if (!$this->_resource) {
			$this->error("Could not connect to ".$this->toString());
			die();
		}	
		
		if (!mysql_select_db($this->_databaseName, $this->_resource)) {
			$this->error("Could not select database for ".$this->toString());
			die();
		}
		
		$this->_connected = true;
	}
	
	function query($sql)
	{
		$this->_printQuery($sql);
		$this->ensureConnection();
		
		$result = mysql_query($sql, $this->_resource);	
		if (!$result) {
			$this->error("[{$sql}]. Invalid query.  MySQL said: ".mysql_error());
		} 

		if (strpos(strtolower(trim($sql)), 'select') === 0) {	
			return new Toucan_DatabaseResult_MySQL($result);
		}
	}
	
	function getTableNames()
	{
		$this->ensureConnection();
		$result = mysql_list_tables($this->_databaseName);	
		if (!$result) {
			$this->error("Could not get tables list");
		}

		$tables = array();
		while ($row = mysql_fetch_row($result)) {
   			$tables[] = $row[0];
   		}

		return $tables;
	}
	
	function select($query)
	{
		$sql = "";

		$fields  = isset($query["fields"])  ? $query["fields"]  : "*";
		$tables  = isset($query["tables"])  ? $query["tables"]  : "";
		$where   = isset($query["where"])   ? $query["where"]   : "";
		$orderBy = isset($query["orderBy"]) ? $query["orderBy"] : "";
		$limit   = isset($query["limit"])   ? $query["limit"]   : "";

		$fieldsStr  = $this->_getFields ($fields);
		$tablesStr  = $this->_getTables ($tables);
		$whereStr   = $this->_getWhere  ($where);
		$orderByStr = $this->_getOrderBy($orderBy);
		$limitStr   = $this->_getLimit  ($limit);
					
		$sql = "SELECT DISTINCT $fieldsStr $tablesStr $whereStr $orderByStr $limitStr";
	
		return $this->query($sql);
	}

	function _getFields($fields)
	{
		if (is_array($fields)) {
			$fieldsStr = "";
			$first = true;
			
			foreach ($fields as $field) {
				if ($first) {
					$first = false;
				} else {
					$fieldsStr .= ", ";	
				}
				
				if (is_array($field)) {
					$fieldsStr .= "{$field['field']} AS {$field['as']}";
				} else {
					$fieldsStr .= $field;	
				}
			}		
			return $fieldsStr;
		} else {
			return $fields;	
		}
	}

	function _getTables($tables)
	{
		$tablesStr = "";
		
		if (is_array($tables)) {
			$first = true;
			foreach ($tables as $table) {
				if ($first) {
					if (is_array($table)) {
						$tablesStr = $table['table'];	
					} else {
						$tablesStr = "$table";	
					}
					$first = false;
				} else {
					if (is_array($table)) {
						$tableName = "{$table['table']}";
						$join = ",";
						$joinCondition = "";
						
						if (isset($table['join'])) {
							if ($table['join'] == 'left') {
								$join = " LEFT JOIN";	
							} else if ($table['join'] == 'inner') {
								$join = " INNER JOIN";	
							}
							if (isset($table['joinCondition'])) {
								$joinCondition = "ON ".$this->_getConditions($table['joinCondition']);
							}
						} 						
						$tablesStr .= "{$join} {$table['table']} {$joinCondition}";	
						
					} else {
						$tablesStr .= ", $table";	
					}
				}	
			}
		} else {
			$tablesStr = $tables;
		}
		
		return ($tablesStr) ? "FROM $tablesStr" : "";
	}
	
	function _getWhere($where) {
		$conditions = $this->_getConditions($where);
		return ($conditions) ? "WHERE $conditions" : "";
	}
	
	function _getConditions($conditions) 
	{   
		if (is_array($conditions)) {
			$logicalOp = isset($conditions['logicalOp']) 
			           ? $conditions['logicalOp'] 
			           : 'AND';
			
			$conditions = isset($conditions['conditions']) 
			            ? $conditions['conditions'] 
			            : $conditions;
			            
			return $this->_getJoinedConditions($conditions, $logicalOp);
		} else {
			return $conditions;
		}	
	}
		
	function _getJoinedConditions($conditions, $logicalOp)
	{		
		$conditionsStr = "";		
		$first = true;
		
		foreach ($conditions as $condition) {	
		
			if ($first) {
				$first = false;
			} else {
				$conditionsStr .= " {$logicalOp} ";
			}
			
			if (isset($condition['conditions'])) {

				$subConditions = $condition['conditions'];
				
				$subLogicalOp = isset($condition['logicalOp']) 
				           ? $condition['logicalOp'] 
				           : 'AND';
	
				$subConditionsStr = $this->_getJoinedConditions(
						$subConditions, $subLogicalOp);	
				
				$conditionsStr .= "($subConditionsStr)";
			} else {
				$operand1 = isset($condition['field1']) 
								? $condition['field1'] 
								: (isset($condition['field']) ? $condition['field'] : '');
																
				$op = isset($condition['op']) ? $condition['op'] : "=";
				
				$operand2 = "";
				
				if (isset($condition['field2'])) {
					$operand2 = $condition['field2'];
				} else if (isset($condition['value'])) {
					$operand2 = $this->_getFieldValue($condition);
				}
						
				$conditionsStr .= "$operand1 $op $operand2";
			} 
		}
		
		return $conditionsStr;
	}
	
	function _getOrderBy($orderBy)
	{
		$orderByStr = "";
		
		if (is_array($orderBy)) {
			if (isset($orderBy['field'])) {
				$orderByStr = $this->_getOrderByClause($orderBy);
			} else {
				$first = true;
				foreach ($orderBy as $orderByClause) {
					if ($first) {
						$first = false;
					} else {
						$orderByStr .= ", ";	
					}
					$orderByStr .= $this->_getOrderByClause($orderByClause);
				}
			}
		} else {
			$orderByStr = $orderBy;	
		}	
		
		return ($orderByStr) ? "ORDER BY $orderByStr" : "";
	}

	function _getOrderByClause($orderByClause) {
		return "{$orderByClause['field']} {$orderByClause['order']}";
	}

	function _getLimit($limit)
	{
		if (is_array($limit)) {
			return "LIMIT {$limit['limit']} OFFSET {$limit['offset']}";
		} else {
			return "";
		}
	}

	function insert($query)
	{
		extract($query);
				
		if (!isset($table)) {
			$this->error("No 'table' attribute for select query passed to ".$this->toString());	
		}
				
		if (!isset($toInsert)) {
			$this->error("No 'toInsert' attribute for select query passed to ".$this->toString());	
		}
		
		$first = true;
		$keys = '';
		$values = '';
		foreach ($toInsert as $item) {
			if ($first) {
				$first = false;
			} else {
				$keys   .= ", ";
				$values .= ", ";
			}
			
			$keys .= $item['field'];
			$values .= $this->_getFieldValue($item);
		} 
		
		$sql = "INSERT INTO $table ($keys) VALUES ($values) ";

		return $this->query($sql);		
	}
		
	function _getFieldValue($field)
	{	
		$value = $field['value'];
				
		if (($value == "" && $value !== false) || $value === "null" || $value === "NULL") {
			return "NULL";	
		}
		
		if (isset($field['applyFunction'])) {
			$value = $this->$field['applyFunction']($value);
		} else {
			$value = "'".addslashes($value)."'";		
		}
		
		return $value;
	}	
		
	function delete($query)
	{
		$sql = "";

		$tablesStr  = $query['table'];
		
		$whereStr = "";
		if (isset($query['where'])) {
			$whereStr   = $this->_getWhere($query['where']);
		}
				
		$sql = "DELETE FROM $tablesStr $whereStr";

		return $this->query($sql);		
	}
	
	function update($query)
	{
		extract($query);				
				
		if (!isset($table)) {
			$this->error("No 'table' attribute for select query passed to ".$this->toString());	
		}
				
		if (!isset($toUpdate)) {
			$this->error("No 'toUpdate' attribute for select query passed to ".$this->toString());	
		}

		$first = true;
		$toUpdateStr = '';
		foreach ($toUpdate as $item) {
			if ($first) {
				$first = false;
			} else {
				$toUpdateStr .= ", ";
			}
			
			$toUpdateStr .= "{$item['field']} = ";
			$toUpdateStr .= $this->_getFieldValue($item);
		} 
				
		$whereStr = "";
		if (isset($where)) {
			$whereStr   = $this->_getWhere($where);
		}
				
		$sql = "UPDATE $table SET $toUpdateStr $whereStr";
		return $this->query($sql);
	}
	
	function strToDate($val) {
		list($day, $month, $year) = explode('/', $val);
		return "'".strftime("%Y-%m-%d", mktime(0, 0, 0, $month, $day, $year))."'";
	}
	
	function likeStr($val) {
		return "'%$val%'";
	}
	
    function boolToInt($val) {
        return $val ? 1 : 0;
    }
	
	function dumpToFile($tables, $file, $options=array())
	{
		$file = escapeshellcmd($file);
		
		$optionsParam = "";
		foreach ($options as $optionName => $option) {
			if ($option == "addDropTable")	{
				$optionsParam .= "--add-drop-table ";
			} elseif ($optionName == "compatible") {
				$optionsParam .= "--compatible={$option} ";
			}
		}
				
		$dbTables = $this->getTableNames();
		$checkedTables = array();
			
		foreach ($tables as $table) {
			$table = trim($table);
			if (in_array($table, $dbTables)) {
				$checkedTables[] = $table;	
			}	
		}
				
		$tablesParam = implode(" ", $checkedTables);		

		$command = "mysqldump --host={$this->_server} "
		         . "--user={$this->_username} --password={$this->_password} "
				 . "{$optionsParam} {$this->_databaseName} {$tablesParam} > {$file}";
		
		$this->exec($command);		
	}
	
	function importFromFile($file)
	{
		$file = escapeshellcmd($file);
		
		$command = "mysql --host={$this->_server} "
		         . "--user={$this->_username} --password={$this->_password} "
		         . "--database={$this->_databaseName} < {$file}";
		
		$this->exec($command);
	}
}

class Toucan_DatabaseResult_MySQL extends Toucan_DatabaseResult
{
	function moveTo($rowNo)
	{
		if ($rowNo < $this->numRows()) {
			return mysql_data_seek($this->_resource, $rowNo);
		} else {
			return -1;
		}
	}
	
	function fetchRow()
	{
		return mysql_fetch_assoc($this->_resource);
	}
	
	function numRows()
	{
		return mysql_num_rows($this->_resource);	
	}
}

?>