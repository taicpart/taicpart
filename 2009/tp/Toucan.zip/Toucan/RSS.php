<?php
			
class Toucan_RSS extends Toucan
{
	var $_title;
	var $_link;
	var $_description;
	var $_language;
	var $_copyright;
	var $_editor;
	var $_webMaster;
	var $_pubDate;
	var $_lastBuildDate;
	var $_category;
	var $_generator;
	var $_docs;
	var $_cloud;
	var $_ttl;
	var $_image;
	var $_rating;
	var $_textInput;
	var $_skipHours;
	var $_skipDays;
	
	function Toucan_RSS($props) 
	{		
		$this->_title           = $this->_getProp($props, 'title');
		$this->_link            = $this->_getProp($props, 'link');		
		$this->_description     = $this->_getProp($props, 'description');
		$this->_language        = $this->_getPropDefault($props, 'language', 'en-gb');
		$this->_copyright       = $this->_getPropDefault($props, 'copyright');
        $this->_managingEditor  = $this->_getPropDefault($props, 'editor');
		$this->_webMaster       = $this->_getPropDefault($props, 'webMaster');
		$this->_pubDate         = $this->_getPropDefault($props, 'pubDate');
		$this->_lastBuildDate   = $this->_getPropDefault($props, 'lastBuildDate');
		$this->_category        = $this->_getPropDefault($props, 'category');
		$this->_generator       = $this->_getPropDefault($props, 'generator');
		$this->_docs            = $this->_getPropDefault($props, 'docs');
		$this->_cloud           = $this->_getPropDefault($props, 'cloud');
		$this->_ttl             = $this->_getPropDefault($props, 'ttl');
		$this->_image           = $this->_getPropDefault($props, 'image');
		$this->_rating          = $this->_getPropDefault($props, 'rating');
		$this->_textInput       = $this->_getPropDefault($props, 'textInput');
		$this->_skipHours       = $this->_getPropDefault($props, 'skipHours');
		$this->_skipDays        = $this->_getPropDefault($props, 'skipDays');
	}
	
	function _makeTag($name, $contents, $props=array())
	{
	    if ($contents != "" || sizeof($props) != 0) {
	        $first = true;
	        $propsList = "";	        
	        foreach($props as $keyName => $keyValue) {
	            $propsList .= " {$keyName}=\"$keyValue\"";	           
	        }
	        
	        return "<{$name}{$propsList}>".htmlspecialchars($contents)."</{$name}>\n";
	    }
	}
	
	function _getImageXML($image) 
	{
	    if (sizeof($image) != 0) {
    	    $xml = "\n<image>\n";
    		$xml .= $this->_makeTag("title", $this->_title);
    		$xml .= $this->_makeTag("link",  $this->_link);
    		$xml .= $this->_makeTag("url",   $image['url']);
    		
    		if (isset($image['width'])) {
    		    $xml .= $this->_makeTag("width",   $image['width']);
    		}
    		
    		if (isset($image['height'])) {
    		    $xml .= $this->_makeTag("height",   $image['height']);
    		}
        
            $xml .= "</image>\n";
            
    	    return $xml;		
	    } else {
	        return '';
	    }
    }
    
	function getHeaderXML()
	{
$xml  = <<< XML
<?xml version="1.0" encoding="utf-8" ?>
<rss version="2.0">
<channel>
XML;

        $xml .= $this->_getImageXML($this->_image);
        
		$xml .= $this->_makeTag("title",            $this->_title);
		$xml .= $this->_makeTag("link",             $this->_link);
		$xml .= $this->_makeTag("description",      $this->_description);
		$xml .= $this->_makeTag("language",         $this->_language);
		$xml .= $this->_makeTag("copyright",        $this->_copyright);
		$xml .= $this->_makeTag("managingEditor",   $this->_managingEditor);
		$xml .= $this->_makeTag("webMaster",        $this->_webMaster);
        $xml .= $this->_makeTag("putDate",          $this->_pubDate);
        $xml .= $this->_makeTag("lastBuildDate",    $this->_lastBuildDate);
        $xml .= $this->_makeTag("category",         $this->_category);
        $xml .= $this->_makeTag("generator",        $this->_generator);
        $xml .= $this->_makeTag("docs",             $this->_docs);
        $xml .= $this->_makeTag("cloud",            $this->_cloud);
        $xml .= $this->_makeTag("ttl",              $this->_ttl);
        $xml .= $this->_makeTag("rating",           $this->_rating);
        $xml .= $this->_makeTag("skipHours",        $this->_skipHours);
        $xml .= $this->_makeTag("skipDays",         $this->_skipDays);
		
        return $xml;
	}

	function getItemXML($title, $link, $description, 
	                    $author='', $category='', $comments='', 
	                    $enclosure=array(), $guid='', $pubDate='', $source='')
	{
	    if ($title != '' || $description != '') {	
    	    $xml = "\n<item>\n";
    	    $xml .= $this->_makeTag("title",       $title);
    	    $xml .= $this->_makeTag("link",        $link);
    	    $xml .= $this->_makeTag("description", $description);
    	    $xml .= $this->_makeTag("author",      $author);
    	    $xml .= $this->_makeTag("category",    $category);
    	    $xml .= $this->_makeTag("comments",    $comments);
    	    $xml .= $this->_makeTag("enclosure",   '', $enclosure);
    	    $xml .= $this->_makeTag("guid",        $guid);
    	    $xml .= $this->_makeTag("pubDate",     $pubDate);
    	    $xml .= $this->_makeTag("source",      $source);
    	    
    	    $xml .= "</item>\n";	
    	    return $xml;
	    } else {
	        $this->error("No title or description supplied for RSS item");
	    }
	    
	}

 	function getFooterXML()
	{	
$xml  = <<< XML
</channel>
</rss>
XML;
		return $xml;
	}
	
	function getBodyXML() 
	{
	    return '';
	}
	
	function deliverFeed($xml='') {
	    header("Content-Type: application/xml");
	    print $this->getHeaderXML();		
	    if ($xml == '') {
	        print $this->getBodyXML();
	    } else {
		    print $xml;
		}
		print $this->getFooterXML();
		die();
    }
}

?>