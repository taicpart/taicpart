<?php

Toucan::load("Toucan_Lib_Sys");

class Toucan_Util_Sorter extends Toucan
{
	var $_name;
	var $_fields;
	var $_order;
	
	var $_page;
	
	function Toucan_Util_Sorter($props)
	{
		$this->_name = $this->_getProp($props, 'name');
		$this->_page =& $this->_getProp($props, 'page');
		
		if ($this->_getFieldRequestValue() == null) {
			$this->_fields = $this->_getPropDefault($props, 'fields');
		} else {
			$this->_fields = $this->_getFieldRequestValue();
		}
		
		if ($this->_getOrderRequestValue() == NULL) {
			$this->_order =	$this->_getPropDefault($props, 'order');
		} else {
			$this->_order = $this->_getOrderRequestValue();
		}
				
		if ($this->_order != 'asc' && $this->_order != 'desc') {
			$this->_order = 'asc';
		}
		
		$this->saveState();
	}
	
	function saveState()
	{
		$this->_page->setStateValue(
				$this->getFieldRequestName(), $this->_getFieldRequestValue());
				
		$this->_page->setStateValue(
				$this->getOrderRequestName(), $this->_getOrderRequestValue());
	}
	
	function getFields()
	{
		return explode(",", $this->_fields);
	}
	
	function getOrder()
	{
		return $this->_order;
	}
	
	function getFieldRequestName()
	{
		return $this->_name."Field";
	}
	
	function _getFieldRequestValue() 
	{
		return $this->_page->getRequestValue($this->getFieldRequestName());
	}
	
	function getOrderRequestName()
	{
		return $this->_name."Order";
	}
	
	function _getOrderRequestValue() 
	{
		return $this->_page->getRequestValue($this->getOrderRequestName());
	}	
	
	function getSorterLink($sortField, $sortOrder, $targetURL="", $anchor="") 
	{
		if ($targetURL == "") {
			$targetURL = Toucan_Lib_Sys::getRequestURL();
		}
		
		$stateStr = $this->_page->getStateQueryStringParam();	
		if ($stateStr != '') {
			$stateStr = "&amp;{$stateStr}";	
		}
				
		$queryString = $this->getFieldRequestName()."=".urlencode($sortField)."&amp;"
		             . $this->getOrderRequestName()."=".urlencode($sortOrder)
		             . $stateStr;

		if ($anchor) {
			$anchor = "#{$anchor}";	
		}

		return "{$targetURL}?{$queryString}{$anchor}";
	}
	
	function makeSorterLink($sortField, $sortOrder, $anchorText, $targetURL="", $anchor="")
	{
		$url = $this->getSorterLink($sortField, $sortOrder, $targetURL, $anchor);
		return "<a href=\"{$url}\">{$anchorText}</a>";
	}		
}

?>