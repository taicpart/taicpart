<?php

Toucan::load("Toucan_Lib_Validate");

class Toucan_Util_Pager extends Toucan
{
	var $_name;
	var $_page;
	var $_maxPage;
	
	function Toucan_Util_Pager($props)
	{
		$this->_name =  $this->_getProp($props, 'name');
		$this->_page =& $this->_getProp($props, 'page');
		
		$this->_maxPage = $this->_getPropDefault($props, 'maxPage', 1);
		
		$this->saveState();
	}
	
	function getName() 
	{
		return $this->_name;
	}
	
	function saveState()
	{
		$this->_page->setStateValue($this->getRequestName(), $this->_getRequestValue());
	}
	
	function getRequestName()
	{
		return $this->_name;
	}
	
	function _getRequestValue()
	{
		return $this->_page->getRequestValue($this->getRequestName());
	}
	
	function setMaxPage($maxPage) 
	{
		$this->_maxPage = $maxPage;	
	}
	
	function getMaxPage() {
		return $this->_maxPage;
	}
	
	function getPage()
	{
		$page = 1;		
		$requestValue = $this->_getRequestValue();
			
		if ($requestValue != NULL) {
			if (Toucan_Lib_Validate::isNumber($requestValue, 1, $this->_maxPage)) {
				$page = intval($requestValue);	
			}
		}
		
		return $page;	
	}
}

?>