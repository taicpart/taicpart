<?php

class Toucan_Util_Login extends Toucan
{
	var $_sessionKeyName;
	var $_loginPage;

	function Toucan_Util_Login($props)
	{
		$this->_sessionKeyName = $this->_getPropDefault($props, 'sessionKeyName', 'loggedIn');
		$this->_loginPage = $this->_getPropDefault($props, 'loginPage');
	}
	
	function checkLogin()
	{
		if (!$this->getUser()) {
			header($this->_loginPage);	
		}
	}
	
	function getUser()
	{
		return $this->_getPropDefault($_SESSION, $this->_sessionKeyName, false);
	}
	
	function login($user='anon')
	{
		$_SESSION[$this->_sessionKeyName] = $user;
	}
	
	function logout()
	{
		unset($_SESSION[$this->_sessionKeyName]);
	}
}


?>