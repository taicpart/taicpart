<?php

Toucan::load("Toucan_Lib_URL");

class Toucan_Util_LinkInformation extends Toucan
{
	var $_startURL;
	var $_baseURL;
	var $_checkExternal;
	
	var $_internalLinks;
	var $_externalLinks;
	var $_deadLinks;
	
	var $_exts = array("", "html", "php");
	
	function Toucan_Util_LinkInformation($props)
	{
		$this->_startURL = Toucan_Lib_URL::canonicalURL($this->_getProp($props, "startURL"));
		$this->_baseURL  = $this->_getPropDefault($props, "baseURL", $this->_startURL);
		$this->_checkExternal = $this->_getPropDefault($props, "checkExternal", true);

		$this->_internalLinks = array();
		$this->_externalLinks = array();
		$this->_deadLinks     = array();		

		$investigated    = array();
		$toInvestigate   = array();
		$toInvestigate[] = array('url'=>$this->_startURL, 'from'=>'');
		
		$count = 0;
		
		while (sizeof($toInvestigate) > 0) {
			$entry = array_pop($toInvestigate);	

			// print "investigating: ".$entry['url']." <br />";

			$external = Toucan_Lib_URL::isExternal($entry['url'], $this->_startURL);		
			$ignore = !in_array(Toucan_Lib_URL::getExtension($entry['url']), $this->_exts);
						
			if (($external && !$this->_checkExternal) || (!$external && $ignore)) {
				continue;	
			}

			if (in_array($entry['url'], $investigated)) {
				if (in_array($entry['url'], $this->_deadLinks)) {
					$entry['url'][] = $entry['from'];
				}
				continue;	
			}
			
			$count ++;
			$this->_progress("{$count}: {$entry['url']}");
			
			if ($this->_pageExists($entry['url'])) {
				if ($external) {
					$this->_externalLinks[] = $entry['url'];
				} else {
					$this->_internalLinks[] = $entry['url'];
					$tagData = $this->_getTagData($entry['url']);	
					
					foreach ($tagData as $tag) {
						if (isset($tag['attribs']['HREF'])) {
							$newURL = $tag['attribs']['HREF'];
							
					/*		
$fullURL = Toucan_Lib_URL::getAbsoluteURL(
									$newURL, $entry['url']);							
print "found: $fullURL <br />";
		*/
							
							
							if (Toucan_Lib_URL::isAbsolute($newURL)) {
								$newURL = Toucan_Lib_URL::canonicalURL($newURL);
							} else {
								$newURL = Toucan_Lib_URL::getAbsoluteURL(
									$newURL, $entry['url']);
							}
							
							$toInvestigate[] = array('url'  => $newURL,
								                     'from' => $entry['url']);
						}	
					}
				}				
			} else {
				$this->_deadLinks[$entry['url']] = array($entry['from']);	
			}
			
			$investigated[] = $entry['url'];
		}
	}

	function _pageExists($url)
	{
		$resource = @fopen($url, "r");
		@fclose($resource);
		return $resource !== false;
	}

	function _getTagData($url)
	{
		$pageParser = $this->create("Toucan_Util_XMLParser", 
				array("file"  => $url,
		 			  "tags" => array('a')));
		
		return $pageParser->getTagData();
	}

	function _progress($str)
	{
		print "$str <br />"; 
		flush();	
	}

	function getInternalLinks()
	{
		return $this->_internalLinks;	
	}

	function getExternalLinks()
	{
		return $this->_externalLinks;	
	}
	
	function getDeadLinks()
	{
		return $this->_deadLinks;	
	}
}

?>