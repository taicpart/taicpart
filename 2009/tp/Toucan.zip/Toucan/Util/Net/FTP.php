<?php

class Toucan_Util_Net_FTP extends Toucan
{
	var $_server;
	var $_username;
	var $_password;
	var $_port;
	var $_resource;

	var $_matcher;
	var $_lsMatch = array(
	        'unix'    => array(
	            'pattern' => '/(?:(d)|.)([rwxt-]+)\s+(\w+)\s+(\w+)\s+(\w+)\s+(\w+)\s+(\S+\s+\S+\s+\S+)\s+(.+)/',
	            'map'     => array('name'=>8,'size'=>6,'rights'=>2,'user'=>4,'group'=>5,
	                              'files_inside'=>3,'date'=>7,'is_dir'=>1)
	        ),
	        'windows' => array(
	            'pattern' => '/(.+)\s+(.+)\s+((<DIR>)|[0-9]+)\s+(.+)/',
	            'map'     => array('name'=>5,'date'=>1,'is_dir'=>3)
	        )
	    );
	var $_asciiExtensions = array('css', 'html', 'php', 'txt', 'xml');


	function Toucan_Util_Net_FTP($props)
	{
		$this->_server   = $this->_getPropDefault($props, "server");
		$this->_username = $this->_getPropDefault($props, "username");
		$this->_password = $this->_getPropDefault($props, "password");
		$this->_port     = $this->_getPropDefault($props, "port", 21);
	}
	
	function setServer($server) 
	{
		$this->_server = $server;	
	}
	
	function getServer()
	{
		return $this->_server;
	}
	
	function setUsername($username)
	{
		$this->_username = $username;
	}
	
	function getUsername()
	{
		return $this->_username;
	}
	
	function setPassword($password)
	{
		$this->_password = $password;
	}
	
	function getPassword()
	{
		return $this->_password;
	}	
	
	function setPort($port)
	{
		$this->_port = $port;
	}
	
	function getPort()
	{
		return $this->_port;
	}		
	
	function connect()
	{
		$this->_resource = ftp_connect($this->_server, $this->_port);
		
		if (!$this->_resource) {
			$this->error("Could not connect to FTP server {$this->_server}, port {$this->_port}");
		}

		$result = ftp_login($this->_resource, $this->_username, $this->_password);
		
		if (!$result) {
			$this->error("Failed to login to FTP server");
		}
		
		$this->_progress("Logged in as {$this->_username}@{$this->_server}");
	}
	
	function ensureConnection()
	{
		if (!$this->_resource) {
			$this->connect();
		}
	}	
	
	function close()
	{
		$this->ensureConnection();
		
		ftp_close($this->_resource);
		$this->_resource = false;	
	}
	
	function chDir($dir) 
	{
		$this->ensureConnection();
		
		if (!@ftp_chdir($this->_resource, $dir)) {
			$this->error("Could not change FTP directory to $dir");
		} else {
			$this->_progress("Changed FTP directory to $dir");
		}
	}
	
	function put($localFile, $serverFile, $mode="useExtension")
	{
		$this->ensureConnection();
		
		if ($mode == "ascii") {
			$ftpMode = FTP_ASCII;
		} else if ($mode == "binary") {
			$ftpMode = FTP_BINARY;	
		} else {
			if (in_array(Toucan_Lib_FileSystem::getExtension($localFile),
			             $this->_asciiExtensions)) {
			 	$ftpMode = FTP_ASCII;
			} else {
				$ftpMode = FTP_BINARY;
			}
		}
		
		$ftpModeStr = ($ftpMode == FTP_ASCII) ? 'ascii' : 'binary';
		$this->_progress("Putting local file $localFile on server (as $serverFile), ftp mode {$mode}/{$ftpModeStr}");
		$result = @ftp_put($this->_resource, $serverFile, $localFile, $ftpMode);
		
		if ($result === false) {
			$this->error("Could not put local file $localFile on server (as $serverFile)");	
		}		
	}
	
	function delete($item, $recursive=true)
	{
		$this->ensureConnection();
		$isDir = strrpos($item, "/") == (strlen($item)-1);
		
		if ($isDir) {
			$dir = Toucan_Lib_FileSystem::canonicalDirName($item);
			
			if ($recursive) {
				$contents = $this->ls($dir);
				
				foreach(array_keys($contents['files']) as $file) {
					$this->delete($dir.$file);	
				}
				
				foreach(array_keys($contents['dirs']) as $subDir) {
					$this->delete(Toucan_Lib_FileSystem::canonicalDirName($dir.$subDir));
				}
			}
			
			$this->_progress("Deleting directory $item");
			$result = @ftp_rmdir($this->_resource, $item);
			if ($result === false) {
				$this->error("Could not delete directory $item");	
			} 
			
		} else {
			$this->_progress("Deleting $item");
			$result = @ftp_delete($this->_resource, $item);
			if ($result === false) {
				$this->error("Could not delete file $item");	
			}						
		}
	}
	
	function rmDir($dir, $recursive=true)
	{
		$this->delete(Toucan_Lib_FileSystem::canonicalDirName($dir), $recursive);
	}
	
	function mkDir($dirName)
	{	
		$this->ensureConnection();
		
		$this->_progress("Making directory $dirName");
		$result = @ftp_mkdir($this->_resource, $dirName);
		if ($result === false) {
			$this->error("Could not make directory $dirName");	
		}	
	}
	
	function _progress($str)
	{
		print "$str <br />";
		flush(); 
	}
	
	function _ensureMatcher($dirList)
	{
		if (!$this->_matcher) {
			foreach ($dirList as $entry) {
			    foreach ($this->_lsMatch as $os => $match) {
			        if (preg_match($match['pattern'], $entry)) {
		            	$this->_matcher = $match;
		            	return;
		            }
		        }
			}	
			
			$this->error("Could not parse directory listing - your OS appears to be unsupported");
		}
	}
	
    function ls($dir, $retrieveHidden=true, $ignoreCurrentAndParentDirs=true)
    {
    	$this->ensureConnection();
    	
        $dirsList  = array();
        $filesList = array();
        
        if ($retrieveHidden) {
        	$dir = "-a {$dir}";
        }
        
        $dirList   = @ftp_rawlist($this->_resource, $dir);
                      
        if ($dirList === false) {
            $this->error("Could not get FTP directory listing for $dir");
        }
         
        if (sizeof($dirList) > 0) {       
	        $this->_ensureMatcher($dirList);
	                
	        foreach ($dirList as $entry) {
	        	$matches = array();
	            if (!preg_match($this->_matcher['pattern'], $entry, $matches)) {
	                continue;
	            }
	            $entry = array();
	            
	            foreach ($this->_matcher['map'] as $key=>$val) {
	                $entry[$key] = $matches[$val];
	            }
	            
	            $entry['timestamp'] = $this->_parseDate($entry['date']);
	
	            if ($entry['is_dir']) {
	            	if ($ignoreCurrentAndParentDirs && $entry['name'] != '.' && $entry['name'] != '..') {
	                	$dirsList[$entry['name']] = $entry;
	            	}
	            } else {
	                $filesList[$entry['name']] = $entry;
	            }
	        }
        }
        
        $res["dirs"] = $dirsList;
        $res["files"] = $filesList;
        
        return $res;
    }	
    
    function _parseDate($date)
    {
        // Sep 10 22:06 => Sep 10, <year> 22:06
        if (preg_match('/([A-Za-z]+)[ ]+([0-9]+)[ ]+([0-9]+):([0-9]+)/', $date, $res)) {
            $year = date('Y');
            $month = $res[1];
            $day = $res[2];
            $hour = $res[3];
            $minute = $res[4];
            $date = "$month $day, $year $hour:$minute";
            $tmpDate = strtotime($date);
            if ($tmpDate > time()) {
                $year--;
                $date = "$month $day, $year $hour:$minute";
            }
        }
        // 09-10-04 => 09/10/04
        else if (preg_match('/^\d\d-\d\d-\d\d/',$date)) {
            $date = str_replace('-','/',$date);
        }
        
        $res = strtotime($date);
        
        if (!$res) {
            $this->error("Date conversion failed when parsing directory. Date: $date");
        }
        
        return $res;    	
    }
}

?>