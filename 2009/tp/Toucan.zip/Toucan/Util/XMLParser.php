<?php

class Toucan_Util_XMLParser extends Toucan
{
	var $_tags;
	var $_tagData;	
	var $_data;
	var $_openTags;
		
	function Toucan_Util_XMLParser($props)
	{
		$file = $this->_getProp($props, "file");
		$tags = $this->_getPropDefault($props, "tags", array());
		
		$this->_tags = array();
		foreach($tags as $tag) {
			$this->_tags[] = strtoupper($tag);
		}
		
		$this->_tagData = array();
		$this->_data = '';
		$this->_openTags = array();
		
		$xmlParser = xml_parser_create();
		xml_set_element_handler($xmlParser, 
								array(&$this, "_startElement"), 
								array(&$this, "_endElement"));
		
		xml_set_character_data_handler ($xmlParser, array(&$this, "_elementData"));
		
		if (!($resource = @fopen($file, "r"))) {
		   $this->error("Could not open file {$file}");
		}
		
		while ($data = fread($resource, 4096)) {
		   if (!xml_parse($xmlParser, $data, feof($resource))) {
		   		$error = xml_error_string(xml_get_error_code($xmlParser));
		   		$line  = intval(xml_get_current_line_number($xmlParser));
		        
		        $this->warning("XML error in {$file}: {$error} at line {$line}\n");
		        break;
		   }  
		}
		
		xml_parser_free($xmlParser);	
		if (!@fclose($resource)) {
			$this->warning("Could not close file {$file}");	
		}
	}	
	
	function _startElement($xmlParser, $name, $attribs)
	{
		$this->_openTags[] = array('name'=>$name, 'attribs'=>$attribs, 'data'=>'');
	}
	
	function _endElement($xmlParser, $name)
	{
		$lastTag = array_pop($this->_openTags);
		if (in_array($name, $this->_tags)) {
			$this->_tagData[] = $lastTag;
		} else {
			if (trim($lastTag['data']) != '') {
				$this->_data .= $lastTag['data'].' ';
			}
		}
	}

	function _elementData($xmlParser, $data)
	{
		if ($data != '') {	
			$lastTag = array_pop($this->_openTags);
			$lastTag['data'] .= $data;
			$this->_openTags[] = $lastTag;
		}
	}

	function getTagData()
	{
		return $this->_tagData;
	}
	
	function getData()
	{
		return $this->_data;
	}
}

?>