<?php

Toucan::load("Toucan_Lib_Util");
Toucan::load("Toucan_Lib_Sys");
Toucan::load("Toucan_Presentation");

class Toucan_Form extends Toucan_Presentation
{
	var $_name;
	var $_method;
	var $_targetURL;

	var $_fields;
	var $_buttons;
	var $_matrices;
	
	var $_defaultButtonName;
	var $_saveFormValuesToState;

	function Toucan_Form($props)
	{
		parent::Toucan_Presentation($props);

		$this->_name      = $this->_getProp($props, 'name');
		$this->_method    = strtolower($this->_getPropDefault($props, 'method', 'post'));
		$this->_targetURL = $this->_getPropDefault($props, 'targetURL', Toucan_Lib_Sys::getRequestURL());
		
		$this->_defaultButtonName
					   = $this->_getPropDefault($props, 'defaultButtonName');
		$this->_saveFormValuesToState
		               = $this->_getPropDefault($props, 'saveFormValuesToState');

		if ($this->_getPropDefault($props, 'jumpToForm')) {
			$this->_targetURL .= "#{$this->_name}";
		} else if ($this->_getPropDefault($props, 'jumpTo')) {
			$this->_targetURL .= "#".$this->_getProp($props, 'jumpTo');	
		}

		$this->_fields   = array();
		$this->_buttons  = array();
		$this->_matrices = array();

		$this->setLayout($this->_getPropDefault($props, 'layoutProps', array()));
		
		$this->_clearSessionValues();
	}

	function setLayout($layoutProps)
	{
		$layoutProps['form'] =& $this;

		// can only add form to body
		$layoutProps['location'] = 'body';

		// default layout of form is Toucan_Presentation_Form
		$layoutProps['type'] = $this->_getPropDefault($layoutProps, 'type', 'Form');
		
		$this->clearPresentations('body');
		$this->addPresentation($layoutProps);	
	}

	/*------------  Property methods  ------------*/

	function getName()
	{
		return $this->_name;
	}

	function getMethod()
	{
		return $this->_method;
	}

	function getTargetURL() {
		if (SID == '') {
			return $this->_targetURL;
		} else {
			return $this->_targetURL .= '?'.strip_tags(SID);
		}
	}

	/*------------  Submission methods  ------------*/

	function submitted()
	{
		$sessionFieldTest   = $this->_getSubmissionCounter() !== false;
		$submittedFieldTest = $this->_getSubmittedTest() == true;

		return $sessionFieldTest && $submittedFieldTest;
	}

	function process()
	{
		$this->loadSubmittedFieldValues();
		$this->processSubmission();
		$this->saveFormValuesToState();
	}

	function loadSubmittedFieldValues()
	{
		if ($this->submitted()) {
			$fieldNames = array_keys($this->_fields);
			foreach($fieldNames as $fieldName) {
		
				// this should be moved into each individual field?
		
				$field = &$this->getField($fieldName);
						
				if (is_a($field, "Toucan_Form_Field_FileUpload")) {
					$field->setValue($_FILES[$fieldName]);
				} else {
					$value = $this->_page->getRequestValue($fieldName);
		
					if ($value != NULL) {
						if (get_magic_quotes_gpc()) {
							$value = stripslashes($value);
						}
					}
					$field->setValue($value);
				}
			}
		}
	}

	function processSubmission()
	{
		if ($this->submitted()) {
			
			if ($this->valid()) {
				$this->_incrementSubmissionCounter();
				$this->_processButtons($this->_getSubmissionCase());
				$this->_processButtons('valid');
				$this->_setLastSubmissionDigest();
			} else {
				$this->_processButtons('invalid');
			}
			$this->_processButtons('any');
		} else {
			$this->_clearSessionValues();
		}		
	}

	function _processButtons($submissionCase)
	{
		$processed = false;
		$buttonNames = array_keys($this->_buttons);
		foreach ($buttonNames as $buttonName) {
			$button = &$this->getButton($buttonName);
			if ($this->_page->getRequestValue($button->getName())) {
				$button->process($submissionCase);
				$processed = true;
				break;
			}
		}		

		$defaultButton = &$this->getDefaultButton();
		if (!$processed && $defaultButton != null) {
			$defaultButton->process($submissionCase);
		}
	}

	function saveFormValuesToState()
	{
		if ($this->_saveFormValuesToState) {

			$fieldNames = array_keys($this->_fields);

			foreach ($fieldNames as $fieldName) {
				$field = &$this->getField($fieldName);
				$value = $field->getValue();
				$this->_page->setStateValue($fieldName, $value);
			}

			$this->_page->setStateValue(
					$this->_getSubmittedTestFieldName(), true);
		}
	}

	function _getSubmissionCase()
	{
		if ($this->_getSubmissionCounter() == 1) {
			return 'new';
		} else if ($this->_getSubmissionCounter() > 1) {
			if ($this->_getLastSubmissionDigest() == $this->_getSubmissionDigest()) {
				return 'prev';
			} else {
				return 'diff';
			}
		} else {
			return 'none';
		}
	}

	function valid()
	{
		$fieldNames = array_keys($this->_fields);

		foreach ($fieldNames as $fieldName) {
			$field =& $this->getField($fieldName);
			if (!$field->valid()) {
				return false;
			}
		}

		return true;
	}

	/*------------  Field Matrix methods  ------------*/

	function &addMatrix($props)
	{
		$props['form'] = &$this;
		$props['page'] = &$this->_page;
		
		if (!isset($props['name'])) {
			$this->error("No name set for matrix in Toucan_Form::addMatrix()");	
		}
		
		$matrix =& $this->create("Toucan_Form_Matrix", $props);
		$this->_matrices[$props['name']] =& $matrix;
		return $matrix;
	}

	function &getMatrices() 
	{
		return $this->_matrices;
	}
	
	/*------------  Button methods  ------------*/

	function &addButton($props)
	{
		if (!is_array($props)) {
			$props = Toucan_Lib_Util::coerceArray($props, 'name');
		}

		if (!isset($props['page'])) {
			$props['page'] = &$this->_page;
		}

		$button =& $this->create('Toucan_Form_Button', $props);
		$this->_buttons[$button->getName()] =& $button;

		if (!$this->_defaultButtonName) {
			$this->_defaultButtonName = $button->getName();
		}

		return $button;
	}

	function &getButton($name)
	{
		return $this->_buttons[$name];
	}

	function getButtons()
	{
		return $this->_buttons;
	}

	function &getDefaultButton()
	{
		if ($this->_defaultButtonName) {
			return $this->_buttons[$this->_defaultButtonName];
		} else {
			return NULL;
		}
	}

	/*------------  Field methods  ------------*/

	function &addField($props)
	{	
		if (!isset($props['type'])) {
			$this->error("No type set for field to be added in Toucan_Form::addField", $props);
		}

		$type = $props['type'];

		if (strpos($type, 'Toucan') !== 0 && strpos($type, 'Proj') !== 0) {
			$type = "Toucan_Form_Field_{$type}";
		}

		$props['form'] =& $this;
		if (!isset($props['page'])) {
			$props['page'] = &$this->_page;
		}
	
		$field =& $this->create($type, $props);
	
		$this->_fields[$field->getName()] =& $field;

		return $field;
	}

	function addFields($fields) 
	{
		foreach ($fields as $field) {
			$this->addField($field);			
		}					
	}

	function &getField($name)
	{
		return $this->_fields[$name];
	}

	function getFields()
	{
		return $this->_fields;
	}

	function getFieldValue($fieldName)
	{	
		$field =& $this->getField($fieldName);	
		return $field->getValue();
	}

	function getFieldValues()
	{
		$fieldValues = array();
		$fieldNames = array_keys($this->_fields);

		foreach($fieldNames as $fieldName) {
			$fieldValues[$fieldName] = $this->getFieldValue($fieldName);
		}

		return $fieldValues;
	}
	
	function &getRecordset()
	{
		$recordset =& $this->create("Toucan_Recordset_Array", 
							 array("data" => array($this->getFieldValues())));	
		return $recordset;
	}

	function _getSubmissionDigest()
	{
		return serialize($this->getFieldValues());
	}

	function clear()
	{
		$fieldNames = array_keys($this->_fields);

		foreach($fieldNames as $fieldName) {
			$field = &$this->getField($fieldName);
			$field->clear();
		}	
	}
	
	/*------------  Test field methods  ------------*/

	function _getSubmittedTestFieldName()
	{
		return "{$this->_name}Submitted";
	}

	function _getSubmittedTest()
	{
		return $this->_page->getRequestValue($this->_getSubmittedTestFieldName());
	}

	function _getSubmissionCounterSessionName()
	{
		return "{$this->_name}Counter";
	}

	function _getSubmissionCounter()
	{
		return $_SESSION[$this->_getSubmissionCounterSessionName()];
	}

	function _incrementSubmissionCounter()
	{
		$_SESSION[$this->_getSubmissionCounterSessionName()]++;
	}

	function _getLastSubmissionDigestSessionName()
	{
		return "{$this->_name}LastSubmissionDigest";
	}

	function _getLastSubmissionDigest()
	{
		return $_SESSION[$this->_getLastSubmissionDigestSessionName()];
	}

	function _setLastSubmissionDigest()
	{
		$_SESSION[$this->_getLastSubmissionDigestSessionName()] = $this->_getSubmissionDigest();
	}

	function _clearSessionValues()
	{
		$_SESSION[$this->_getSubmissionCounterSessionName()] = 0;
		$_SESSION[$this->_getLastSubmissionDigestSessionName()] = '';
	}

	/*------------  HTML methods  ------------*/

	function _generateHeaderHTML()
	{	
		$name   = $this->getName();
		$method = $this->getMethod();
		$action = $this->getTargetURL();

		$encType = "";
		
		foreach($this->_fields as $field) {
			if (is_a($field, 'Toucan_Form_Field_FileUpload')) {
				$encType = ' enctype="multipart/form-data"';
				break;		
			}
		}

		$html = "<a name=\"{$this->_name}\"></a>\n"
	          . "<form name=\"$name\" method=\"$method\" action=\"$action\"$encType>\n";

	    return $html;
	}

	function _generateFooterHTML()
	{
		$this->addField(
				array('type' => 'Hidden',
				      'name' => $this->_getSubmittedTestFieldName(),
				      'initialValue' => true));

		$this->addField(
				array('type' => 'Hidden',
				      'name' => $this->_page->getStateStringRequestName(),
				      'initialValue' => $this->_page->getStateString()));

		$matrixNames = array_keys($this->_matrices);
		foreach ($matrixNames as $matrixName) {
			$matrix =& $this->_matrices[$matrixName];
			
			$this->addField(
				array("type"  => "Hidden", 
				      "name"  => $matrix->getKeyDataRequestName(), 
				      "initialValue" => $matrix->getKeyDataString()));				      				
		}

		$html = '';

		$fieldNames = array_keys($this->_fields);

		foreach ($fieldNames as $fieldName) {
			$field =& $this->getField($fieldName);
			if (is_a($field, 'Toucan_Form_Field_Hidden')) {
				$html .= $field->getHTML() . "\n";
			}
		}

		$html .= "</form>\n";

		return $html;
	}
	
	function toString() 
	{
		return parent::toString();
	}
}
