<?php

class Toucan_Form_Button extends Toucan_Presentation
{
	var $_name;
	var $_actions;
	var $_caption;
	var $_confirm;
	var $_htmlClass;
	
	function Toucan_Form_Button($props)
	{
		parent::Toucan_Presentation($props);
		
		$this->_name      = $this->_getProp($props, 'name');
		$this->_caption   = $this->_getPropDefault($props, 'caption', 'Submit'); 
		$this->_confirm   = $this->_getPropDefault($props, 'confirm'); 
		$this->_htmlClass = $this->_getPropDefault($props, 'htmlClass');
		$this->_actions   = array();
		
		$formSubmissionTypes = array('new', 'prev', 'diff', 'valid', 'invalid', 'any');
		foreach ($formSubmissionTypes as $type) {
			$this->_actions[$type] = array();
		}
	}
	
	function getName()
	{
		return $this->_name;
	}
	
	function &addAction($props)
	{	
		$type = $this->_getProp(
				$props, 'type');
		$formSubmissionType = $this->_getPropDefault(
				$props, 'formSubmissionType', 'valid');
		
		if (strpos($type, 'Toucan') !== 0 && strpos($type, 'Proj') !== 0) {
			$type = "Toucan_Action_{$type}";
		}
	
		$action = &Toucan::create($type, $props);
		$this->_actions[$formSubmissionType][] = &$action;
		return $action;					
	}
	
	function addActions($actions) 
	{
		foreach	($actions as $action) {
			$this->addAction($action);
		}	
	}
	
	function process($formSubmissionType) 
	{
		foreach ($this->_actions[$formSubmissionType] as $action) {
			$action->process();
		}
	}
	
	function _getConfirmMessage()
	{
		if ($this->_confirm) {
			return "onclick=\"return confirm('{$this->_confirm}')\"";	
		}
	}
	
	function _generateHTML()
	{
		$confirm = $this->_getConfirmMessage();
		
		$class = $this->_htmlClass ? "class = \"{$this->_htmlClass}\" " : "";
		
		// $html= "<input name=\"{$this->_name}\" type=\"submit\" value=\"{$this->_caption}\" {$class}{$confirm} />";

		$html = <<< HTML
<button name="{$this->_name}" value="true" type="submit" {$class}{$confirm}>
{$this->_caption}
</button>
HTML;

		return $html;

	}
}

?>