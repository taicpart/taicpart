<?php

Toucan::load('Toucan_Form_Field_Text');

class Toucan_Form_Field_Currency extends Toucan_Form_Field_Text
{
	function Toucan_Form_Field_Currency($props)
	{
		$props['preUnits']   = $this->_getPropDefault($props, 'currency', '&pound;');
		$props['postUnits']  = '';
		
		if (!isset($props['validation'])) {
			$props['validation'] = array();
		}
		 
		$props['validation'][] = 'Currency';
		
		parent::Toucan_Form_Field_Number($props);
	}
}
?>