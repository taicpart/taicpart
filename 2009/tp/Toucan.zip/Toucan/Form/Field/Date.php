<?php

Toucan::load('Toucan_Lib_Validate');
Toucan::load('Toucan_Form_Field_Text');

class Toucan_Form_Field_Date extends Toucan_Form_Field_Text
{
	function Toucan_Form_Field_Date($props)
	{	
		$dateValidateOptions = $this->_getPropDefault(
				$props, 'dateValidateOptions', array());
	
		if (!isset($props['validation'])) {
			$props['validation'] = array();
		}
		
		$props['validation'][] = 
				array('type'=>'Date', 'options'=>$dateValidateOptions);
		
		parent::Toucan_Form_Field_Text($props);
	}
	
	function setValue($value)
	{	
		if ($value !='' && Toucan_Lib_Validate::isDate($value)) {
			$parts = explode('/', $value);
		
			// set day and month to required length
			for ($i=0; $i<=1; $i++) {
				$len = strlen($parts[$i]);
				if (strlen($parts[$i]) < 2) {
					$parts[$i] = str_repeat("0", 2-$len).$parts[$i];
				} 
			}
			
			$this->_value = implode('/', $parts);
		} else {
			parent::setValue($value);
		}
	}
}
?>