<?php

Toucan::load('Toucan_Form_Field');

class Toucan_Form_Field_Text extends Toucan_Form_Field
{
	var $_maxLength;
	var $_size;
	
	function Toucan_Form_Field_Text($props)
	{
		parent::Toucan_Form_Field($props);
		$this->_maxLength = $this->_getPropDefault($props, 'maxLength');	
		$this->_size      = $this->_getPropDefault($props, 'size');
	}
	
	function _generateBodyHTML() 
	{
		$maxLengthStr = "";
		if ($this->_maxLength) {
			$maxLengthStr = "maxlength=\"{$this->_maxLength}\"";
		}

		$sizeStr = "";
		if ($this->_size) {
			$sizeStr = "size=\"{$this->_size}\"";
		}
		
		return  "<input name=\"{$this->_name}\" type=\"text\" "
		      . "{$maxLengthStr} {$sizeStr} value=\"".$this->getHTMLSafeValue()."\" />";
	}
}
?>