<?php

Toucan::load('Toucan_Form_Field');

class Toucan_Form_Field_Value extends Toucan_Form_Field
{	
	function _generateBodyHTML() 
	{
		return $this->getHTMLSafeValue()
			   ."<input name=\"{$this->_name}\" type=\"hidden\" value=\""
			   .$this->getHTMLSafeValue()."\" />";
	}
}
?>