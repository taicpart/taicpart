<?php

Toucan::load('Toucan_Form_Field_Text');

class Toucan_Form_Field_Number extends Toucan_Form_Field_Text
{
	var $_preUnits;
	var $_postUnits;
	
	function Toucan_Form_Field_Number($props)
	{
		$numberValidateOptions = $this->_getPropDefault(
				$props, 'numberValidateOptions', array());
	
		if (!isset($props['validation'])) {
			$props['validation'] = array();
		}
		
		$props['validation'][] = 
				array('type'=>'Number', 'options'=>$numberValidateOptions);		
		
		parent::Toucan_Form_Field_Text($props);
		$this->_preUnits  = $this->_getPropDefault($props, 'preUnits');
		$this->_postUnits = $this->_getPropDefault($props, 'postUnits');
	}
		
	function _generateBodyHTML() 
	{
		return "{$this->_preUnits}".parent::_generateBodyHTML()."{$this->_postUnits}";
	}
}
?>