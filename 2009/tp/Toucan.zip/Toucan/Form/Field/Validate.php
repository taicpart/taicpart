<?php

Toucan::load("Toucan_Lib_Validate");

class Toucan_Form_Field_Validate extends Toucan
{	
	var $_field;
	var $_message;
	
	function Toucan_Form_Field_Validate($props)
	{	
		$this->_field   =& $this->_getProp($props, 'field');
		$this->_message =  $this->_getPropDefault($props, 'message');
	}
	
	function _passedValidate()
	{
		Toucan::error("_validateField() must be overridden in ".get_class($this));	
	}
	
	function process()
	{
		if ($this->_passedValidate()) {
			return '';
		} else {
			return $this->_message;
		}
	}
}

?>