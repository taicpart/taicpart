<?php

Toucan::load('Toucan_Form_Field');

class Toucan_Form_Field_FileUpload extends Toucan_Form_Field
{
	var $_maxFileSize;
	
	function Toucan_Form_Field_FileUpload($props) 
	{
		parent::Toucan_Form_Field($props);
		$this->_maxFileSize = 
			$this->_getPropDefault($props, 'maxFileSize', 50000);
	}
	
	function _generateBodyHTML() 
	{
$html = <<< HTML
	<input type="hidden" name="MAX_FILE_SIZE" value="{$this->_maxFileSize}" />
	<input name="{$this->_name}" type="file" />
HTML;
		return $html;
	}
}
?>