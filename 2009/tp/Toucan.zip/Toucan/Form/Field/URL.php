<?php	

Toucan::load('Toucan_Form_Field_Value');

class Toucan_Form_Field_URL extends Toucan_Form_Field_Value
{	
	var $_startURL;
	var $_endURL;
	var $_target;
	var $_anchorText;
	
	function Toucan_Form_Field_URL($props)
	{
		parent::Toucan_Form_Field_Value($props);
		
		$this->_startURL   = $this->_getPropDefault($props, "startURL");
		$this->_endURL     = $this->_getPropDefault($props, "endURL");
		$this->_target     = $this->_getPropDefault($props, "target");
		$this->_anchorText = $this->_getPropDefault($props, "anchorText");
	}
	
	function _generateBodyHTML() 
	{
		$targetHTML = "";
		if ($this->_target) {
			$targetHTML = "target=\"{$this->_target}\"";
		}
		
		$url = $this->_startURL.$this->getHTMLSafeValue().$this->_endURL;
		
		$anchorText = $url;
		if ($this->_anchorText) {
			$anchorText = $this->_anchorText;
		}
		
		$html = "<a href=\"{$url}\" {$targetHTML}>{$anchorText}</a>"
			  . "<input name=\"{$this->_name}\" type=\"hidden\" value=\""
			  . $this->getHTMLSafeValue()."\" />";
			  
		return $html;
	}
}
?>