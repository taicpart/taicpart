<?php

Toucan::load('Toucan_Form_Field_Validate');

class Toucan_Form_Field_Validate_Unique extends Toucan_Form_Field_Validate
{	
	var $_usedValues;
	var $_ignoreField;
	
	function Toucan_Form_Field_Validate_Unique($props)
	{
		parent::Toucan_Form_Field_Validate($props);
		$recordset      =  $this->_getProp($props, 'recordset');
		$recordsetField =  $this->_getProp($props, 'recordsetField');
		$this->_ignoreField  =& $this->_getPropDefault($props, 'ignoreField');
		
		$this->_usedValues = array();
		$recordset->moveToFirst();
		while ($recordset->hasNext()) {
			$row = $recordset->nextRecord();
			$this->_usedValues[] = $row[$recordsetField];
		}
		
		$this->_message =  $this->_getPropDefault($props, 'message', 'Please enter a unique value');
	}	
	
	function _passedValidate()
	{					
		if (in_array($this->_field->getValue(), $this->_usedValues)) {
			if ($this->_ignoreField) {				
				return $this->_field->getValue() 
						== $this->_ignoreField->getValue();
			} else {
				return false;
			}
		} else {
			return true;
		}
	}
}
?>