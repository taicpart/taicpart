<?php
Toucan::load('Toucan_Form_Field_Validate');

class Toucan_Form_Field_Validate_EmailAddress extends Toucan_Form_Field_Validate
{	
	var $_checkDomain;
	var $_allowNull;
	
	function Toucan_Form_Field_Validate_EmailAddress($props)
	{
		parent::Toucan_Form_Field_Validate($props);
		
		$this->_message =  $this->_getPropDefault(
				$props, 'message', 'Please enter a valid email address');	
					
		$this->_checkDomain = $this->_getPropDefault(
				$props, 'checkDomain', true);
				
		$this->_allowNull = $this->_getPropDefault(
				$props, 'allowNull', true);
	}
	
	function _passedValidate()
	{
		if ($this->_field->getValue()=="" && $this->_allowNull) {
			return true;
		} else {
			return Toucan_Lib_Validate::isEmailAddress(
				$this->_field->getValue(), $this->_checkDomain);
		}
	}
}

?>