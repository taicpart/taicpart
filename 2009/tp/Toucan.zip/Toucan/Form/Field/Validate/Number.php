<?php
Toucan::load('Toucan_Form_Field_Validate');

class Toucan_Form_Field_Validate_Number extends Toucan_Form_Field_Validate
{	
	var $_minPrecision;
	var $_maxPrecision;
	var $_min;
	var $_max;
	var $_allowNull;
	
	function Toucan_Form_Field_Validate_Number($props)
	{
		parent::Toucan_Form_Field_Validate($props);
		
		$this->_message       =  $this->_getPropDefault($props, 'message', 'Please enter a valid number');
		$this->_minPrecision  = $this->_getPropDefault($props, 'minPrecision', null);		
		$this->_maxPrecision  = $this->_getPropDefault($props, 'maxPrecision', null);		
		
		$precision = $this->_getPropDefault($props, 'precision', null);		
		if ($precision) {
			$this->_minPrecision = $precision;
			$this->_maxPrecision = $precision;
		}
		
		$this->_min           =  $this->_getPropDefault($props, 'min', null);		
		$this->_max           =  $this->_getPropDefault($props, 'max', null);		
		$this->_allowNull     =  $this->_getPropDefault($props, 'allowNull');
	}
	
	function _passedValidate()
	{
		return ($this->_allowNull && $this->_field->getValue() == "") || 
			   (Toucan_Lib_Validate::isNumber(
					$this->_field->getValue(), $this->_min, $this->_max,
					$this->_minPrecision, $this->_maxPrecision));
	}
}

?>