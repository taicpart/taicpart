<?php
Toucan::load('Toucan_Form_Field_Validate');

class Toucan_Form_Field_Validate_Date extends Toucan_Form_Field_Validate
{	
	var $_allowNull;
		
	function Toucan_Form_Field_Validate_Date($props)
	{
		parent::Toucan_Form_Field_Validate($props);		
				
		$this->_message   = $this->_getPropDefault($props, 'message', 
			"Please enter a valid date in the form dd/mm/yyyy");	
			
		$this->_allowNull = $this->_getPropDefault($props, 'allowNull', false);
	}
	
	function _passedValidate()
	{						
		if ($this->_field->getValue() == '' && $this->_allowNull) {
			return true;
		}			
		
		return Toucan_Lib_Validate::isDate($this->_field->getValue());
	}
}

?>