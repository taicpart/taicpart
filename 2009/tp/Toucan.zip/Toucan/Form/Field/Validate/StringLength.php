<?php

Toucan::load('Toucan_Form_Field_Validate');

class Toucan_Form_Field_Validate_StringLength extends Toucan_Form_Field_Validate
{	
	var $_min;
	var $_max;
	
	function Toucan_Form_Field_Validate_StringLength($props)
	{
		parent::Toucan_Form_Field_Validate($props);
		
		$this->_min    = $this->_getPropDefault($props, 'min');
		$this->_max    = $this->_getPropDefault($props, 'max');
		
		$defaultMessage = '';
		if ($this->_min && !$this->_max) {
			$defaultMessage = "Please enter at least {$this->_min} characters";	
		} else if (!$this->_min && $this->_max) {
			$defaultMessage = "Please enter a maximum of {$this->_max} characters";	
		} else {
			$defaultMessage = "Please enter between {$this->_min} and {$this->_max} characters";	
		}
				
		$this->_message = $this->_getPropDefault($props, 'message', $defaultMessage);
		$this->_trim    = $this->_getPropDefault($props, 'trim', true);
	}	
	
	function _passedValidate()
	{
		return Toucan_Lib_Validate::stringLength($this->_field->getValue(), $this->_max, $this->_min);
	}
}
?>