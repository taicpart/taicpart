<?php

Toucan::load('Toucan_Form_Field_Validate');

class Toucan_Form_Field_Validate_NotNull extends Toucan_Form_Field_Validate
{	
	var $_trim;
	
	function Toucan_Form_Field_Validate_NotNull($props)
	{
		parent::Toucan_Form_Field_Validate($props);
		
		$this->_message = $this->_getPropDefault($props, 'message', 'Please enter a value');
		$this->_trim    = $this->_getPropDefault($props, 'trim', true);
	}	
	
	function _passedValidate()
	{
		return Toucan_Lib_Validate::notNull($this->_field->getValue(), $this->_trim);
	}
}

?>