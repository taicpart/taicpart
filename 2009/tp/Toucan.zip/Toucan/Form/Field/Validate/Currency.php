<?php
Toucan::load('Toucan_Form_Field_Validate_Number');

class Toucan_Form_Field_Validate_Currency extends Toucan_Form_Field_Validate_Number
{		
	function Toucan_Form_Field_Validate_Currency($props)
	{
		$props['precision'] = 2;
		
		parent::Toucan_Form_Field_Validate_Number($props);
		
		$this->_message =  $this->_getPropDefault(
				$props, 'message', 'Please enter a valid amount (including pence)');		
	}	
}

?>