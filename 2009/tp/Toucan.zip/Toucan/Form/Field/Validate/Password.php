<?php

Toucan::load('Toucan_Form_Field_Validate');
Toucan::load('Toucan_Lib_SimpleEncrypt');

class Toucan_Form_Field_Validate_Password extends Toucan_Form_Field_Validate
{	
	var $_userField;
	var $_usersRecordset;
	var $_passEncrypted;
	function Toucan_Form_Field_Validate_Password($props)
	{
		parent::Toucan_Form_Field_Validate($props);
		
		$this->_message         =  $this->_getPropDefault($props, 'message', 'Login failed');
		$this->_userField       =& $this->_getProp($props, 'userField');
		$this->_usersRecordset  =& $this->_getProp($props, 'usersRecordset');
		$this->_passEncrypted   =  $this->_getPropDefault($props, 'passEncrypted');
	}	
	
	function _passedValidate()
	{
		$this->_usersRecordset->moveToFirst();
		while ($this->_usersRecordset->hasNext()) {
			$user = $this->_usersRecordset->nextRecord();
		
			if ($user['user'] == $this->_userField->getValue()) {
				$correctPassword = $user['password'];
				
				if ($this->_passEncrypted) {
					$correctPassword = 
							Toucan_Lib_SimpleEncrypt::decrypt($correctPassword, 
											   				  TOUCAN_PASSWORD_KEY);
				}				
				
				return ($this->_field->getValue() == $correctPassword);
			}
		}
		return false;
	}
}

?>