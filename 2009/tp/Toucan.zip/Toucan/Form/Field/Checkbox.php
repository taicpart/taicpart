<?php

Toucan::load('Toucan_Form_Field');

class Toucan_Form_Field_Checkbox extends Toucan_Form_Field
{		
	function getValue()
	{
		if ($this->_value) {
			return true;
		} else {
			return false;
		}
	}
	
	function _generateBodyHTML() 
	{	
		$onOrOff = ($this->getValue()) ? 'checked = "checked"' : '';

		return  "<input name=\"{$this->_name}\" type=\"hidden\" value=\"\" />\n"
		       ."<input name=\"{$this->_name}\" type=\"checkbox\" {$onOrOff} />";
	}
}

?>