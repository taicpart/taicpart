<?php

Toucan::load('Toucan_Form_Field');

class Toucan_Form_Field_TextArea extends Toucan_Form_Field
{
	var $_rows;
	var $_cols;
	
	function Toucan_Form_Field_TextArea($props)
	{
		parent::Toucan_Form_Field($props);
		$this->_rows = $this->_getPropDefault($props, "rows", 5);
		$this->_cols = $this->_getPropDefault($props, "cols", 50);
	}
	
	function _generateBodyHTML() 
	{	
		return "<textarea name=\"{$this->_name}\" rows=\"{$this->_rows}\" cols=\"{$this->_cols}\">"
			   .$this->getHTMLSafeValue()."</textarea>";
	}
}

?>