<?php

Toucan::load('Toucan_Form_Field_Value');

class Toucan_Form_Field_NextID extends Toucan_Form_Field_Value
{	
	function Toucan_Form_Field_NextID($props)
	{
		parent::Toucan_Form_Field_Value($props);
		
		$db 	 =& $this->_getProp($props, 'db');
		$idField =  $this->_getPropDefault($props, 'idField', $this->getName());
		$table   =  $this->_getProp($props, 'table');
		
		$nextIDRecordset = Toucan::create("Toucan_Recordset_Database",
				array("db"    => &$db,
				      "query" => array("fields" => 
				      		array(array("field" => "MAX({$idField})+1",
				      		  			"as"    => "nextid")),
			                      "tables" => $table)));
		
		$row = $nextIDRecordset->nextRecord();
		if ($row['nextid']) {
			$this->_value = $row['nextid'];
		} else {
			$this->_value = 1;		
		}
	}
}
?>