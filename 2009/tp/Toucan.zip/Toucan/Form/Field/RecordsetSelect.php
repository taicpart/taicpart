<?php

Toucan::load('Toucan_Form_Field_Select');

class Toucan_Form_Field_RecordsetSelect extends Toucan_Form_Field_Select
{	
	function Toucan_Form_Field_RecordsetSelect($props)
	{
		$props['options'] = array();
		$recordset = &$props['recordset'];	
		$valueField = $props['valueField'];
		
		$recordset->moveToFirst();
		
		if (isset($props['captionFields'])) {
			$captionFields = $props['captionFields'];
			
			while ($recordset->hasNext()) {
				$row = $recordset->nextRecord();
				$option = array();
				$option['value'] = $row[$valueField];
				if (is_array($captionFields)) {
					$sep = $this->_getPropDefault($props, 'captionSeparator', ' ');	
					$caption = '';
					$first = true;
					foreach($captionFields as $captionField) {
						if ($first) {
							$first = false;
						} else {
							$caption .= $sep;	
						}
						$caption .= $row[$captionField];
					}
					$option['caption'] = $caption;
				} else {
					$option['caption'] = $row[$captionFields];
				}
				
				$props['options'][] = $option;
			}
		} else if (isset($props['captionCallBack'])) {
			$callback = $props['captionCallBack'];

			while ($recordset->hasNext()) {
				$row = $recordset->nextRecord();
				$option['value'] = $row[$valueField];
				
				if (is_array($callback)) {
					$option['caption'] = $callback[0]->$callback[1]($row);
				} else {
					$option['caption'] = $callback($row);
				}
				$props['options'][] = $option;
			}
		} else {
			while ($recordset->hasNext()) {
				$row = $recordset->nextRecord();
				$option['value'] = $row[$valueField];
				$option['caption'] = $row[$valueField];
				$props['options'][] = $option;
			}
		}
		
		parent::Toucan_Form_Field_Select($props);
	}
}
?>