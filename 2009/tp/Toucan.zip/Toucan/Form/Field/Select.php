<?php

Toucan::load('Toucan_Form_Field');

class Toucan_Form_Field_Select extends Toucan_Form_Field
{
	var $_options;
	var $_nullOption;
	var $_maxCaptionLength;
	
	function Toucan_Form_Field_Select($props)
	{
		parent::Toucan_Form_Field($props);
		$this->_options          = $this->_getProp($props, 'options');
		$this->_nullOption       = $this->_getPropDefault($props, 'nullOption');
		$this->_maxCaptionLength = $this->_getPropDefault($props, 'maxCaptionLength', 75);
	}
	
	function _generateOptionHTML($option)
	{
		$html = "<option value=\"".htmlspecialchars($option['value'])."\"";

		if ($option['value'] == $this->getValue()) {
			$html .= ' selected="selected"';
		}
		$caption = $option['caption'];
		if (strlen($caption) > $this->_maxCaptionLength) {
			$caption = substr($caption, 0, $this->_maxCaptionLength) . "...";
		}
		
		$html .= ">".htmlspecialchars($caption)."</option>";		
		return $html;
	}
	
	function _generateBodyHTML() 
	{
		$html = "<select name=\"{$this->_name}\">";
		
		if ($this->_nullOption) {
			$html .= $this->_generateOptionHTML(
				array("value"=>"", "caption" => $this->_nullOption));
		}
		
		foreach ($this->_options as $option) {
			if ($option['value'] != "") {
				$html .= $this->_generateOptionHTML($option);
			}
		}
		
		$html .= '</select>';

		return $html;
	}
}
?>