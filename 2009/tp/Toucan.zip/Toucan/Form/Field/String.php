<?php

Toucan::load('Toucan_Form_Field_Text');

class Toucan_Form_Field_String extends Toucan_Form_Field_Text
{
	function Toucan_Form_Field_String($props)
	{
		$maxLength = $this->_getProp($props, 'maxLength');
		
		if (!isset($props['validation'])) {
			$props['validation'] = array();	
		}	
		
		if (!is_array($props['validation'])) {
			$props['validation'] = array($props['validation']);	
		}
		
		$props['validation'][] =
				array('type'=>'StringLength', 
				      'options'=>array("max"=>$maxLength));
				
		parent::Toucan_Form_Field_Text($props);	
	}
}
?>