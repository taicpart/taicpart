<?php

Toucan::load('Toucan_Form_Field');

class Toucan_Form_Field_Hidden extends Toucan_Form_Field
{
	function _generateBodyHTML() 
	{
		return "<input name=\"{$this->_name}\" type=\"hidden\" value=\""
			   .$this->getHTMLSafeValue()."\" />";
	}
}
?>