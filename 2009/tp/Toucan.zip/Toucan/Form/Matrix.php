<?php

Toucan::load("Toucan_Lib_Validate");
Toucan::load("Toucan_Lib_SimpleEncrypt");

class Toucan_Form_Matrix extends Toucan
{
	var $_name;
	var $_form;
	var $_page;
	var $_numRows;

	var $_fieldNames;
	var $_buttonNames;

	var $_keyNames;
	var $_keyData;

	var $_recordset;

	function Toucan_Form_Matrix($props)
	{
		$this->_name     =  $this->_getProp($props, 'name');
		$this->_form     =& $this->_getProp($props, 'form');
		$this->_page     =  $this->_getProp($props, 'page');
		$this->_numRows  =  $this->_getProp($props, 'numRows');
		$this->_keyNames =  $this->_getPropDefault($props, 'keys', array());

		$this->_keyData = array();
		foreach($this->_keyNames as $key) {
			$this->_keyData[$key] = array();
		}

		$this->_fieldNames  = array();
		$this->_buttonNames = array();
	}

	function getNumRows()
	{
		return $this->_numRows;
	}

	function getFieldNames()
	{
		return $this->_fieldNames;	
	}
	
	function getButtonNames()
	{
		return $this->_buttonNames;
	}

	function getData($checkField = false)
	{
		$data = array();
		$encodedData = $this->_page->getRequestValue($this->getKeyDataRequestName());

		if ($encodedData) {
			$serializedKeyData = Toucan_Lib_SimpleEncrypt::decrypt($encodedData, TOUCAN_STATE_KEY);	
			$keyData = unserialize($serializedKeyData); 

			$endButtonPressed = false;
			foreach ($this->_buttonNames as $buttonName) {
				$buttonPressed = $this->_page->getRequestValue($buttonName);

				if ($buttonPressed) {
					$endButtonPressed = true;
					break;
				}
			}

			for ($rowNo=1; $rowNo <= $this->_numRows; $rowNo++) {
				$rowButtonPressed = false;
				if (!$endButtonPressed) {
					foreach ($this->_buttonNames as $buttonName) {

						$buttonPressed = $this->_page->getRequestValue(
								$this->_getRowName($buttonName, $rowNo));

						if ($buttonPressed) {
							$rowButtonPressed = true;
							break;
						}
					}
				}

				if ($endButtonPressed || $rowButtonPressed) {

					$error = false;
					$row = array();
					foreach ($this->_keyNames as $keyName) {
						if (isset($keyData[$keyName][$rowNo])) {
							$row[$keyName] = $keyData[$keyName][$rowNo];
						} else {
							$error = true;
						}
					}

					foreach ($this->_fieldNames as $fieldName) {
						$rowFieldName = $this->_getRowName($fieldName, $rowNo);
						$field =& $this->_form->getField($rowFieldName);
						$row[$fieldName] = $field->getValue();
					}

					if (!$error) {
						if (!$rowButtonPressed && $checkField) {
							if ($row[$checkField]) {
								$data[] = $row;
							}
						} else {
							$data[] = $row;
						}
					}
				}
			}
		}
		return $data;
	}

	function &getRecordset($checkField = false)
	{
		$recordset =& $this->create("Toucan_Recordset_Array", 
		            		array("data" => $this->getData($checkField)));
		return $recordset;
	}

	function setDataUsingRecordset(&$recordset) 
	{
		$rowNo = 1;
		while ($recordset->hasNext()) {
			$row = $recordset->nextRecord();
			foreach ($this->_fieldNames as $fieldName) {
				$field =& $this->getRowField($fieldName, $rowNo);
				if (isset($row[$fieldName])) {
					$field->setValue($row[$fieldName]);
				} 
			}
			$rowNo ++;	
		}
	}
	

	function addField($props)
	{
		if (!isset($props['name'])) {
			$this->error("No name set for field to be added to Toucan_Form_Matrix::addField");
		}

		$name = $props['name'];
		$this->_fieldNames[] = $name;

		for ($rowNo=1; $rowNo <= $this->_numRows; $rowNo++) {
			$props['name'] = $this->_getRowName($name, $rowNo);
			$this->_resolveValidationDependencies($props, $rowNo);		
			$this->_form->addField($props);
		}
	}

	function _resolveValidationDependencies(&$props, $rowNo)
	{
		if (isset($props['validation']) && is_array($props['validation'])) {
	
			foreach ($props['validation'] as $key => $validation) {
				
				if (isset($validation['options']['dependsOn'])) {
					$param = $validation['options']['dependsOn']['param'];	
					
					$dependsOnFieldName 
						= $validation['options']['dependsOn']['field'];	
					
					$dependsOnField =& 
						$this->_form->getField(
							$this->_getRowName($dependsOnFieldName, $rowNo));

					$props['validation'][$key]['options'][$param] 
						=& $dependsOnField;
				}
			}
		}		
	}

	function addFields($fields) 
	{
		foreach ($fields as $field) {
			$this->addField($field);			
		}		
	}

	function addButton($props)
	{
		if (!isset($props['name'])) {
			$this->error("No name set for field to be added to Toucan_Form_Matrix::addButton");
		}

		$name = $props['name'];
		$this->_buttonNames[] = $name;

		// make end button
		if (isset($props['endCaption'])) {
			$props['caption'] = $props['endCaption'];
		}
		$this->_form->addButton($props);

		// make row buttons
		for ($rowNo=1; $rowNo <= $this->_numRows; $rowNo++) {
			$props['name'] = $this->_getRowName($name, $rowNo);
			if (isset($props['rowCaption'])) {
				$props['caption'] = $props['rowCaption'];
			}
			$this->_form->addButton($props);
		}
	}

	function addActionToButton($name, $actionProps, $forRowButtons=true, $forEndButton=true)
	{
		if (!in_array($name, $this->_buttonNames)) {
			$this->_noSuchElementError($name, "button", "addActionToButton");
		}

		if ($forEndButton) {
			$button =& $this->getEndButton($name);
			$button->addAction($actionProps);
		}
	
		if ($forRowButtons) {
			for ($rowNo=1; $rowNo <= $this->_numRows; $rowNo++) {
				$button =& $this->getRowButton($name, $rowNo);
				$button->addAction($actionProps);
			}
		}
	}

	function &getRowField($name, $rowNo)
	{
		if (!in_array($name, $this->_fieldNames)) {
			$this->_noSuchElementError($name, "field", "getRowField");
		}
		$this->_checkRow($rowNo, "getRowField");

		return $this->_form->getField($this->_getRowName($name, $rowNo));
	}

	function &getRowButton($name, $rowNo)
	{
		if (!in_array($name, $this->_buttonNames)) {
			$this->_noSuchElementError($name, "button", "getRowButton");
		}
		$this->_checkRow($rowNo, "getRowButton");

		return $this->_form->getButton($this->_getRowName($name, $rowNo));
	}

	function &getEndButton($name)
	{
		if (!in_array($name, $this->_buttonNames)) {
			$this->_noSuchElementError($name, "button", "getEndButton");
		}

		return $this->_form->getButton($name);
	}

	function addRowKeyValue($keyName, $rowNo, $value)
	{
		if (!isset($this->_keyData[$keyName])) {
			$this->_noSuchElementError($keyName, "key", "addRowKey");
		}
		$this->_checkRow($rowNo, "addRowKey");

		$this->_keyData[$keyName][$rowNo] = $value;
	}

	function _noSuchElementError($name, $type, $function)
	{
		$this->error("No such $type '$name' in Toucan_Form_Matrix::$function");
	}

	function _checkRow($rowNo, $function)
	{
		if (!Toucan_Lib_Validate::isNumber($rowNo, 1, $this->_numRows)) {
			$this->_noSuchElementError($rowNo, "row", $function);
		}
	}

	function getKeyDataRequestName()
	{
		return "{$this->_name}Data";
	}

	function getKeyDataString()
	{
		$serializedKeyData = serialize($this->_keyData);
		return Toucan_Lib_SimpleEncrypt::encrypt($serializedKeyData, TOUCAN_STATE_KEY);
	}

	function _getRowName($name, $rowNo)
	{
		return $name.intval($rowNo);
	}
}

?>