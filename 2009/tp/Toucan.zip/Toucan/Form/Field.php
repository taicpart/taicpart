<?php

Toucan::load('Toucan_Presentation');

class Toucan_Form_Field extends Toucan_Presentation
{
	var $_name;
	var $_form;
	
	var $_value;
	var $_initialValue;
	var $_caption;
	var $_validation;
	
	function Toucan_Form_Field($props)
	{
		parent::Toucan_Presentation($props);
		
		$this->_name         =  $this->_getProp($props, 'name');
		$this->_form         =& $this->_getProp($props, 'form');
		
		$this->_caption      =  $this->_getPropDefault($props, 'caption');
		$this->_initialValue =  $this->_getPropDefault($props, 'initialValue');
	
		$this->_validation = array();
		$validation = $this->_getPropDefault($props, 'validation', array());
			
		if (is_array($validation)) {
			foreach ($validation as $validate) {
				
				if (is_array($validate)) {
				    if (isset($validate['options'])) {
					    $this->addValidate($validate['type'], $validate['options']);
					} else {
					    $this->addValidate($validate['type']);
					}
				} else {
					$this->addValidate($validate);
				}	
			}
		} else {
			$this->addValidate($validation);
		}
		
		if ($this->_getPropDefault($props, 'focusOnLoad')) {
		    $this->setFocusOnLoad();
		}
		
		$this->clear();	
	}

	function getName()
	{
		return $this->_name;
	}
	
	function getCaption()
	{
		return $this->_caption;
	}
	
	function getValue()
	{
		return $this->_value;
	}
	
	function getHTMLSafeValue()
	{
		return htmlspecialchars($this->_value);	
	}
	
	function setValue($value)
	{
		$this->_value = $value;
	}

    function setFocusOnLoad() 
    {
        $object = "document.".$this->_form->getName().".".$this->getName();
        $this->_page->addOnLoadScript($object.".focus()");
    }

	function clear()
	{
		$this->setValue($this->_initialValue);		
	}

	function &addValidate($type, $props=array()) 
	{
		if (strpos($type, '_') === false) {
			$type = "Toucan_Form_Field_Validate_{$type}";	
		}
		
		$props['field'] =& $this;
				
		$validationComponent =& Toucan::create($type, $props);
		$this->_validation[] =& $validationComponent;
		
		return $validationComponent;
	}

	function performValidate() 
	{
		$messages = array();
		foreach ($this->_validation	as $validationComponent) 
		{
			$message = $validationComponent->process();
			if ($message != '')	{
				$messages[] = $message;	
			}
		}
		return $messages;
	}
	
	function valid() 
	{
		return sizeof($this->performValidate()) == 0;	
	}
	
	function toString() 
	{
		return parent::toString().' "'.$this->_name .'"';
	}	
}