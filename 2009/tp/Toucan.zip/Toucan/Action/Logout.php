<?php

class Toucan_Action_Logout extends Toucan
{
	var $_login;

	function Toucan_Action_Logout($props)
	{
		$this->_login     =& $this->_getProp($props, 'login');
	}
	
	function process()
	{
		$this->_login->logout();
	}
}

?>