<?php

class Toucan_Action_ClearForm extends Toucan
{
	var $_form;
	
	function Toucan_Action_ClearForm($props)
	{	
		$this->_form =& $this->_getProp($props, 'form');
	}
	
	function process()
	{
		$this->_form->clear();
	}
}

?>