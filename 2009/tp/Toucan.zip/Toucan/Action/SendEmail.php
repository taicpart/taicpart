<?php

Toucan::load("Toucan_Lib_Email");

class Toucan_Action_SendEmail extends Toucan
{
	var $_toEmailAddress;
	var $_subject; 
	var $_message;
	var $_fromEmailAddress;
	var $_fromName;
	var $_cc;
	var $_bcc;
				
	function Toucan_Action_SendEmail($props)
	{
		$this->_toEmailAddress		= $this->_getPropDefault($props, "toEmailAddress");
		$this->_subject				= $this->_getPropDefault($props, "subject");
		$this->_message				= $this->_getPropDefault($props, "message");
		$this->_fromEmailAddress	= $this->_getPropDefault($props, "fromEmailAddress");
		$this->_fromName			= $this->_getPropDefault($props, "fromName");
		$this->_cc					= $this->_getPropDefault($props, "cc");
		$this->_bcc					= $this->_getPropDefault($props, "bcc");
	}

	function process()
	{
		Toucan_Lib_Email::send(
				$this->_toEmailAddress, 
				$this->_subject, 
				$this->_message, 
				$this->_fromEmailAddress, 
				$this->_fromName, 
				$this->_cc, 
				$this->_bcc);
	}
}

?>