<?php

Toucan::load("Toucan_Action_SendEmail");

class Toucan_Action_SendEmailFromForm extends Toucan_Action_SendEmail
{				
	var $_form;
	var $_loadFields;
	
	function Toucan_Action_SendEmailFromForm($props)
	{
		parent::Toucan_Action_SendEmail($props);
		$this->_form       =& $this->_getProp($props, "form");
		$this->_loadFields =  $this->_getProp($props, "loadFields");
	}

	function _loadFields()
	{
		foreach ($this->_loadFields as $loadField => $internalField) {
			$this->$internalField = $this->_form->getFieldValue($loadField);
		}
	}

	function process()
	{
		$this->_loadFields();
		parent::process();
	}
}

?>