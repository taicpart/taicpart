<?php

Toucan::load("Toucan_Action_Database");

class Toucan_Action_Database_ClearTable extends Toucan_Action_Database
{
	var $_table;
	
	function Toucan_Action_Database_ClearTable($props)
	{
		parent::Toucan_Action_Database($props);
		$this->_table = $this->_getProp($props, 'table');
	}
	
	function process()
	{
		$this->_db->delete(array("table"=>$this->_table));	
	}
}

?>