<?php

Toucan::load("Toucan_Action_Database");

class Toucan_Action_Database_UpdateRecords extends Toucan_Action_Database
{
	var $_recordset;
	var $_table;
	var $_fields;
	var $_whereFields;	

	function Toucan_Action_Database_UpdateRecords($props)
	{
		parent::Toucan_Action_Database($props);
		$this->_recordset   =& $this->_getProp($props, 'recordset');
		$this->_table       =& $this->_getProp($props, 'table');
		$this->_fields      =& $this->_getProp($props, 'fields');  
		$this->_saveFields  =& $this->_getProp($props, 'saveFields');  
		$this->_whereFields =& $this->_getProp($props, 'whereFields');
	}
	
	function process()
	{		
		$query = array();
		$query['table'] = $this->_table;

		$this->_recordset->moveToFirst();

		while ($this->_recordset->hasNext()) {		
						
			$row = $this->_recordset->nextRecord();
						
			$toUpdate = array();
			$where    = array();
	
			if ($this->_fields) {
				foreach ($this->_fields as $field) {
					if (!is_array($field)) {
						$field = array('name'=>$field);
					}
										
					$item = array('field' => $field['name'], 
								  'value' => $row[$field['name']]);

					if (in_array($field['name'], $this->_saveFields)) {
						if (isset($field['applyFunction'])) {
							$item['applyFunction'] = $field['applyFunction'];
						}
						if (isset($field['saveField'])) {
							$item['field'] = $field['saveField'];
						}
						
						$toUpdate[] = $item;
					}
					
					if (in_array($field['name'], $this->_whereFields)) {
						$where[] = $item;	
					}
				}					
			} 
														
			$query['toUpdate'] = $toUpdate;
			$query['where'] = $where;
			
			$this->_db->update($query);
		}		
	}
}

?>