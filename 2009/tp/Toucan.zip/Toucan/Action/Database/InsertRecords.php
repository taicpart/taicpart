<?php

Toucan::load("Toucan_Action_Database");

class Toucan_Action_Database_InsertRecords extends Toucan_Action_Database
{
	var $_recordset;
	var $_table;
	var $_fields;
	
	function Toucan_Action_Database_InsertRecords($props)
	{
		parent::Toucan_Action_Database($props);
		
		$this->_recordset =& $this->_getProp($props, 'recordset');
		$this->_table     =& $this->_getProp($props, 'table');
		$this->_fields    =& $this->_getPropDefault($props, 'fields');  
	}
	
	function process()
	{
		$query = array();
		$query['table'] = $this->_table;
		
		while ($this->_recordset->hasNext()) {
			$row = $this->_recordset->nextRecord();
			$toInsert = array();
			
			if ($this->_fields) {
				foreach ($this->_fields as $field) {
										
					$item = array();
					$item['field'] = $field['name'];
					$item['value'] = $row[$field['name']];
					
					if (isset($field['applyFunction'])) {
						$item['applyFunction'] = $field['applyFunction'];
					}
					
					$toInsert[] = $item;
				}
			} else {
				foreach ($row as $key => $value) {
					$toInsert[] = array('name'=>$key, 'value'=>$value);	
				}	
			}
			
			$query['toInsert'] = $toInsert;
			$this->_db->insert($query);
		}
	}
}

?>