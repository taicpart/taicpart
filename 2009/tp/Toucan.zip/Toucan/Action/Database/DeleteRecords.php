<?php

Toucan::load("Toucan_Action_Database");

class Toucan_Action_Database_DeleteRecords extends Toucan_Action_Database
{
	var $_recordset;
	var $_table;
	var $_whereFields;
	
	function Toucan_Action_Database_DeleteRecords($props)
	{
		parent::Toucan_Action_Database($props);
		$this->_recordset      =& $this->_getProp($props, 'recordset');
		$this->_table          =& $this->_getProp($props, 'table');
		$this->_whereFields    =  $this->_getProp($props, 'whereFields');
	}
	
	function process()
	{
		$query = array();
		$query['table'] = $this->_table;
		
		$doQuery = false;

		if ($this->_recordset->getNumRecords() > 0) {
			$query['where'] = array('logicalOp'=>'OR', 'conditions'=>array());
			
			while ($this->_recordset->hasNext()) {
				$row = $this->_recordset->nextRecord();
				
				$subAndConditions = array('conditions'=>array());
				
				foreach ($this->_whereFields as $whereField) {
					$subAndConditions['conditions'][] 
							= array('field'=>$whereField, 'value'=>$row[$whereField]);
				}					
				
				$query['where']['conditions'][] = $subAndConditions;	
				$doQuery = true;
			}
		}
		
		if ($doQuery) {
			$this->_db->delete($query);
		}
	}
}

?>