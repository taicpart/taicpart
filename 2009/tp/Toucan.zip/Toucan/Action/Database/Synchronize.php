<?php

Toucan::load("Toucan_Action_Database");

class Toucan_Action_Database_Synchronize extends Toucan_Action_Database
{
	var $_tableNames;
	var $_tempFile;
	var $_remoteDb;
	var $_options;
	
	function Toucan_Action_Database_Synchronize($props)
	{		
		parent::Toucan_Action_Database($props);
		
		$this->_tableNames =  $this->_getProp($props, "tableNames");
		$this->_tempFile   =  $this->_getPropDefault($props, "tempFile", "dump.sql");
		$this->_remoteDb   =& $this->_getProp($props, "remoteDb");
		$this->_options    =  $this->_getProp($props, "options", array());
	}
	
	function process()
	{
		$this->_dump();
		$this->_import();
	}
	
	function _dump()
	{
		$this->_options[] = "addDropTable";
		$error = $this->_db->dumpToFile($this->_tableNames, $this->_tempFile, $this->_options);
		if ($error) {
			$this->error($error);
		}
	}
	
	function _import()
	{
		$error = $this->_remoteDb->importFromFile($this->_tempFile);
		if ($error) {
			$this->error($error);
		}
		
		if (!@unlink($this->_tempFile)) {
			$this->_warning("Could not delete {$this->_tempFile}");
		}	
	}
}

?>