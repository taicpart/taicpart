<?php

class Toucan_Action_Search extends Toucan
{
	var $_form;
	var $_query;
	var $_searchFields;
	
	function Toucan_Action_Search($props)
	{
		$this->_form         =& $this->_getProp($props, 'form');
		$this->_query        =& $this->_getProp($props, 'query');
		$this->_searchFields =& $this->_getProp($props, 'searchFields');
	}
	
	function process()
	{
		if (!isset($this->_query['where'])) {
			$this->_query['where'] = array();
		}
		
		foreach ($this->_searchFields as $searchField) {
			if ($searchField['compareField'] != "_NONE_") {
				$field =& $this->_form->getField($searchField['name']);
				
				if ($field && $field->getValue() != '' && $field->valid()) {
					$where = array();
					$where['field']            = $searchField['compareField'];
					$where['op']               = $searchField['compareOp'];
					$where['value']            = $field->getValue();
					
					if (isset($searchField['applyFunction'])) {
						$where['applyFunction']    = $searchField['applyFunction'];
					}
					
					$this->_query['where'][] = $where;
				}
			}
		}
	}
}

?>