<?php

class Toucan_Action_Sleep extends Toucan
{
	var $_timeInSeconds;
	
	function Toucan_Action_Sleep($props)
	{
		$this->_timeInSeconds = $this->_getProp($props, 'timeInSeconds');
	}
	
	function process()
	{
		sleep($this->_timeInSeconds);
	}
}

?>