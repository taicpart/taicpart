<?php

class Toucan_Action_Login extends Toucan
{
	var $_login;
	var $_userField;
	
	function Toucan_Action_Login($props)
	{	
		$this->_login     =& $this->_getProp($props, 'login');
		$this->_userField =& $this->_getProp($props, 'userField');
	}
	
	function process()
	{
		$this->_login->login($this->_userField->getValue());
	}
}

?>