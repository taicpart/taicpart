<?php

class Toucan_Action_Admin_UpdateKeys extends Toucan
{
	var $_keys;
	var $_editFields;
	var $_recordset;

	function Toucan_Action_Admin_UpdateKeys($props)
	{
		$this->_keys       =& $this->_getProp($props, 'keys');
		$this->_editFields =& $this->_getProp($props, 'editFields');
		$this->_recordset  =& $this->_getProp($props, 'recordset');  
	}
	
	function process()
	{		
		foreach ($this->_keys as $rowIndex => $keyPairs) {
			
			foreach($keyPairs as $keyPairIndex => $keyPair) {
				$key = $keyPair['key'];

				foreach ($this->_editFields as $editField)	{

					if (($editField['name'] == $key && isset($editField['saveField']) && $editField['saveField'] != "_NONE_") || 
						(isset($editField['saveField']) && $editField['saveField'] == $key)) {
														
						$this->_recordset->moveToFirst();
						while ($this->_recordset->hasNext()) {
							$row = $this->_recordset->nextRecord();
							if (isset($row[$editField['name']])) {
							
								$this->_keys[$rowIndex][$keyPairIndex]['value'] =
									$row[$editField['name']];
							}
						}
					}
				}					
			}			
		}
	}
}

?>