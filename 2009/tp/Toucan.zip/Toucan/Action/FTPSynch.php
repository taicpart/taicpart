<?php

Toucan::load("Toucan_Lib_FileSystem");

class Toucan_Action_FTPSynch extends Toucan
{
	var $_ftpProps;
	
	function Toucan_Action_FTPSynch($props)
	{
		$this->_ftpProps  = $this->_getProp($props, "ftpProps");
		$this->_synchDirs = $this->_getProp($props, "synchDirs");		
	}
	
	function process()
	{
		$this->_progress("<strong>Started</strong>");
		$ftp =& $this->create("Toucan_Util_Net_FTP", $this->_ftpProps);
		
		foreach ($this->_synchDirs as $synchDir) {
			$this->_synchDir($ftp, $synchDir);	
		}

		$ftp->close();
		$this->_progress("<strong>Closed connection to FTP server</strong>");
	}

	function _synchDir(&$ftp, $synchDir)
	{
		$localDir  = Toucan_Lib_FileSystem::canonicalDirName($this->_getProp($synchDir, "localDir"));
		$serverDir = Toucan_Lib_FileSystem::canonicalDirName($this->_getProp($synchDir, "serverDir"));
							
		$ignoreLocalDirs   = $this->_getPropDefault($synchDir, "ignoreLocalDirs",   array());
		$ignoreLocalFiles  = $this->_getPropDefault($synchDir, "ignoreLocalFiles",  array());
		$ignoreServerDirs  = $this->_getPropDefault($synchDir, "ignoreServerDirs",  array());
		$ignoreServerFiles = $this->_getPropDefault($synchDir, "ignoreServerFiles", array());
				
		$localFiles  = Toucan_Lib_FileSystem::ls($localDir);
		$serverFiles = $ftp->ls($serverDir);

		//$this->_progress("Checking local dir {$localDir} vs server dir {$serverDir}");
		
		foreach ($localFiles['files'] as $fileName => $fileProps) {
			$localAbsoluteFilename = $localDir.$fileName;
			$serverAbsoluteFilename = $serverDir.$fileName;
						
			if (!in_array($localAbsoluteFilename, $ignoreLocalFiles) && 
					!in_array($serverAbsoluteFilename, $ignoreServerFiles)) {
					
				if (isset($serverFiles['files'][$fileName])) {
					$localTimestamp  = $fileProps['timestamp'];
					$serverTimestamp = $serverFiles['files'][$fileName]['timestamp'];
					
					if ($localTimestamp > $serverTimestamp) {
						$this->_progress("<strong>Uploading new copy of {$fileName}</strong>");
						$this->_progress("Local file timestamp was {$localTimestamp}");
						$this->_progress("Server file timestamp was {$serverTimestamp}");
						
						$ftp->put($localAbsoluteFilename, $serverAbsoluteFilename);
					}
				} else {
					$this->_progress("<strong>Uploading (brand) new copy of {$fileName}</strong>");
					$ftp->put($localAbsoluteFilename, $serverAbsoluteFilename);
				}
			}
		}
		
		foreach ($serverFiles['files'] as $fileName => $fileProps) {
			$serverAbsoluteFilename = $serverDir.$fileName;
			
			if (!in_array($serverAbsoluteFilename, $ignoreServerFiles) && 
					!isset($localFiles['files'][$fileName])) {
					
				$this->_progress("Deleting file {$fileName}");
				$ftp->delete($serverAbsoluteFilename);
			}	
		}
		
		foreach ($serverFiles['dirs'] as $dirName => $dirProps) {
			$serverAbsoluteDir = $serverDir.$dirName;
			
			if (!in_array($serverAbsoluteDir, $ignoreServerDirs) && 
					$dirName != '.' && $dirName != '..' && !isset($localFiles['dirs'][$dirName])) {

				$this->_progress("<strong>Deleting directory {$dirName}</strong>");
				$ftp->rmDir($serverAbsoluteDir);
			}	
		}
		
		foreach ($localFiles['dirs'] as $dirName => $dirProps) {
			if ($dirName != '.' && $dirName != '..') {

				$localAbsoluteDir  = $localDir.$dirName;
				$serverAbsoluteDir = $serverDir.$dirName;

				if (!(in_array($localAbsoluteDir, $ignoreLocalDirs) || 
				      in_array($serverAbsoluteDir, $ignoreServerDirs))) {
						
					if (!isset($serverFiles['dirs'][$dirName])) {
						$this->_progress("<strong>Making directory {$dirName}</strong>");
						$ftp->mkDir($serverAbsoluteDir);
					}	
								
					$nextSynchDir = $synchDir;
					$nextSynchDir['localDir']  = $localAbsoluteDir;
					$nextSynchDir['serverDir'] = $serverAbsoluteDir;
					
					$this->_synchDir($ftp, $nextSynchDir);
				}
			}
		}
	}
		
	function _progress($str)
	{
		print "$str <br />";
		flush(); 
	}
}

?>