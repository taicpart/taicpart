<?php

Toucan::load("Toucan_Lib_Util");

class Toucan_Action_GoToPage extends Toucan
{
	var $_url;
	var $_keysRecordset;
	var $_keyNames;
	
	function Toucan_Action_GoToPage($props)
	{
		$this->_url =& $this->_getProp($props, 'url');
		
		$this->_keysRecordset =& $this->_getPropDefault($props, 'keysRecordset'); 
		$this->_keyNames      =& $this->_getPropDefault($props, 'keyNames'); 
	}
	
	function process()
	{
		$destination = $this->_url;
		if ($this->_keysRecordset) {
			$keyData = array();
			$this->_keysRecordset->moveToFirst();
			while ($this->_keysRecordset->hasNext()) {
				$keySet = array();
				$row = $this->_keysRecordset->nextRecord();
				foreach ($this->_keyNames as $keyName) {
					$keySet[] = array('key'=>$keyName, 'value'=>$row[$keyName]);
				}
				$keyData[] = $keySet;
			}	

			$serializedKeyData = serialize($keyData);
			$encodedKeyData = Toucan_Lib_SimpleEncrypt::encrypt($serializedKeyData, TOUCAN_STATE_KEY);

			if (strpos($this->_url, '?') === false) {
				$destination .= "?";	
			} else {
				$destination .= "&";	
			}
			$destination .= "key=".htmlentities(urlencode($encodedKeyData));
		}
		
		header("location: {$destination}");
	}
}

?>