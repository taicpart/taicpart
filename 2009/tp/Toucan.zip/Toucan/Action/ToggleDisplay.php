<?php

class Toucan_Action_ToggleDisplay extends Toucan
{
	var $_pres;

	function Toucan_Action_ToggleDisplay($props)
	{
		$this->_pres =& $this->_getProp($props, 'presentation');
	}

	function process()
	{
		$this->_pres->setDisplay(!$this->_pres->getDisplay());
	}
}

?>