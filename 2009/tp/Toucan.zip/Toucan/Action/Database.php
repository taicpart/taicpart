<?php

class Toucan_Action_Database extends Toucan
{
	var $_db;
	
	function Toucan_Action_Database($props)
	{
		$this->_db    =& $this->_getProp($props, 'db');
	}	
}

?>