<?php

Toucan::load("Toucan_Script");

class Toucan_Script_GoogleMap extends Toucan_Script
{
	var $_locations;
	var $_zoom;
	var $_divID;
	
	function Toucan_Script_GoogleMap($props)
	{
		parent::Toucan_Script($props);
		
		$this->_page->addScript(
				array("type" => "FromSrc",
				      "src"  => "http://maps.google.com/maps?file=api&amp;v=1&amp;key=".GOOGLE_MAP_KEY));
		
		$this->_page->addOnLoadScript("createMap()");
		
		$this->_locations = $this->_getPropDefault($props, "locations", array());
		$this->_zoom      = $this->_getPropDefault($props, "zoom", 2);
		$this->_divID     = $this->_getProp($props, "divID");
	}
	
	function _generateCode()
	{
		return $this->_generateLocations().$this->_generateBaseFunctions();	
	}
	
	function _generateLocations()
	{
		$code = "var locations = {";
		$firstLoc = true;
		foreach ($this->_locations as $location => $props) {
			if ($firstLoc) {
				$firstLoc = false;
			} else {
				$code .= ",";	
			}
			$code .= "'$location':{";
			$firstProp = true;
			foreach ($props as $prop => $value) {
				if ($firstProp) {
					$firstProp = false;
				} else {
					$code .= ",";	
				}
				$code .= "'{$prop}':'{$value}'";
			}
			$code .= "}";
		}
		
		$code .= "};";
		return $code;		
	}
	
	function _generateBaseFunctions()
	{
		$code = <<< CODE
var baseIcon = new GIcon();
baseIcon.shadow = "http://www.google.com/mapfiles/shadow50.png";
baseIcon.iconSize = new GSize(20, 34);
baseIcon.shadowSize = new GSize(37, 34);
baseIcon.iconAnchor = new GPoint(9, 34);
baseIcon.infoWindowAnchor = new GPoint(9, 2);
baseIcon.infoShadowAnchor = new GPoint(18, 25);
var map;

function createMarker(point, ref) {
	  var loc = locations[ref];	
	  var icon = new GIcon(baseIcon);
	  var letter = "";
	  if (loc.letter != null) {
	  	letter = loc.letter;
	  }
	  icon.image = "http://www.google.com/mapfiles/marker"+letter+".png";
	  var marker = new GMarker(point, icon);

	  GEvent.addListener(marker, "click", function() {
			showLocationInfo(ref);
	  });

	  return marker;
}

function showLocationInfo(ref)
{
	var loc = locations[ref];
	var html = '<div><strong>'+loc.name+'</strong>, <span class="smaller">'+loc.address+'</span>';
	if (loc.directions != "") {
		html += '<p class="map_directions smaller">'+loc.directions+'</p>';
	}
	html += "</div>";
	
	loc.marker.openInfoWindowHtml(html);
}		

function moveMap(ref)
{
	var loc = locations[ref];
	map.recenterOrPanToLatLng(new GPoint(loc.longitude,loc.latitude));
	showLocationInfo(ref);
}

function createMap()
{
	if (GBrowserIsCompatible()) {
		map = new GMap(document.getElementById("{$this->_divID}"));
		map.addControl(new GLargeMapControl());
		map.addControl(new GMapTypeControl());
		var centeredAndZoomed = false;
			
		for(var i in locations) {
			var loc = locations[i];
			if (!centeredAndZoomed) {
				map.centerAndZoom(new GPoint(loc.longitude, loc.latitude), {$this->_zoom});
			}
			loc.marker = createMarker(new GPoint(loc.longitude,loc.latitude),loc.ref);
			map.addOverlay(loc.marker);
		}	
	}
} 
CODE;
		return $code;
	}
}

?>