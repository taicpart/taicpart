<?php

Toucan::load("Toucan_Script");

class Toucan_Script_FromSrc extends Toucan_Script
{
	var $_src;

	function Toucan_Script_FromSrc($props)
	{
		parent::Toucan_Script($props);
		$this->_src = $this->_getPropDefault($props, 'src');
	}

	function getScript()
	{
		return "<script language=\"JavaScript\" type=\"text/JavaScript\" src=\"{$this->_src}\"></script>";
	}
}

?>