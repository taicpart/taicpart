<?php
require_once("Lib/Sys.php");

class Toucan
{
	function &create($class, $props=array())
	{
		Toucan::load($class);
		$instance =& new $class($props);
		return $instance;
	}
	
	function load($class)
	{
		if (!class_exists($class)) {
			$parts = explode("_", $class);
			
			$file  = array_pop($parts).".php";
			$dir   = implode(array_slice($parts, 1), "/");
			
			if ($dir != "") {
				$dir .= "/";	
			}
			
			require_once("$dir$file");	
		}		
	}
	
	function &_getProp($props, $name)
	{
		if (isset($props[$name])) {
			return $props[$name];	
		} else {
			$this->_propNotSetError($props, $name);
		}
	}
	
	function &_getPropDefault($props, $name, $default=false)
	{
		if (isset($props[$name])) {
			return $props[$name];
		} else {
			return $default;
		}
	}
		
	function _propNotSetError($props, $name)
	{
		$this->error("Property \"{$name}\" not set	in ".$this->toString(), $props);
	}
	
	function error($error, $debugInfo=NULL)
	{	
		if (defined('TOUCAN_SHOW_ERRORS') && TOUCAN_SHOW_ERRORS) {
			print "<p class=\"toucanError\">ERROR: {$error}</p>";
			
			if ($debugInfo != NULL) {
				$this->varDump($debugInfo);
			}
		}
		
		die();
	}	
	
	function warning($warning, $debugInfo=NULL)
	{
		if (defined('TOUCAN_SHOW_WARNINGS') && TOUCAN_SHOW_WARNINGS) {
			print "<p class=\"toucanWarning\">WARNING: {$warning}</p>";

			if ($debugInfo != NULL) {
				$this->varDump($debugInfo);
			}
		}			
	}
	
	function debug($message)
	{
		if (defined('TOUCAN_SHOW_DEBUG') && TOUCAN_SHOW_DEBUG) {
			print "<p class=\"toucanDebug\">{$message}</p>";
		}			
	}
		
	function varDump($var)
	{
		if (defined('TOUCAN_SHOW_DEBUG') && TOUCAN_SHOW_DEBUG) {
			print "<xmp>";
			var_dump($var);
			print "</xmp>";
		}					
	}
	
	function debugObject($obj, $maxLevel=-1, $thisLevel=0)
	{
		if ($thisLevel < $maxLevel || $maxLevel == -1) {
			if (is_object($obj) || is_array($obj)) {
				print "<table border=\"1\">";
				foreach ($obj as $key=>$val) {
					print "<tr>";
					print "<td valign=\"top\">$key</td>";
					print "<td>";
					$this->debugObject($val, $maxLevel, $thisLevel+1);
					print "</td>";
					print "</tr>";
				}
				print "</table>";
			} else if ($obj) {
				$this->varDump($obj);
			} 
		} else {
			print "&lt; REACHED MAX DEPTH &gt;";
		}
	}
	
	function exec($cmd, $suppressErrors=false)
	{
		if (defined('TOUCAN_SHOW_EXEC_CMD') && TOUCAN_SHOW_EXEC_CMD) {
			print "<p class=\"toucanExecCmd\">{$cmd}</p>";		
		}
		
		$redirectErrorsToOutputCmd = "$cmd  2>&1";
		$response = array();
		$returnCode = 0;
		
		exec($redirectErrorsToOutputCmd, $response, $returnCode);
		
		if (sizeof($response) > 0) {
			if (defined(TOUCAN_SHOW_EXEC_OUTPUT) && TOUCAN_SHOW_EXEC_OUPUT) {
				print "<p class=\"toucanExecResponse\">".implode($response, "<br />")."</p>";
			}			
		}
		
		if (!$suppressErrors && $returnCode != 0) {
			$this->error("When executing $cmd", $response);
		}
	}
	
	function toString()
	{
		$classInfo = get_class($this);
		return $classInfo;
	}
}
?>