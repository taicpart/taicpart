<?php

Toucan::load("Toucan_Lib_JavaScript");

class Toucan_Presentation extends Toucan
{
	var $_page;
	var $_display = true;
	var $_styleSheets;
	
	var $_subPresentations;
		
	function Toucan_Presentation($props)
	{				
		if (is_a($this, 'Toucan_Page')) {
			$this->_page =& $this;	
		} else {
			$this->_page =& $this->_getProp($props, 'page');
		} 

		$this->_display =  $this->_getPropDefault($props, 'display', true);
				
		$this->_styleSheets = array();
		if (isset($props['styleSheet'])) {
			$this->_styleSheets[] = $props['styleSheet'];
		} else if (isset($props['styleSheets'])) {
			$this->_styleSheets = $props['styleSheets'];
		}	

		$this->clearPresentations();
	}
	
	function &addPresentation($props)
	{
		if (is_a($this, 'Toucan_Page')) {
			$page =& $this;	
		} else {
			$page =& $this->_page;	
		}
		
		if (!isset($props['type'])) {
			$this->error("No type set for presentation in Toucan_Presentation::addPresentation", $props);
		}
	
		$type     = $props['type'];
		$location = isset($props['location']) ?  $props['location'] : 'none';
		
		if (strpos($type, 'Toucan') !== 0 && strpos($type, 'Proj') !== 0) {
			$type = "Toucan_Presentation_{$type}";	
		}
		
		if (!isset($props['page'])) {
			$props['page'] =& $page;	
		}
	
		$pres =& $this->create($type, $props);
		
		$page->addStyleSheets($pres->getStyleSheets());
		
		if ($location != 'none') {
			$this->_subPresentations[$location][] = &$pres;	
		}

		return $pres;
	}

	function clearPresentations($location='')
	{
		if ($location == '') {
			$this->_subPresentations['header'] = array();
			$this->_subPresentations['body']   = array();
			$this->_subPresentations['footer'] = array();		
		} else {
			$this->_subPresentations[$location] = array();
		}
	}

	function setDisplay($display)
	{
		$this->_display = $display;
	}
	
	function getDisplay()
	{
		return $this->_display;	
	}

	function getStyleSheets()
	{
		return $this->_styleSheets;	
	}

	function _generateHTML()
	{
		return  $this->_generateHeaderHTML()
		       .$this->_generateBodyHTML()
			   .$this->_generateFooterHTML();
	}

	function _generateSubPresentations($type)
	{
		$html = '';
		
		$presentationIndexes = array_keys($this->_subPresentations[$type]);
		foreach ($presentationIndexes as $index) {
			$pres =& $this->_subPresentations[$type][$index];
			$html .= $pres->getHTML();
		}
		
		return $html;
	}

	function _generateHeaderHTML()
	{		
		return $this->_generateSubPresentations('header');
	}

	function _generateBodyHTML()
	{		
		return $this->_generateSubPresentations('body');
	}
	
	function _generateFooterHTML()
	{		
		return $this->_generateSubPresentations('footer');
	}

	function getHTML() 
	{		
		if ($this->_display) {		
			return $this->_generateHTML();
		}
	}
	
	function getHeaderHTML() 
	{
		if ($this->_display) {		
			return $this->_generateHeaderHTML();
		}
	}

	function getBodyHTML()
	{	
		if ($this->_display) {		
			return $this->_generateBodyHTML();
		}		
	}
	
	function getFooterHTML() 
	{
		if ($this->_display) {		
			return $this->_generateFooterHTML();
		}
	}
	
	function popUpLinkHTML($url, $anchorText, $windowID, $xPos, $yPos, $width, $height, $class="")
	{
		$classHTML = "";
		if ($class) {
			$classHTML = "class = \"{$class}\"";
		}	
			
$html = <<< HTML
<a href="$url" $classHTML target="$windowID" onclick="window.open('$url', '$windowID', 
'toolbar=no, location=no, scrollbars=yes, resizable=yes, menubar=no, status=no, left=$xPos, top=$yPos, width=$width, height=$height'); 
return false">$anchorText</a>
HTML;
		return $html;		
	}
	
	function emailAddress($emailAddress, $altImage="") 
	{
		$html  = Toucan_Lib_JavaScript::scrambleEmailAddress($emailAddress);
		
		if ($altImage != '') {
			$url = $altImage;
			if (is_array($altImage)) {
				$url = $altImage['url'];
			}
			
			$html .= "<noscript>"
				  .  "<img src=\"$url\"";
				  
			if (is_array($altImage) && isset($altImage['width'])) {
				$html .= " width=\"{$altImage['width']}\"";
			}
			
			if (is_array($altImage) && isset($altImage['height'])) {
				$html .= " height=\"{$altImage['height']}\"";
			}

			if (is_array($altImage) && isset($altImage['class'])) {
				$html .= " class=\"{$altImage['class']}\"";	
			}

			if (is_array($altImage) && isset($altImage['align'])) {
				$html .= " align=\"{$altImage['align']}\"";	
			}

			$html .= " alt=\"email address\" />"
			      .  "</noscript>";	
		} 		
		
		return $html;
	}
}
