<?php

Toucan::load("Toucan_Page");
Toucan::load("Toucan_Lib_Util");

class Toucan_Page_Admin_Login extends Toucan_Page
{
	var $_db;
	var $_login;
	var $_loginTable;
	var $_goToPage;

	function Toucan_Page_Admin_Login($props)
	{
		parent::Toucan_Page($props);
		
		$this->_db         = $this->_getProp($props, "db");
		$this->_login      = $this->create("Toucan_Util_Login");
		$this->_loginTable = $this->_getProp($props, "loginTable");
		$this->_goToPage   = $this->_getPropDefault($props, "goToPage");
	}

	function ensureLogin()
	{
		if (!$this->_login->getUser())	{
			$form =& $this->addForm(array("name"=>"login", "location"=>"body"));

			$usersRecordset =& Toucan::create("Toucan_Recordset_Database",
					array("db" => &$this->_db,
				          "query" =>
				          array("fields" => array("user", "password"),
				                "tables" => $this->_loginTable)));

			$userField =& $form->addField(
					array("type"        => "Text",
			              "name"        => "user",
			              "caption"     => "Username",
			              "focusOnLoad" => true));

			$passField =& $form->addField(
			        array("type"              => "Password",
			              "name"              => "pass",
			              "caption"           => "Password",
			              "validation"        => array(
			              array("type" => "Password",
			              	    "options" =>
			              		   array("userField"      => &$userField,
			                          	 "usersRecordset" => &$usersRecordset,
			                          	 "passEncrypted"  => true)))));

			$button =& $form->addButton(array("name"      => "login",
			                                  "caption"   => "Login",
			                                  "htmlClass" => "loginButton"));

			$button->addAction(
					array("type"      => "Login",
					      "userField" => &$userField,
					      "login"     => &$this->_login));

			if ($this->_goToPage) {
				$button->addAction(
						array("type"  => "GoToPage",
						      "url"   => &$this->_goToPage));				
			}

			$this->processForms();

			if (!$form->submitted() || !$form->valid()) {
				print $this->getHTML();
				die();
			} else {
				$this->clearPresentations();
			}
		}		
	}
}

?>