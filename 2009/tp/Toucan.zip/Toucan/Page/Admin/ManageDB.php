<?php

Toucan::load("Toucan_Page_Admin_Login");
Toucan::load("Toucan_Lib_Util");

class Toucan_Page_Admin_ManageDB extends Toucan_Page
{
	var $_name;
	var $_requestSafeName;
	var $_baseTable;
	var $_baseTableKeys;
	var $_mode;

	function Toucan_Page_Admin_ManageDB($props)
	{
		parent::Toucan_Page($props);
		
		$loginPage = $this->_getPropDefault($props, "loginPage");
		if ($loginPage) {
			$loginPage->ensureLogin();
		}

		$this->_name = $this->_getProp($props, "name");
		$this->_requestSafeName = strtolower(str_replace(" ", "", $this->_name));

		$this->_db = $this->_getProp($props, "db");
		$this->_baseTable = $this->_getProp($props, "baseTable");
		$this->_baseTableKeys = $this->_getProp($props, "baseTableKeys");

		$this->_getMode();
		$this->_appendTitle();
		
		if ($this->_mode == "Add") {			
			$this->_initialiseAddPage($this->_getPropDefault($props, "add", array()));
		} else if ($this->_mode == "Edit") {
			$this->_initialiseEditPage($this->_getPropDefault($props, "edit", array()));
		} else {
			$this->_initialiseListPage($this->_getPropDefault($props, "list", array()));
		}
	}

	function _appendTitle()
	{
		$this->_title .= " :: {$this->_name} :: {$this->_mode}";
	}
	
	function _addHeaderPresentation()
	{
	}	

	function _getMode()
	{
		$mode = $this->getRequestValue("mode");

		if ($mode) {
			if ($mode == "add") {
				$this->_mode = "Add";
			} else if ($mode == "edit") {
				$this->_mode = "Edit";
			} else {
				$this->_mode = "List";
			}
		} else {
			$this->_mode = "List";
		}
	}

	function _initialiseAddPage($props)
	{
		$this->setStateValue("mode", "add");
		
		// get fields from properties
		$addFields = $this->_getProp($props, "addFields");
		$uploadFields = $this->_getPropDefault($props, "uploadFields", array());

		// setup form				
		$addRecordForm =& $this->addForm(
				array("name"   => "add",
					  "method" => "post"));
		$addRecordForm->addFields($addFields);
		$addRecordForm->addFields($uploadFields);

		// load submission and get data
		$addRecordForm->loadSubmittedFieldValues();
		$addRecordFormRecordset =& $addRecordForm->getRecordset();

		// initialize actions
		$addRecordAction =
				array("type"      => "Database_InsertRecords",
					  "recordset" => &$addRecordFormRecordset,
					  "db"        => &$this->_db,
					  "table"     => $this->_baseTable,
					  "fields"    => $addFields,
					  "formSubmissionType" => "new");
		$uploadActions = array();
		foreach ($uploadFields as $uploadField) {
			$uploadField['action']['recordset'] = &$addRecordFormRecordset;							
			$uploadActions[]= $uploadField['action'];
		}		

		// initialize 'add & return' button
		$addAndReturnButton =& $addRecordForm->addButton(
				array("name"      =>  "addAndReturn",
				      "caption"   => "Add &amp; return",
				      "htmlClass" => "addAddAndReturnButton"));
		$addAndReturnButton->addAction($addRecordAction);
		$addAndReturnButton->addActions($uploadActions);
		$addAndReturnButton->addAction(
				array("type" => "GoToPage",
		              "url"  => $this->_goToPageURL("list")));

		// initialize 'add & add another' button
		$addAndAddAnotherButton =& $addRecordForm->addButton(
				array("name"      => "addAndAddAnother",
				      "caption"   => "Add &amp; add another",
				      "htmlClass" => "addAddAndAddButton"));
		$addAndAddAnotherButton->addAction($addRecordAction);
		$addAndAddAnotherButton->addActions($uploadActions);
		$addAndAddAnotherButton->addAction(
				array("type" => "GoToPage",
		              "url"  => $this->_goToPageURL("add")));

		// initialize 'add & edit' button
		$addAndEditButton =& $addRecordForm->addButton(
				array("name"      => "addAndEdit",
				      "caption"   => "Add &amp; edit",
				      "htmlClass" => "addAddAndEditButton"));
		$addAndEditButton->addAction($addRecordAction);
		$addAndEditButton->addActions($uploadActions);
		$addAndEditButton->addAction(
				array("type" => "GoToPage",
					  "keyNames"=>$this->_baseTableKeys,
					  "keysRecordset" => &$addRecordFormRecordset,
		              "url"  => $this->_goToPageURL("edit")));		

		// initialize 'cancel' button
		$cancelButton =& $addRecordForm->addButton(
				array("name"      => "cancel",
				      "caption"   => "Cancel",
				      "htmlClass" => "addCancelButton"));
		$cancelButton->addAction(
				array("type" => "GoToPage",
		              "url"  => $this->_goToPageURL("list"),
		              "formSubmissionType" => "any"));

		// process submission
		$addRecordForm->processSubmission();
	}

	function _initialiseEditPage($props)
	{
		// get fields from properties
		$editFields   = $this->_getProp($props, "editFields");
		$uploadFields = $this->_getPropDefault($props, "uploadFields", array());
		
		$loadFields = array();
		foreach ($editFields as $editField) {
			if (isset($editField['loadField'])) {
				$loadFields[] = array("field" => $editField['loadField'],
				                      "as" => $editField['name']);
			} else {
				$loadFields[] = $editField['name'];
			}
		}
		
		$saveFields = array();
		foreach ($editFields as $editField) {
			if (!isset($editField['saveField']) || $editField['saveField'] != "_NONE_") {
				$saveFields[] = $editField['name'];
			}
		}
		
		// set state to edit mode		
		$this->setStateValue("mode", "edit");	
		
		// get keys of records to edit
		$encodedKeyData = $this->getRequestValue('key');
		$serializedKeyData = Toucan_Lib_SimpleEncrypt::decrypt($encodedKeyData, TOUCAN_STATE_KEY);	
		$keys = unserialize($serializedKeyData); 		
		
		// initialize form
		$editRecordsForm =& $this->addForm(
				array("name"   => "edit",
					  "method" => "post"));
		
		// add key data to form in order to remember it when page is submitted
		$editRecordsForm->addField(
			array("type" => "Hidden",
			      "name" => "key",
			      "initialValue" => $encodedKeyData));
		
		// initialize record matrix
		$editRecordsMatrix =& $editRecordsForm->addMatrix(
				array("name" => "editMatrix",
				      "numRows" => sizeof($keys)));

		// add 'update' button on rows and end
		$editRecordsMatrix->addButton(
			array("name" => "update",
			      "rowCaption" => "Update this record",
			      "endCaption" => "Update all &amp; return",
			      "htmlClass"  => "editUpdateButton"));

		// initialize 'cancel' button
		$cancelButton =& $editRecordsForm->addButton(
				array("name"      => "cancel",
				      "caption"   => "Cancel",
				      "htmlClass" => "editCancelButton"));
		$cancelButton->addAction(
				array("type" => "GoToPage",
		              "url"  => $this->_goToPageURL("list"),
		              "formSubmissionType" => "any"));
		
		// add fields to matrix
		$editRecordsMatrix->addFields($editFields);
		$editRecordsMatrix->addFields($uploadFields);
				      
		// set form to submitted data (if form was submitted)
		$editRecordsForm->loadSubmittedFieldValues();
		
		// retrieve data (loaded from database / submitted)
		$editRecordsMatrixRecordset =& $editRecordsMatrix->getRecordset();

		// initialize 'return' action to list page
		$returnAction = 
				array("type" => "GoToPage",
		              "url"  => $this->_goToPageURL("list"));

		// add update action to update buttons
		$editRecordsMatrix->addActionToButton("update", 
				array("type"        => "Database_UpdateRecords",
					  "db"          => &$this->_db,
					  "table"       => $this->_baseTable,
					  "recordset"   => &$editRecordsMatrixRecordset,
					  "fields"      => $editFields,
					  "saveFields"  => $saveFields,
					  "whereFields" => $this->_baseTableKeys));
					  
		$editRecordsMatrix->addActionToButton("update",
				array("type"	   => "Admin_UpdateKeys",
				      "keys"	   => &$keys,
				      "editFields" => $editFields,
				      "recordset"  => &$editRecordsMatrixRecordset));

		// initialize upload action and add to update buttons
		foreach ($uploadFields as $uploadField) {
			$action = $uploadField['action'];
			$action['recordset'] = &$editRecordsMatrixRecordset;			
			$editRecordsMatrix->addActionToButton("update", $action);
		}


		// add return action to update button
		$editRecordsMatrix->addActionToButton(
				"update", $returnAction, false, true);	
		
		// process the submission
		$editRecordsForm->processSubmission();

		if (!$editRecordsForm->submitted() || $editRecordsForm->valid()) {
			
			// load records to edit from database
			$editRecordset =& Toucan::create(
					"Toucan_Recordset_Database", array("db" => &$this->_db));
			$editRecordset->loadRecordsFromKeys(
					$this->_baseTable, $loadFields, $keys);
			$editRecordsMatrix->setDataUsingRecordset($editRecordset);
			
		}
	}

	function _initialiseListPage($props)
	{			
		$baseQuery       = $this->_getProp($props, "baseQuery");
		$searchFields    = $this->_getProp($props, "searchFields");
		$tableRowData    = $this->_getProp($props, "tableRowData");

		$this->setStateValue("mode", "list");

		$searchForm =& $this->addForm(
				array("name"   => "search",
		              "method" => "get",
		              "saveFormValuesToState" => true));

		$searchForm->addFields($searchFields);

		$searchButton =& $searchForm->addButton(
				array("name"      => "search",
				      "caption"   => "Search",
				      "htmlClass" => "listSearchButton"));

		$pager  =& $this->createPager(
				array("name" => "{$this->_requestSafeName}Pager"));
		$sorter =& $this->createSorter(
				array("name" => "{$this->_requestSafeName}Sorter"));

		$searchForm->process();

		$searchAction = Toucan::create("Toucan_Action_Search",
				array("form"         => &$searchForm,
					  "searchFields" => &$searchFields,
					  "query"        => &$baseQuery));

		$searchAction->process();

		$buttonForm =& $this->addForm(
				array("name"   => "buttons",
					  "method" => "get"));

		$clearTableButton =& $buttonForm->addButton(
				array("name"      => "clearTable",
				      "caption"   => "Clear Table",
				      "confirm"   => "Are you sure you wish to delete ALL records in this table?",
				      "htmlClass" => "listClearButton"));

		$clearTableButton->addAction(
				array("type"    => "Database_ClearTable",
				      "db"      => &$this->_db,
				      "table"   => $this->_baseTable));

		$addRecordButton =& $buttonForm->addButton(
				array("name"      => "addRecord",
				      "caption"   => "Add new record",
				      "htmlClass" => "listAddButton"));

		$addRecordButton->addAction(
				array("type" => "GoToPage",
				      "url"  => $this->_goToPageURL("add")));

		$this->addPresentation(
				array("type"     => "PagerControls",
				      "location" => "body",
				      "pager"    => &$pager));

		$listForm =& $this->addForm(
				array("name"   => "list",
				      "method" => "get"));

		$listMatrix   =& $listForm->addMatrix(
				array("name"    => "listMatrix",
					  "numRows" => 20,
				      "keys"    => $this->_baseTableKeys));

		$listMatrix->addField(
				array("type"=>"Checkbox",
				      "name"=>"selected"));

		$listMatrix->addButton(
				array("name"      => "edit",
				      "caption"   => "Edit",
				      "htmlClass" => "listEditButton"));

		$listMatrix->addButton(
				array("name"      => "delete",
				      "caption"   => "Delete",
				      "confirm"   => "Are you sure you want to delete these record(s)?",
				      "htmlClass" => "listDeleteButton"));

		$listForm->loadSubmittedFieldValues();
		$listMatrixRecordset =& $listMatrix->getRecordset('selected');

		$listMatrix->addActionToButton("delete",
				array("type"           => "Database_DeleteRecords",
					  "db"             => &$this->_db,
					  "table"          => $this->_baseTable,
		              "recordset"      => &$listMatrixRecordset,
		              "whereFields"    => $this->_baseTableKeys));

		$listMatrix->addActionToButton("edit",
				array("type"           => "GoToPage",
				      "keysRecordset"  => &$listMatrixRecordset,
				      "keyNames"       => $this->_baseTableKeys,
				      "url"            => $this->_goToPageURL("edit")));

		$this->addPresentation(
				array("type"     => "PagerControls",
				      "location" => "body",
				      "pager"    => &$pager));

		$buttonForm->process();
		
		$listForm->processSubmission();
		$listForm->clear();
		
		$listRecordset =& Toucan::create("Toucan_Recordset_Database",
				array("db"     => &$this->_db,
				      "query"  => $baseQuery,
				      "pager"  => &$pager,
				      "sorter" => &$sorter));		
		
		$listForm->setLayout(
				array("type"           => "Table",
					  "location"       => "body",
					  "recordset"      => &$listRecordset,
			          "sorter"         => &$sorter,
			          "tableRowData"   => $tableRowData,
			          "tableRowKeys"   => $this->_baseTableKeys,
			          "matrix"         => &$listMatrix,
			          "rowFieldNames"  => array("selected"),
			          "rowButtonNames" => array("edit", "delete"),
			          "endButtonNames" => array("edit", "delete"),
			          "endCaption"     => "<div class=\"withSelected\">With selected:</div>"));		
	}

	function _login($props)
	{
		$login = $this->create("Toucan_Util_Login");
		
		$user = $login->getUser();
		if (!$user)	{
			$loginTable = $this->_getProp($props, "loginTable");

			$form =& $this->addForm(array("name"=>"login", "location"=>"body"));

			$usersRecordset =& Toucan::create("Toucan_Recordset_Database",
					array("db" => &$this->_db,
				          "query" =>
				          array("fields" => array("user", "password"),
				                "tables" => $loginTable)));

			$userField =& $form->addField(
					array("type"       => "Text",
			              "name"       => "user",
			              "caption"    => "Username",
			              "validation" => "NotNull"));

			$passField =& $form->addField(
			        array("type"              => "Password",
			              "name"              => "pass",
			              "caption"           => "Password",
			              "validation"        => array(
			              array("type" => "Password",
			              	    "options" =>
			              		   array("userField"      => &$userField,
			                          "usersRecordset" => &$usersRecordset)))));

			$button =& $form->addButton(array("name"  => "login",
			                                  "value" => "Login"));

			$button->addAction(
					array("type"      => "Login",
					      "userField" => &$userField,
					      "login"     => &$login));

			$this->processForms();

			if (!$form->submitted() || !$form->valid()) {
				print $this->getHTML();
				die();
			} else {
				$this->clearPresentations();
			}
		}
	}

	function _goToPageURL($mode) {
		return $_SERVER['PHP_SELF']
			   ."?mode={$mode}&".$this->getStateQueryStringParam();
	}
}

?>