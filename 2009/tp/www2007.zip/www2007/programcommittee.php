<?php
	include("_proj/Proj.php");
	$page =& Toucan::create("Proj_TAICPART_Page", 
							array("url"      => "programcommittee.php",
							      "subtitle" => "Program Committee"));
	print $page->getHeaderHTML();
?>
	<h1>Program Committee (confirmed so far)</h1>
	
	<div style="float: left; width: 390px;">	
	<h2>Academic Members</h2>
		
	<ul>
		<li>Giulio Antoniol, <em>University of Sannio</em>, Italy</li>
		<li>Kirill Bogdanov, <em>University of Sheffield</em>, UK</li>
		<li>David Binkley, <em>Loyola College Maryland</em>,USA</li>
		<li>Jonathan Bowen, <em>London South Bank University</em>, UK</li>
		<li>Myra Cohen, <em>University of Nebraska-Lincoln</em>, USA</li>
		<li>John Clark, <em>University of York</em>, UK</li>
		<li>Mireille Ducass&eacute;, <em>IRISA / INSA de Rennes</em>, France</li>
		<li>Matthew Dwyer, <em>University of Nebraska-Lincoln</em>, USA</li>
		<li>Mark Harman, <em>Kings College London</em>, UK</li>
		<li>Mary Jean Harrold, <em>Georgia Institute of Technology</em>, USA</li>
		<li>Rob Hierons, <em>Brunel University</em>, UK</li>
		<li>Mike Holcombe, <em>University of Sheffield</em>, UK</li>
		<li>Gregory Kapfhammer, <em>Allegheny College</em>, USA</li>
		<li>Bogdan Korel, <em>Illinois Institute of Technology</em>, USA</li>
		<li>Paul Krause, <em>University of Surrey</em>, UK</li>
		<li>Yvan Labiche, <em>Carleton University</em>, Canada</li>
		<li>Bev Littlewood, <em>City University London</em>, UK</li>
		<li>Wes Masri, <em>American University of Beirut</em>, Lebanon</li>
		<li>John May, <em>University of Bristol</em>, UK</li>
		<li>Phil McMinn, <em>University of Sheffield</em>, UK</li>
		<li>Robby, <em>Kansas State University</em>, USA</li>
		<li>Stuart Reid, <em>Cranfield University</em>, UK</li>
		<li>Filippo Ricca, <em>ITC-irst, Trento</em>, Italy</li>
		<li>Marc Roper, <em>University of Strathclyde</em>, UK</li>
		<li>Mary Lou Soffa, <em>University of Virginia</em>, USA</li>
		<li>Hasan Ural, <em>University of Ottawa</em>, Canada</li>
		<li>Jianjun Zhao, <em>Shanghai Jiao Tong University</em>, China</li>
		<li>Hong Zhu, <em>Oxford Brookes University</em>, UK</li>
	</ul>
</div>	
	
	<div style="float: right; width: 340px;">		
	<h2>Industrial Members</h2>
	
	<ul>
		<li>Steve Allott, <em>Electromind</em>, UK</li>
		<li>Paul Baker, <em>Motorola</em>, UK</li>
		<li>Sigrid Eldh, <em>Ericsson</em>, Sweden</li>
		<li>Isabel Evans, <em>Testing Solutions Group Ltd.</em>, UK</li>
		<li>Paul Gerrard, <em>Gerrard Consulting</em>, UK</li>
		<li>Mike Hennell, <em>LDRA Software Technology</em>, UK</li>
		<li>Jani Pesonen, <em>Nokia</em>, Finland</li>
		<li>Mathai Joseph, <em>Tata Consultancy Services Ltd.</em>, India</li>
		<li>Wolfram Schulte, <em>Microsoft</em>, USA</li>
		<li>Brian Shea, <em>Vizuri Ltd.</em>, UK</li>
		<li>Clive Stewart, <em>IBM</em>, UK</li>
		<li>Willem Visser, <em>NASA</em>, USA</li>
		<li>Joachim Wegener, <em>DaimlerChrysler</em>, Germany</li>	
	</ul>		
</div>
<?php
	print $page->getFooterHTML();
?>
