<?php
	include("_proj/Proj.php");
	$page =& Toucan::create("Proj_TAICPART_Page", 
							array("url"=>"enquiries.php",
								  "subtitle"=>"Enquiries"));
	print $page->getHeaderHTML();
?>
	
	<h1>Enquiries</h1>
				
	<p>For enquiries regarding TAIC PART, please contact the general chair, 
	   <a href="http://www.dcs.kcl.ac.uk/staff/mark/">Mark Harman</a>.</p>	
		
<?php
	print $page->getFooterHTML();
?>
