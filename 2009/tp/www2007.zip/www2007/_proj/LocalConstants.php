<?php

// paths
define("TOUCAN_PATH", "C:/Documents and Settings/phil/My Documents/Toucan/");
define("PROJ_PATH",   "C:/Documents and Settings/phil/My Documents/TAIC PART/www2007/_proj/");
define("ADMIN_EMAIL", "p.mcminn@dcs.shef.ac.uk");

// toucan	
define("TOUCAN_SHOW_ERRORS",      true);
define("TOUCAN_SHOW_WARNINGS",    false);
define("TOUCAN_SHOW_DEBUG",       false);
define("TOUCAN_SHOW_QUERY",       false);
define("TOUCAN_SHOW_EXEC_CMD",    false);
define("TOUCAN_SHOW_EXEC_OUTPUT", false);
define("TOUCAN_STATE_KEY",		  "cumberl@ndlodge");
define("TOUCAN_EMAIL_LOG_FILE",   "_log/email");

?>