<?php

class Proj_TAICPART_Presentation_Footer extends Toucan_Presentation
{
	function Proj_TAICPART_Presentation_Footer($props)
	{
		parent::Toucan_Presentation($props);
	}

	function getHTML()
	{
		$html = <<< HTML
		
	<div class="spacer"></div>
	</div>
	
	<div id="line_footer"></div>
</div>		
HTML;

		return $html;
	}

}

?>