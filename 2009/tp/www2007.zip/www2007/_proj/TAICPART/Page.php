<?php

Toucan::load("Toucan_Page");

class Proj_TAICPART_Page extends Toucan_Page
{
	function Proj_TAICPART_Page($props) 
	{
		$title = $this->_getPropDefault($props, "title");
		$url = $this->_getPropDefault($props, "url");
		
		if (!$title) {
			$subtitle = $this->_getPropDefault($props, "subtitle");
			if ($subtitle) {
				$props["title"] = "TAIC PART :: ".$subtitle;
			} else {
				$props["title"] = "TAIC PART :: "
				                . "Testing: Academic &amp; Industrial Conference - "
				                . "Practice And Research Techniques";	
			}
		}
			
		$props["metaDescription"] = <<< META
TAIC PART will be a workshop that brings together academics working on algorithms, methods and techniques from practical
software testing, with industrialists, interested in developing more soundly-based and
well-understood testing processes and practices.
META;

		$props["metaKeywords"] = <<< META
TAIC PART, TAICPART, Testing, Academia, Industry, Practice, Research Techniques,
UKTest, UK test, Mark Harman, Phil McMinn, Zheng Li, David Willmor
META;
		$props["xmlPrologue"] = true;
		
		$props["favIconURL"] = 'http://www.taicpart.org/favicon.ico';
		
		parent::Toucan_Page($props);
		
		$bodyTemplate = $this->_getPropDefault($props, "bodyTemplate");	
		if ($bodyTemplate) {
			$templateFile = PROJ_PATH."content/{$bodyTemplate}.inc";
			$template = file_get_contents($templateFile);
			$this->addPresentation(array('type'    	=> 'Proj_CCC_Presentation_Template',
			                             'template' => $template,
										 'location' => 'body'));			
		}
		
		$this->addPresentation(array(
				"type"     => "Proj_TAICPART_Presentation_Header",
				"location" => "header",
				"url"      => $url));

		$this->addPresentation(array(
				"type"     => "Proj_TAICPART_Presentation_Footer",
				"location" => "footer"));		
				
		$this->addStyleSheet("style/taicpart.css");
	}
}
?>