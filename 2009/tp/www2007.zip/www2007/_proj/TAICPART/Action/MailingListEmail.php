<?php

Toucan::load("Toucan_Action_SendEmailFromForm");

class Proj_TAICPART_Action_MailingListEmail extends Toucan_Action_SendEmailFromForm
{				
	var $_toEmailAddress;
	var $_subject;
	var $_form;
	var $_loadFields;
	
	function Proj_TAICPART_Action_MailingListEmail($props)
	{
		parent::Toucan_Action_SendEmail($props);
		$this->_form       =& $this->_getProp($props, "form");
		$this->_loadFields =  $this->_getProp($props, "loadFields");
	}

	function _loadFields()
	{
		foreach ($this->_loadFields as $loadField => $internalField) {
			$this->$internalField = $this->_form->getFieldValue($loadField);
		}

		$email = str_replace("@", "=", $this->_pEmail);
		
		$this->_toEmailAddress   = "mailinglist-subscribe-$email@taicpart.org";
		$this->_fromEmailAddress = ADMIN_EMAIL;
		$this->_subject          = "";
		$this->_message          = "";
		$this->_bcc              = ADMIN_EMAIL;
	}

	function process()
	{
		$this->_loadFields();
		parent::process();
	}
}

?>