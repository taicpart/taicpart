<?php
$server = $_SERVER["HTTP_HOST"];
$redirectServers = array("taicpart.org");
$hostServer = "www2007.taicpart.org";

if (in_array($server, $redirectServers)) {
	header("Location: http://{$hostServer}{$_SERVER['REQUEST_URI']}");
	die();
}

if ($server == $hostServer) {
	include("HostConstants.php");
} else {
	include("LocalConstants.php");
}

// start Toucan
require_once(TOUCAN_PATH."Toucan.php");
Toucan_Lib_Sys::addToIncludePath(TOUCAN_PATH);
Toucan_Lib_Sys::addToIncludePath(PROJ_PATH);

define("CONFERENCE_SHORT_DATE", "12-14 September 2007");
define("CONFERENCE_DATE", "Wednesday 12 - Friday 14 September, 2007");
define("SUBMISSION_DATE", "Friday 13th April 2007");
define("INFORM_DATE", "June 2007");

?>