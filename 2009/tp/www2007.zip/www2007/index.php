<?php
	include("_proj/Proj.php");
	$page =& Toucan::create("Proj_TAICPART_Page", array("url"=>"."));
	print $page->getHeaderHTML();
?>

	<h1>Get ready to TAIC PART in 2007</h1>

		<div class="cumberland_photo photo">
			<img src="images/cumberland.jpg" width="200" height="254" alt="" /><br />
			Cumberland Lodge, Windsor, UK
		</div>
			
	<p>
	TAIC PART is a testing workshop that aims to forge collaboration between
	industry and academia on the challenging and exciting problem of
	software testing.  The event, is sponsored by representatives of both industry and
	academia, bringing together commercial and industrial software
	developers and users with academic researchers working on the theory and practice
	of software testing.</p>  
	
	<p>Take a look and see what happened at 
	<a href="http://www2006.taicpart.org">TAIC PART 2006</a>.</p>
	
	<p>
	The conference will be held at <a href="http://www.cumberlandlodge.ac.uk/" target="_blank">Cumberland Lodge</a>,
	 Windsor, UK, <?=CONFERENCE_SHORT_DATE?>.
	Cumberland lodge is a former royal residence given to the nation
	in 1946 by the late Queen Mother. It is an ideal setting for a productive and enjoyable
	conference, providing world-class conference facilities in an ideal
	location, which resonates with centuries of historical significance, dating back to
	the mid 17th century.
	</p>

	<p>Download the <a href="publicity/announce07.pdf">TAIC PART 2007 PDF Announcement</a>.</p>

	<h2>Co-located workshop: Mutation 2007</h2>
	<p><a href="http://www.ise.gmu.edu/mutation2007/" target="_blank">Mutation 2007</a> will be co-located
	with TAIC PART, and is scheduled for the preceeding two days - Monday and Tuesday (10-11 September).
	Mutation 2007 shares the same submission dates as TAIC PART - for more information see the 
	<a href="http://www.ise.gmu.edu/mutation2007/" target="_blank">Mutation 2007 website</a>.</p>
	
	<p>Download the <a href="publicity/mutation.pdf">Mutation 2007 PDF Announcement</a>.</p>
	
	<div class="right_column">	

		<h2>In collaboration with</h2>
		
			<a href="http://www.ieee.org" target="_blank"><img src="images/ieee.gif" width="101" height="125" alt="IEEE" border="0" /></a>
			<a href="http://www.computer.org/ " target="_blank"><img src="images/ieee-cs.gif" width="203" height="125" alt="IEEE Computer Society" border="0" /></a>


		<br />&nbsp;		
		
		<h2>Sponsors</h2>
		
		<div class="sponsors">
			
			<a href="http://www.electromind.com/" target="_blank"><img src="images/electromind.jpg" width="200" height="33" alt="Electromind" border="0" /></a>
			
			<a href="http://www.ericsson.com" target="_blank"><img src="images/ericsson.gif" width="150" height="34" alt="Ericsson" border="0" /></a>
			
			<br />
			
			<a href="http://www.gerrardconsulting.co.uk" target="_blank"><img src="images/gerrard.gif" width="125" height="43" alt="Gerrard Consulting" border="0" /></a> 
						
			<a href="http://www.ldra.co.uk" target="_blank"><img src="images/ldra.gif" width="150" height="61" alt="LDRA" border="0" /></a> 

			<br />
			
			<a href="http://www.research.nokia.com" target="_blank"><img src="images/nokia.gif" width="141" height="57" alt="Nokia" border="0" /></a>
			
			<a href="http://www.vizuri.co.uk" target="_blank"><img src="images/vizuri.jpg" width="125" height="80" alt="Vizuri" border="0" /></a>
		
			<? // note to self: add new sponsors to CFP too ?>
		</div>
		
	</div>


	<h2>Important Dates</h2>
	<ul>
	<li>Deadline for submission of papers: <br />  <strong><?=SUBMISSION_DATE?></strong></li>
	<li>Notification of acceptance: <br /> <strong><?=INFORM_DATE?></strong></li>
	<li>Workshop: <br /> <strong><?=CONFERENCE_DATE?></strong></li>
	</ul>
	
	<h2>Organisation</h2>
	<ul>
		<li><strong>General chair</strong><br />
			<a href="http://www.dcs.kcl.ac.uk/staff/mark/" target="_blank">Professor Mark Harman</a><br />
			<em>King's College London</em></li>		
		<li><strong>Program Committee Chair</strong><br />
			<a href="http://www.dcs.shef.ac.uk/~phil/" target="_blank">Dr Phil McMinn</a><br />
			<em>University of Sheffield</em></li>		
		<li><strong>Local Arrangements Chair</strong><br />
			<a href="mailto:Chris.McCulloch@kcl.ac.uk" target="_blank">Christine McCulloch</a><br />
			<em>King's College London</em></li>
		<li><strong>PhD Symposium Chair</strong><br />
			<a href="http://www.cs.man.ac.uk/~willmord/" target="_blank">David Willmor</a><br />
			<em>University of Manchester</em></li>
	</ul>	

<?php
	print $page->getFooterHTML();
?>