<?php
	include("_proj/Proj.php");
	$page =& Toucan::create("Proj_TAICPART_Page", 
							array("url"=>"missing.php",
								  "subtitle"=>"404 Error"));
	print $page->getHeaderHTML();
?>
	
	<h1>The requested URL was not found on this server</h1>
	
	<br />
		
<?php
	print $page->getFooterHTML();
?>
