<?php
	header("Location: papersubmission.php#formatting");
?>
	