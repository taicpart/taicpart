<?php
	include("_proj/Proj.php");
	$page =& Toucan::create("Proj_TAICPART_Page", 
							array("url"      => "local.php",
							      "subtitle" => "Local &amp; Travel Information"));
	print $page->getHeaderHTML();
?>
	
	<h1>Local &amp; Travel Information</h1>
		
	<h2>Getting to Cumberland Lodge</h2>	
	<ul>
	<li>Download the <a href="local/clodge_map.pdf">comprehensive Cumberland Lodge travel information PDF</a> containing details how to 
		<strong>get to the Lodge via road, air or taxi</strong>, including a  
		<strong>local map of Windsor Great Park and the surrounding area</strong>.</li>
		
	<li>Cumberland Lodge can be found on Google maps <a href="http://maps.google.co.uk/maps?f=q&hl=en&sll=51.440955,-0.607681&sspn=0.107428,0.234146&q=cumberland+lodge&om=1" target="_blank">here</a>.</li>
	</ul>

	<p>For reference, the address and telephone number of the Lodge are as follows: </p> 
	<ul><li>Cumberland Lodge, The Great Park, Windsor,
	Berkshire, SL4 2HP, UK.<br />
	Telephone: 01784 432316<br />
	Website: <a href="http://www.cumberlandlodge.ac.uk" target="_blank">http://www.cumberlandlodge.ac.uk</a></ul>

	<h2>Accommodation for pre- and post-Workshop nights</h2>
	
	<p>Cumberland Lodge is not a hotel, and thus cannot accomodate attendees the night before or the night after the workshop.  
	   Download the <a href="local/accommodation.pdf">local B&amp;Bs 
	and hotels information PDF</a>. </p>
	
	<h2>Arrival / First Workshop Day</h2>
	<p>Mutation 2007 due to begin at 10am on Monday 10 September (see <a href="http://www.ise.gmu.edu/mutation2007/">Mutation 2007 programme</a>), 
	    <br /> TAIC PART at 10am, Wednesday 12th (see <a href="tp-programme.pdf">TAIC PART programme</a>).</p>
	
	<p>Please arrive promptly at the Lodge and notify your arrival at Reception.  
	The Cumberland Lodge staff will direct you to your room, and to the location of the initial session.</p>
	

	
<?php
	print $page->getFooterHTML();
?>
