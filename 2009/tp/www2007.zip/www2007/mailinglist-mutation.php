<?php
	session_start();
	
	include("_proj/Proj.php");
	$page =& Toucan::create("Proj_TAICPART_Page", 
							array("url"      => "mailinglist.php",
							      "subtitle" => "Stay Informed"));

	$form =& $page->addForm("mailinglist");

	$form->addField(array("type"    => "Text",
						  "size"    => 30,
	                      "name"    => "liame",
	                      "caption" => "Email Address",
	                      "validation" => array(array("type" => "EmailAddress",
	                                                  "options" => array("allowNull"=>false)))));

	$submittedMessage = Toucan::create("Toucan_Presentation_HTML", 
			array("display" => false,
				  "page"    => &$page,
				  "html"    => "<h3>Thank you - the command to add your email address has been sent to the mailing list</h3>"));

	$submit =& $form->addButton("submit");
	
	$submit->addAction(
			array("type"       => "Proj_TAICPART_Action_MailingListEmail",
			      "form"       => &$form,
			      "loadFields" => array("liame"=>"_pEmail")));
			      
	$submit->addAction(
			array("type" 		 => "ToggleDisplay",
				  "presentation" => &$submittedMessage));
	
	$submit->addAction(
			array("type"         => "ToggleDisplay",
				  "presentation" => &$form));	
	
	$form->process();
	
	print $form->getHTML();
	print $submittedMessage->getHTML();

?>

<a href="http://www.ise.gmu.edu/mutation2007/">&lt;&lt;&lt; Back to Mutation 2007 website</a>
