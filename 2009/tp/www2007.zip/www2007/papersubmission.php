<?php
	include("_proj/Proj.php");
	$page =& Toucan::create("Proj_TAICPART_Page", 
							array("url"      => "papersubmission.php",
							      "subtitle" => "Paper submission"));
	print $page->getHeaderHTML();
?>
	
	<h1>Electronic Paper Submission</h1>
	
	<p>Electronic paper submission will open late March 2007.</p>
	
	<a name="formatting"></a>
	<h1>Formatting your paper</h1>
		
	<p><strong>The full proceedings will be published by the IEEE Computer Society.</strong></p> 
	
	<p><strong>Therefore, all papers and other materials for the proceedings must
	   be typeset to conform to IEEE conference style guidelines.</strong></p>
		
	<p>Instructions for this are available in the following formats: <a href="formatting/instruct.doc">MS-Word Document</a> | <a href="formatting/instruct.ps">PS</a> | <a href="formatting/instruct.pdf">PDF</a>.</p>
	
	<p><strong>For MS-Word users</strong>, the <a href="formatting/instruct.doc">instruction word document</a> can be used as a basis for formatting your paper.
	Otherwise, the <a href="formatting/format.doc">format.doc</a> file can be used.  This is also available in <a href="formatting/format.ps">PS</a> and <a href="formatting/format.pdf">PDF</a> formats.</p>
	   
	<p><strong>Latex users</strong> should download <a href="formatting/IEEE_CS_Latex.zip">IEEE_CS_Latex.zip</a> which contains the required style files.</p>
		
	<h2>Page Limits</h2>
	
	<p>Your paper <strong>must</strong> conform to the following page limits:</p>
	
	<table class="paperLengths">
		<tr><th>Paper type</th><th>Maximum Length</th></tr>
		<tr><td>Research</td><td>10 pages</td></tr>
		<tr><td>"Challenge"</td><td>5 pages</td></tr>
		<tr><td>Tools</td><td>5 pages</td></tr>
		<tr><td>Experience</td><td>5 pages</td></tr>
		<tr><td>Paper for PhD program</td><td>5 pages</td></tr>
	</table>
	
	<p><strong>For a definition of the different paper types</strong>, please consult the <a href="callforpapers.php">call for papers</a>.</p>
		
		
<?php
	print $page->getFooterHTML();
?>
