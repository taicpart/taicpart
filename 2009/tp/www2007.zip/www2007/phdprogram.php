<?php
	include("_proj/Proj.php");
	$page =& Toucan::create("Proj_TAICPART_Page", 
							array("url"      => "phdprogram.php",
							      "subtitle" => "PhD Program"));
	print $page->getHeaderHTML();
?>
	
<h1>PhD Program</h1>
	
<p>The workshop will include a half-day PhD program.</p>	

<p>The goal of the half-day PhD program is to provide a supportive yet
questioning setting in which students can present their work. Students
will be able to discuss their goals, methods, and results at an early
stage in their research. The PhD program aims to provide useful
guidance for completion of the dissertation research and initiation of
a research career.</p>
	
<h2>Scope</h2>

<p>The technical scope of the PhD program is that of TAIC PART 2007.
Students should consider participating in the PhD program after having
settled on a research area or dissertation topic. Students selected to
attend the Symposium will be asked to present a talk about their work
and their research abstracts will appear in the TAIC PART 2007
Proceedings.</p>

<p>The Doctoral Symposium Committee will select participants using the
following criteria: the potential quality of the research and its
relevance to software testing, quality of the research abstract, stage
of the research (students will be selected across a range of research
stages) and the applicability of the research area to industry.</p>

<h2>Submission Format</h2>

<p>Submissions should be in the form of a paper which is a maximum of 5 pages long, 
formatted in accordance with the
<a href="formatting.php">TAIC PART 2007 Format and Submission Guidelines</a>. 
It should aim to
cover: the technical problem to be solved with a justification of its
importance, an account of related work explaining why this has not
solved the problem, the research hypothesis or claim, a sketch of the
proposed solution and the expected contributions of your dissertation
research.</p>

<p>PhD papers should be submitted electronically via the website - 
<a href="papersubmission.php">http://www2007.taicpart.org/papersubmission.php</a></p>

<h2>Important Dates</h2>

<ul>
<li>Deadline for submission of papers: <br />  <strong><?=SUBMISSION_DATE?></strong></li>
<li>Notification of acceptance: <br /> <strong><?=INFORM_DATE?></strong></li>
<li>Workshop: <br /> <strong><?=CONFERENCE_DATE?></strong></li>
</ul>

<h2>For more information</h2>
<p>Contact the PhD symposium chair, <a href="http://www.cs.man.ac.uk/~willmord/" target="_blank">David Willmor</a>.</p>
		
		
<?php
	print $page->getFooterHTML();
?>
