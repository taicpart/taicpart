<?php
	include("_proj/Proj.php");
	$page =& Toucan::create("Proj_TAICPART_Page", 
							array("url"      => "keynotes.php",
							      "subtitle" => "Keynote Speakers"));
	print $page->getHeaderHTML();
?>
	
	<h1>Keynote Speakers</h1>
	
	<br />	
	
	<h2>Michael Ernst, MIT, USA</h2>
	
	<p class="image_column">
		<img src="images/ernst.jpg" width="110" height="150" alt="Michael Ernst" />
	</p>
	
	<h3>Topic: Automatic Discovery of Program Specifications</h3>
	
<p>	
Michael D. Ernst is Associate Professor in the MIT Electrical Engineering
and Computer Science department and in the MIT Computer Science and
Artificial Intelligence Lab.  His primary technical interest is programmer
productivity, encompassing software engineering, testing, verification,
static and dynamic program analysis, compilation, and programming language
design.  However, he has also published in artificial intelligence, theory,
and other areas of computer science.  Ernst was previously a researcher at
Microsoft Research.
</p>
	
<p>Michael's homepage can be found at: <a href="http://pag.csail.mit.edu/~mernst/" target="_blank">http://pag.csail.mit.edu/~mernst</a>.
	
	<br clear="all" />	

	&nbsp;
	
	<br />

	<h2>Andreas Zeller, Saarland University, Germany</h2>

	<p class="image_column">
		<img src="images/zeller.jpg" width="120" height="137" alt="Andreas Zeller" />
	</p>

	<h3>Topic: Automated Debugging</h3>	

<p>
Andreas Zeller is computer science professor at Saarland University;
he researches large programs and their history, and has developed a
number of methods to determine the causes of program failures - on
open-source programs as well as in industrial contexts at IBM,
Microsoft, SAP and others.  His book "Why Programs Fail"  has
received the Software Development Magazine productivity award in 2006.	
</p>	

<p>Andreas' homepage can be found at: <a href="http://www.st.cs.uni-sb.de/zeller/" target="_blank">http://www.st.cs.uni-sb.de/zeller</a>.

<?php
	print $page->getFooterHTML();
?>
