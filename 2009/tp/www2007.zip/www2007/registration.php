<?php
	include("_proj/Proj.php");
	$page =& Toucan::create("Proj_TAICPART_Page", 
							array("url"      => "registration.php",
							      "subtitle" => "Registration"));
	print $page->getHeaderHTML();
?>
	
	<h1>Registration</h1>
		
	<p>Registration will commence shortly after the outcome of paper submissions are announced.</p>

<?php
/*	
	
	<h2>Fees</h2>
	
	<p>The standard fee is expected to be <strong>&pound;250</strong>.  This will include:
		<ul>
			<li>a copy of the proceedings</li>
			<li>all meals (including two breakfasts, two dinners and three
lunches)</li> 
		<li>outstanding accommodation on site for two nights.</li></ul></p>

    <p>We will offer a further reduced rate for up to 10 PhD students of <strong>&pound;100</strong>.  This is open to students from the UK and the EU.  First choice will be given to those accepted for the PhD program.</p>
*/	
?>	
	
		
<?php
	print $page->getFooterHTML();
?>
