<?php
	include("_proj/Proj.php");
	$page =& Toucan::create("Proj_TAICPART_Page", 
							array("url"      => "callforpapers.php",
							      "subtitle" => "Call for papers"));
	print $page->getHeaderHTML();
?>
	
<h1>Call for papers</h1>
		
<p><strong><span class="emph">TAIC PART</span> is a testing workshop that aims to forge collaboration between industry and academia on the challenging and exciting problem of software testing.</strong> It is sponsored by representatives of both industry and academia, bringing together commercial and industrial software developers and users with academic researchers working on the theory and practice of software testing.
</p>

<p><strong>The workshop will be held at Cumberland Lodge, Windsor Great Park, UK, <?=CONFERENCE_DATE?>.</strong></p>

<p>Cumberland Lodge is a former royal residence given to the nation in 1946 by the late Queen Mother. It is an ideal setting for a productive and enjoyable conference, providing world-class conference facilities in an ideal location, which resonates with centuries of historical significance, dating back to the mid 17th century.</p>

<p>Authors are invited to submit papers describing original research, experience, tools or industrial "challenges" in testing. <strong>All topics</strong> in software testing will be considered.  A special focus will be on papers which are in accordance with the theme of the conference, which will be <span class="emph">Technology Transfer from Academia to Industry in Software Testing</span>.  A special issue of the <a href="http://www.elsevier.com/wps/find/journaldescription.cws_home/505732/description#description" target="_blank">Journal of Systems and Software</a> containing extended versions of selected papers from TAIC PART 2007 will focus on this theme.</strong> </p>

<p><span class="emph">Research topics</span> include (but are not limited to):</p>

<ul>
<li>Theory of testing (adequacy criteria, relationships between testing and formal methods etc.)</li>
<li>Testing strategies (black-box, white-box, non-functional, state-based etc.)</li>
<li>Test data generation techniques (search-based, constraint logic etc.)</li>
<li>Model based testing and model checking</li>
<li>Process issues and methods</li>

</ul>

<p><span class="emph">Experience papers</span> should describe industrial experience applying testing techniques and/or tools to commercial projects or open source solutions; the problems tackled and the results.</p>

<p><span class="emph">Tools papers</span> should describe novel developments in environments and systems of potential benefit to the testing community.</p>

<p><span class="emph">Industrial "challenge" papers</span> should have at least one author whose affiliation is non-academic and should describe an example of a real-world software testing problem, for which help is sought from the academic research community. Such papers should set out the problem, the goal of testing for this problem area and the way in which the success or otherwise of a proposed solution will be assessed. One goal of the workshop will be to create on-going partnerships which will seek to solve these industrial challenges.</p>

<p><span class="emph">The full proceedings will be published by the IEEE Computer Society.</span>  Materials for the proceedings should be typeset to conform to IEEE conference style guidelines. These are described and mirrored at <a href="papersubmission.php#formatting">http://www2007.taicpart.org/papersubmission.php</a>. There is a page limit for all submissions. For research papers this is 10 pages in IEEE conference style format. For "challenge", "tools" and "experience" submissions the page limit is 5 pages in IEEE conference style format.</p>

<p>All papers should be submitted electronically via the website - <a href="http://www2007.taicpart.org/papersubmission.php">http://www.taicpart.org/papersubmission.php</a></p>

<p><span class="emph">The workshop will include a half-day PhD program</span>. The goal of the half-day PhD program is to provide a supportive yet questioning setting in which students can present their work. Students will be able to discuss their goals, methods, and results at an early stage in their research. The PhD program aims to provide useful guidance for completion of the dissertation research and initiation of a research career.
<br />
Students should consider participating in the PhD program after having settled on a research area or dissertation topic.  PhD papers should be a maximum of 5 pages long in IEEE conference style format. PhD papers will be reviewed separately from the other types of submission, but are subject to the same deadlines.  The paper should aim to cover: the technical problem to be solved with a justification of its importance, an account of related work explaining why this has not solved the problem, the research hypothesis or claim, a sketch of the proposed solution and the expected contributions of your dissertation research. 
Participants will be selected using the following criteria: the potential quality of the research and its relevance to software testing, quality of the research abstract, stage of the research (students will be selected across a range of research
stages) and the applicability of the research area to industry.  Students selected to attend will be asked to present a talk about their work and their papers will appear in the proceedings.  For more information, contact <a href="http://www.cs.man.ac.uk/~willmord/" target="_blank">David Willmor</a>, email: <a href="mailto:d.willmor@cs.manchester.ac.uk">d.willmor@cs.manchester.ac.uk</a>.</p>

<p><span class="emph">Keynote Speakers</span></p>
<ul>
<li>Michael D. Ernst, MIT, USA</li>
<li>Andreas Zeller, Saarland University, Germany</li>
</ul>

<p><span class="emph">Important Dates</span></p>

<ul>
<li>Deadline for submission of papers: <br />  <strong><?=SUBMISSION_DATE?></strong></li>
<li>Notification of acceptance: <br /> <strong><?=INFORM_DATE?></strong></li>
<li>Workshop: <br /> <strong><?=CONFERENCE_DATE?></strong></li>
</ul>

<p><span class="emph">General Chair:</span>&nbsp;<a href="http://www.dcs.kcl.ac.uk/staff/mark/" target="_blank">Professor Mark Harman</a>, King's College London</p>
<p><span class="emph">Program Chair:</span>&nbsp;<a href="http://www.dcs.shef.ac.uk/~phil/" target="_blank">Dr Phil McMinn</a>, University of Sheffield</p>
<p><span class="emph">Local Arrangements Chair:</span>&nbsp;<a href="mailto:Chris.McCulloch@kcl.ac.uk" target="_blank">Christine McCulloch</a>, King's College London</p>
<p><span class="emph">PhD Program Chair:</span>&nbsp;<a href="http://www.cs.man.ac.uk/~willmord/" target="_blank">David Willmor</a>, University of Manchester</p>

<p><span class="emph">Sponsors include (to date):</span> <a href="http://www.gerrardconsulting.co.uk" target="_blank">Gerrard Consulting</a>, <a href="http://www.ldra.co.uk/" target="_blank">LDRA</a>, <a href="http://research.nokia.com" target="_blank">Nokia</a> and <a href="http://www.vizuri.co.uk" target="_blank">Vizuri</a>.</p>
		
<?php
	print $page->getFooterHTML();
?>
