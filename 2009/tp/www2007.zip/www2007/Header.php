<?php

class Proj_TAICPART_Presentation_Header extends Toucan_Presentation
{
	var $_url;
	
	function Proj_TAICPART_Presentation_Header($props)
	{
		parent::Toucan_Presentation($props);
		$this->_url = $this->_getProp($props, "url");
	}

	function getHTML()
	{
		$tabs = array("."                	 => "Welcome",
					  "callforpapers.php" 	 => "Call for<br />Papers",
					  "programcommittee.php" => "Program<br /> Committee",
					  "keynotes.php"         => "Keynote<br />Speakers",
                      "tp-programme.pdf"     => "Programme",
                      "local.php"            => "Travel &amp;<br />Arrival",
					  //"registration.php" 	 => "Registration",				  
		        "registration.php" 	 => "Registration<br />(<span style=\"color:#ff0000; font-weight:bold\">CLOSED</span>)",				  
		        "mailinglist.php"      => "Stay<br />Informed");
		
		$html  = '<div id="body">';
		$html .= '<h1 class="logo"><a href="." class="logo no_text">';
		$html .= 'TAIC PART :: Testing: Academic &amp; Industrial Conference - ';
		$html .= 'Practice And Research Techniques</a></h1>';
		$html .= '<div id="words"></div>';
		$html .= '<div id="endheader"></div>';
		$html .= '<ul id="menu">';

		$last = "";
		$sel = "";
		$neighbour = "";
			
		foreach ($tabs as $url=>$name) {
			if ($this->_url == $url) {
				$sel = "_sel";
			} else {
				$sel = "";	
			}
			
			if ($last) {
				$neighbour = "";
				if ($last == $this->_url) {
					$html .= "<span class=\"tab_sel_right\"></span>";
				} else if (!$sel) {
					$html .= "<span class=\"tab_right\"></span>";
				}
				$html .= '</li>';
			} else {
				$neighbour = "_no_neighbour";
			}
			
			
			$html .= "<li class=\"tab\">";
			
			if ($last != $this->_url) {
				$html .= "<span class=\"tab{$sel}_left{$neighbour}\"></span>";
			}
			
			$html .= "<a href=\"{$url}\" class=\"tab{$sel}_mid\">";
			
			if (strpos($name, "<br />") !== FALSE) {
				$html .= "<span class=\"tab_inner_two_lines\">";
			} else {
				$html .= "<span class=\"tab_inner_one_line\">";
			}
			
			$html .= "{$name}</span></a>";	
			$last = $url;
		}
		
		$html .= "<span class=\"tab{$sel}_right_no_neighbour\"></span>";
		$html .= '</li>';
		$html .= '</ul>';
		$html .= '<div id="content">';

		return $html;
	}
}

?>